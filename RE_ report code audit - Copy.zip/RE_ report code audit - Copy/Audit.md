# OpenSafety � Detailed Modernization Assessment

## 1. Executive Summary

OpenSafety is a **legacy .NET Framework 4.7.1** multi-tier enterprise web application built with a classical n-tier / Domain-Driven Design (DDD) structure. It is production-deployed to on-premises IIS servers with an Azure SQL backend. The codebase was clearly built over several years by multiple developers and carries significant technical debt. The path forward is a migration to **.NET 8 (LTS)** with modernized architecture patterns.

---

## 2. Solution Inventory

| Layer | Project | Framework | Technology |
|---|---|---|---|
| Frontend (MVC) | `OpenSafetyFrontend` | .NET FW 4.7.1 | ASP.NET MVC 5.2.3, Bootstrap 3, jQuery 3.3 |
| Frontend App | `OpenSafetyFrontedApplication` | .NET FW **4.5.2** ?? | ASP.NET MVC (scaffold/stub) |
| Distributed Service | `OpenSafetyDistributedService` | .NET FW 4.7.1 | **WCF** (8 `.svc.cs` files) |
| Application Layer | `OpenSafetyApplication` | .NET FW 4.7.1 | Plain C# services |
| Contract Layer | `OpenSafetyContract` | .NET FW 4.7.1 | WCF `[ServiceContract]`, DTOs |
| Domain Model | `OpenSafetyDomainModel` | .NET FW 4.7.1 | Entities, Repository interfaces |
| Infrastructure | `OPenSafetyInfrastructure` | .NET FW 4.7.1 | EF 6, NEST/Elasticsearch 6 |
| Cross-Cutting | `OpenSafetyCrossCutting` | .NET FW 4.7.1 | Cache, Email, Exceptions, Enums |
| DI / IoC | `OpenSafetyDependancyResolver` | .NET FW 4.7.1 | Unity 5.2.1 |
| Async Service | `WsAsynchronousSilicoState` | .NET FW 4.7.1 | Windows Service (`ServiceBase`) |
| API (placeholder) | `WebApiOpenSafety` | .NET FW 4.7.1 | Unused scaffolded ASP.NET Web API 2 |
| Tests | `OpenSafetyDistributedService.Tests`, `OpenSafetyFrontend.Tests` | .NET FW 4.7.1 | MSTest, minimal/empty |

---

## 3. Critical Issues (Must Fix)

### 3.1 End-of-Life Runtime

- **All projects target .NET Framework 4.7.1**, which is in maintenance-only support. No new features will be added and .NET 9/10 ecosystem features are unavailable.
- `OpenSafetyFrontedApplication` still targets **.NET Framework 4.5.2**, which is **completely out of support** since January 2016.
- **Action:** Migrate all projects to **.NET 8 LTS** (or at minimum .NET 9).

### 3.2 WCF as the Service Bus

- The entire service layer (`OpenSafetyDistributedService`) is built on **WCF** (8 `.svc` services: Dico, Admin, Acquisition, Data, Cosmetochem, MDM, Mpnet, Synonyms).
- WCF **does not run on .NET Core / .NET 5+** (only `CoreWCF` as a partial community port exists).
- The frontend consumes these services via **`System.ServiceModel`** client proxies (`Service References`).
- Endpoints are still `localhost:59525/OpenSafetyDistributedService/*.svc` URIs in `Web.config`.
- **Action:** Replace all WCF services with **ASP.NET Core Minimal APIs or Web API controllers**, and replace generated client proxies with typed `HttpClient` factories.

### 3.3 Hardcoded Credentials in Source Control

- `OpenSafetyDistributedService\Web.config` contains a **clear-text database password** (`Password=DBadmin@123456789`) and an application password (`OPSty!4Pit#18`) committed to git.
- **Action:** Immediately rotate credentials. Store secrets in **Azure Key Vault** or environment variables, never in config files tracked by git. Add `Web.config` to `.gitignore` or use config transforms with placeholder values only.

### 3.4 Synchronous Blocking HTTP Calls (`IDisposable HttpClient` anti-pattern)

- `RestHelper.cs` and multiple application services (`CosmetochemApplicationService`, `DataApplicationService`) instantiate `new HttpClient(handler)` inside `using` blocks � 13+ files affected.
- `HttpClient` disposal causes **socket exhaustion** under load (DNS changes not respected, connection pool exhausted).
- `result.Result` blocking calls exist in `RestHelper.ExecuterWebMethode<T>` � **12 files use `.Result` or `.Wait()`**, risking deadlocks in ASP.NET's synchronization context.
- **Action:** Register typed/named `HttpClient` instances via `IHttpClientFactory` in DI. Convert all call-sites to `async/await` (`await client.GetAsync(...)` instead of `.Result`).

---

## 4. High-Priority Issues

### 4.1 Dependency Injection � Broken / Stub Implementations

- `OpenSafetyDependancyResolver\App_Start\UnityConfig.cs` and `OpenSafetyCrossCutting\App_Start\UnityConfig.cs` are **copy-paste stubs** that register nothing but set the `DependencyResolver`.
- `OpenSafetyDistributedService\App_Start\UnityConfig.cs` is also an empty stub; each WCF service re-calls `UnityConfig.RegisterComponents()` in its **parameterless constructor**, re-creating the container on every request.
- The production `UnityConfig.cs` (`OpenSafetyDependancyResolver\UnityConfig.cs`) uses **Unity 5.2.1**, which is an older, unmaintained container.
- **Action:** Replace Unity with the built-in `Microsoft.Extensions.DependencyInjection` (available since .NET Core 1.0). Remove all stub `UnityConfig` duplicates. Wire DI via a single `Program.cs` / `Startup.cs`.

### 4.2 No `async/await` Propagation

- Only **3 out of 578** `.cs` files use `async`/`await`. All I/O operations (database via EF, HTTP, SMTP, file I/O) are **synchronous**, blocking thread-pool threads.
- EF 6 queries use `.ToList()` materialisation inside LINQ joins on **entire tables** (see `GenericRepository.cs`, `EFDicoRepository.cs`) � this loads full table sets into memory before filtering in C#.
- **Action:** Adopt `async`/`await` throughout, use EF Core async methods (`ToListAsync`, `FirstOrDefaultAsync`), and push filtering to the database with proper LINQ-to-SQL predicates.

### 4.3 Entity Framework 6 ? EF Core

- Infrastructure uses **EF 6.1.3** with `packages.config`, a `DbContext` (`OpenSafetyDBContext`), and EF Migrations (24+ migration files).
- EF 6 does not support .NET 8.
- **Action:** Migrate to **EF Core 8**, which supports all existing patterns (DbContext, Migrations, Code-First). EF Core offers better async support, query splitting, bulk operations, and compiled queries.

### 4.4 Inconsistent Null Safety and Defensive Patterns

- **0 files** enable `#nullable` annotations.
- Direct `int.Parse()` without validation (e.g., `int.Parse(sourceId)`, `int.Parse(indexRow)`) throughout the infrastructure layer � unhandled `FormatException` at runtime.
- `GetIdSourceByName` calls `.ID` on `FirstOrDefault()` without null check � guaranteed `NullReferenceException` if not found.
- **Action:** Enable `<Nullable>enable</Nullable>` globally, introduce `int.TryParse`, replace null-dereference patterns with null-conditional operators or guard clauses.

### 4.5 Exception Handling Anti-patterns

- **57 files** catch `Exception` generically; **44 files** re-throw `new Exception(e.Message)` � this **destroys the original stack trace** and swallows inner exceptions.
- Each service method has an identical triple catch block (`UnauthorizedException` / `FaultException` / `Exception`) copy-pasted across 100+ methods.
- **Action:** Use `throw;` (bare rethrow) to preserve stack traces. Create domain-specific exception types. Introduce a global exception handler middleware instead of per-method catch blocks.

---

## 5. Architecture Issues

### 5.1 Layer Violations and Coupling

- `GenericRepository.cs` in the Infrastructure layer imports `OpenSafetyFrontend.ServiceAdmin` (a WCF service client proxy from the **UI layer**) � a clear **downward dependency** violation.
- `BaseService.cs` in the Application layer references `DicoAdapter` and `DicoDomainService` directly (a domain service class that doesn't appear to exist in the domain model), creating tight coupling.
- `SecurityService` uses `HttpContext.Current.Session` � this is not unit-testable and will not work outside of ASP.NET Framework's `System.Web`.
- **Action:** Enforce strict layer boundaries. Move session abstraction behind an `ISessionProvider` interface. Remove UI references from Infrastructure.

### 5.2 Multiple Redundant UnityConfig Files

- There are **at least 4 copies** of `UnityConfig.cs` across `OpenSafetyDependancyResolver`, `OpenSafetyCrossCutting`, `OpenSafetyContract`, and `OpenSafetyDistributedService` � three of which are empty stubs.
- **Action:** Consolidate to one DI registration entry point using `IServiceCollection` extensions per project.

### 5.3 Windows Service Background Job

- `WsAsynchronousSilicoState` is a Windows Service using `System.ServiceProcess.ServiceBase` � not supported on .NET 8 without `Microsoft.Extensions.Hosting.WindowsServices`.
- Uses a `System.Timers.Timer` for job scheduling rather than a proper hosted service pattern.
- **Action:** Convert to `IHostedService` / `BackgroundService` using `Microsoft.Extensions.Hosting`, optionally with **Quartz.NET** or **Hangfire** for scheduling.

### 5.4 Repository Pattern Anti-patterns

- `IRepository<TEntity>` in the domain uses `ISpecification<TEntity>` but the implementations (`EFDicoRepository`) do not implement this interface � the specification pattern is defined but never used.
- `GenericRepository<T>` creates its own `new OpenSafetyDBContext()` � bypassing the injected `EFUnitOfWork`'s context, making the Unit of Work pattern **ineffective** (two separate DbContexts per operation).
- **Action:** Inject `DbContext` into repositories (not instantiate it). Align `UnitOfWork` and `Repository` on the same `DbContext` instance.

---

## 6. Code Quality Issues

### 6.1 Naming & Typos

- Project folder: `OPenSafetyInfrastructure` (inconsistent casing), `OpenSafetyFrontedApplication` (typo: "Fronted" instead of "Frontend").
- Class: `OpenSafetyDependancyResolver` (typo: "Dependancy" instead of "Dependency").
- Repository folder: `Reposistories` (double typo: "Reposistories").
- Variable: `_dicoRepositoiry` (typo in `DicoApplicationService`).
- Comment: `/// <r�sum�>` and `</ summary>` (malformed XML doc comments mixing French and English, broken closing tag syntax).

### 6.2 Commented-Out Code

- **56 out of 578** `.cs` files contain commented-out code blocks (dead code). Examples: entire `UseUnity` extension method commented out in `UnityConfig`, large `Pagination` test method commented out, route registrations commented out.
- **Action:** Remove all dead code � it exists in git history if recovery is needed.

### 6.3 Mixed Language (French/English)

- Error messages, comments, XML doc tags, log messages, and variable names are inconsistently in French and English throughout all layers.
- French hardcoded strings in exception messages (e.g., `"Vous n'avez pas acc�s � cette application"`) create maintenance and internationalisation challenges.
- **Action:** Adopt a single language (English) for code, comments, and log messages. Externalise user-facing strings to `.resx` resource files (already partially done in `App_GlobalResources`).

### 6.4 LINQ Anti-patterns

- Multiple LINQ queries call `.ToList()` before filtering, materialising **entire database tables** into memory (e.g., `_context.BlocColonnes.ToList()`, `_context.BlocVersions.ToList()` joined in C# memory).
- This is a **severe N+1 / memory explosion risk** at scale.
- **Action:** Compose LINQ queries as `IQueryable<T>` and call `.ToList()` / `.ToListAsync()` only at the terminal materialisation point, allowing EF to generate a single SQL JOIN.

### 6.5 Static Configuration Access

- All services read `ConfigurationManager.AppSettings[...]` as static `readonly` fields at class-load time (not injectable).
- No `IOptions<T>` pattern is used.
- **Action:** Use `IOptions<T>` / `IConfiguration` injected via DI for all configuration values.

---

## 7. Testing Coverage

| Metric | State |
|---|---|
| Test projects | 2 (`OpenSafetyDistributedService.Tests`, `OpenSafetyFrontend.Tests`) |
| Active test methods | ~3 (others commented out or trivially asserting `IsNotNull`) |
| Test framework | MSTest (no Moq, no FluentAssertions) |
| Integration tests | 0 |
| Unit tests | 0 meaningful |
| Code coverage | ~0% |

- **Action:** Introduce **xUnit** (or NUnit), **Moq** for mocking, and **FluentAssertions**. Start with unit tests on Application services and domain logic, then integration tests using `WebApplicationFactory<T>` for API endpoints.

---

## 8. Security Issues

| Issue | Severity | Location |
|---|---|---|
| Plaintext DB password in committed `Web.config` | ?? Critical | `OpenSafetyDistributedService\Web.config` |
| Plaintext app password (`OPSty!4Pit#18`) committed | ?? Critical | `OpenSafetyDistributedService\Web.config` |
| Windows Authentication over `webHttpBinding` (WCF REST) | ?? Medium | `Web.config` bindings |
| Session-based role storage (`HttpContext.Current.Session["isRole"]`) � no CSRF protection | ?? Medium | `SecurityService.cs` |
| `TrustServerCertificate=False` in dev but no certificate validation hardening | ?? Low | Connection string |
| `customErrors mode="Off"` exposes stack traces in production | ?? Medium | `Web.config` |

---

## 9. Dependencies Needing Upgrade

| Package | Current Version | Latest | Notes |
|---|---|---|---|
| `Newtonsoft.Json` | 6.0.4 � 12.0.3 (mixed) | 13.x | Inconsistent across projects |
| `AutoMapper` | 5.1.1 | 13.x | Breaking changes in v6+; profile-based API changed |
| `NEST` / `Elasticsearch.Net` | 6.1.0 | 8.x (NEST deprecated ? `Elastic.Clients.Elasticsearch`) | Major API overhaul |
| `EntityFramework` | 6.1.3 | ? EF Core 8 | Platform migration required |
| `Unity` | 5.2.1 / 5.11.6 | ? `Microsoft.Extensions.DependencyInjection` | Unity unmaintained |
| `log4net` | 2.0.5 � 2.0.8 | ? `Microsoft.Extensions.Logging` + Serilog/NLog | Modernise logging |
| Bootstrap | 3.3.7 (Frontend) | 5.x | v3 EOL; major UI API changes |
| jQuery | 1.10.2 � 3.3.1 (mixed) | 3.7.x | CVEs in older versions |
| `Swashbuckle` | 6.0.0-rc1-final | ? `Swashbuckle.AspNetCore` 6.x | Wrong package for ASP.NET Core |
| `Microsoft.AspNet.Mvc` | 5.2.3 � 5.2.7 | ? ASP.NET Core 8 MVC | Platform migration |

---

## 10. Modernization Roadmap (Recommended Phases)

### Phase 1 � Security & Hygiene (Immediate, 1�2 weeks)

1. **Rotate all exposed credentials** immediately.
2. Add `Web.config` (with secrets) to `.gitignore`; use only placeholder config committed.
3. Move all secrets to **Azure Key Vault** references.
4. Remove `customErrors mode="Off"` from production transforms.
5. Clean up all commented-out dead code blocks.

### Phase 2 � Infrastructure Modernisation (4�6 weeks)

1. Migrate all projects to **.NET 8**.
2. Replace **EF 6** with **EF Core 8**; fix LINQ-to-SQL queries (remove `.ToList()` before filters).
3. Replace **Unity** with `Microsoft.Extensions.DependencyInjection`.
4. Replace `ConfigurationManager` with `IConfiguration` / `IOptions<T>`.
5. Replace `log4net` with `Microsoft.Extensions.Logging` + **Serilog**.
6. Enable `<Nullable>enable</Nullable>` and fix null-safety warnings.

### Phase 3 � Service Layer Migration (6�8 weeks)

1. Replace all **8 WCF services** with **ASP.NET Core Minimal API** or Web API controllers.
2. Remove all `System.ServiceModel` client proxies from the frontend; replace with typed `HttpClient` via `IHttpClientFactory`.
3. Fix the `HttpClient` instantiation anti-pattern (socket exhaustion).
4. Convert all synchronous I/O to `async`/`await`.

### Phase 4 � Architecture Clean-up (4�6 weeks)

1. Fix Repository/UnitOfWork to share a single `DbContext` instance.
2. Remove `OpenSafetyFrontend` dependency from `GenericRepository` (Infrastructure layer).
3. Decouple `SecurityService` from `HttpContext.Current` via `IHttpContextAccessor`.
4. Consolidate to one DI registration entry point per bounded context.
5. Convert `WsAsynchronousSilicoState` to `IHostedService` / `BackgroundService`.

### Phase 5 � Quality & Testing (Ongoing)

1. Introduce **xUnit**, **Moq**, and **FluentAssertions**.
2. Write unit tests for Application services (domain logic).
3. Write integration tests with `WebApplicationFactory<T>`.
4. Set up a code coverage gate in Jenkins CI (? 60% target).
5. Upgrade frontend dependencies (Bootstrap 5, jQuery 3.7).

---

## 11. Estimated Effort Summary

| Phase | Effort | Risk |
|---|---|---|
| Phase 1 � Security | 1�2 weeks | ?? High impact if delayed |
| Phase 2 � Infrastructure | 4�6 weeks | ?? Medium � well-understood migration path |
| Phase 3 � WCF ? API | 6�8 weeks | ?? High � largest scope, touches all consumers |
| Phase 4 � Architecture | 4�6 weeks | ?? Medium |
| Phase 5 � Testing | Ongoing | ?? Low risk, high long-term return |

> **Total estimated effort: ~15�22 developer-weeks** for a full modernisation to a production-quality .NET 8 application.
