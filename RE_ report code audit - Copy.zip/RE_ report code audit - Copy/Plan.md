# OpenSafety � .NET 8 Migration Execution Plan

> **Source documents:** `Upgrade_report.md` � `answers.md` � `Audit.md`
> **Target:** .NET 8 LTS across all 18 projects
> **Strategy:** Strangler Fig � new .NET 8 API runs in parallel with WCF during transition
> **Branch:** `feature/dotnet8-migration`

---

## Quick-Reference Summary

| | |
|---|---|
| Total phases | 7 |
| Total sprints | 11 |
| Total estimated effort | **~92 developer-days** |
| Parallel-track option | **~55 developer-days** (2 devs) |
| Calendar time (1 dev) | ~22 weeks |
| Calendar time (2 devs, parallel) | ~12�14 weeks |
| Projects to remove | 4 stubs |
| Projects to migrate | 12 active |
| Projects to create | 0 (in-place migration) |
| `.cs` files affected by incompatible APIs | 225 / 578 (39%) |
| Razor views to update | 119 |
| WCF services to replace | 8 |
| EF6 migrations to recreate | 14 (? 1 EF Core baseline) |

---

## Dependency Build Order (must be respected)

```
Layer 0 ??? OpenSafetyCrossCutting
Layer 1 ??? OpenSafetyDomainModel          (? CrossCutting)
Layer 2 ??? OpenSafetyContract             (? CrossCutting, DomainModel)
Layer 3 ??? OPenSafetyInfrastructure       (? CrossCutting, DomainModel)
Layer 4 ??? OpenSafetyApplication          (? Contract, CrossCutting, DomainModel)
Layer 5 ??? OpenSafetyDistributedService   (? Application, Contract, CrossCutting, DomainModel, Infrastructure)
Layer 5 ??? OpenSafetyFrontend             (? Application, Contract, CrossCutting, DomainModel, Infrastructure)
Layer 6 ??? WsAsynchronousSilicoState      (? HTTP calls to DistributedService only)
Layer 6 ??? Test projects                  (? respective host projects)
```

> ?? `OPenSafetyInfrastructure` currently has an **illegal upward reference** to `OpenSafetyFrontend`. This must be fixed in Phase 0 before any other step.

---

## Phase 0 � Pre-Migration Preparation

> **Duration:** Sprint 0 (1 week) � **Effort:** 5 days � **Risk:** ?? credential rotation is urgent

### Goals
- Establish a safe working baseline
- Remove all dead code and stubs to reduce noise
- Fix the layer violation that blocks compilation order
- Secure credentials that are currently committed to source control

---

### Sprint 0 � Week 1

#### S0-T1 � Environment Setup (0.5 day)

```bash
# Install required tooling
winget install Microsoft.DotNet.SDK.8
dotnet tool install -g upgrade-assistant
dotnet tool install -g dotnet-ef

# Create migration branch
git checkout -b feature/dotnet8-migration

# Baseline snapshot
git tag pre-migration-baseline
```

**Verify:**
```bash
dotnet --version        # must be 8.x.x
upgrade-assistant --version
dotnet ef --version
```

---

#### S0-T2 � Credential Rotation ?? URGENT (0.5 day)

`OpenSafetyDistributedService/Web.config` contains a plaintext database password and application password committed to `git`.

```
Actions:
1. Rotate the database password (coordinate with DBA)
2. Rotate the application password
3. Add Web.config to .gitignore (keep only Web.config.template with placeholders)
4. Rewrite git history to remove the credential from all commits:
   git filter-branch or BFG Repo Cleaner
5. Force-push to origin after team notification
6. Store real secrets in Azure Key Vault (configure in Phase 3)
```

---

#### S0-T3 � Fix Layer Violation: Infrastructure ? Frontend (1 day)

`OPenSafetyInfrastructure` has a `ProjectReference` to `OpenSafetyFrontend` inside `GenericRepository.cs` � a downward dependency violation.

```
Root cause:
  GenericRepository imports OpenSafetyFrontend.ServiceAdmin.BlocColonneDTO

Fix steps:
1. Locate all usages of OpenSafetyFrontend.ServiceAdmin.* in OPenSafetyInfrastructure
2. Move BlocColonneDTO (and any other shared DTOs) to OpenSafetyContract
3. Update using directives in GenericRepository.cs
4. Remove <ProjectReference Include="..\OpenSafetyFrontend\..."> from OpenSafetyInfrastructure.csproj
5. Verify the solution builds (with legacy .NET FW) before proceeding
```

---

#### S0-T4 � Remove Stub / Dead Projects (1 day)

Remove the 4 stub projects from the solution. They add noise and their `.NET FW 4.5.2` targets block `upgrade-assistant` analysis.

| Project | Reason for Removal |
|---|---|
| `WebFrontendTest` | Scaffold stub � only WCF proxy references, no logic |
| `OpenSafetyFrontedApplication` | Empty MVC stub, targets obsolete .NET FW 4.5.2 |
| `Fronted.Tests` | Empty `static void Main`, targets obsolete .NET FW 4.5.2 |
| `WebApiOpenSafety` | Default Web API scaffold � `ValuesController` only, never extended |

```bash
# For each project:
# 1. Right-click ? Remove from solution (Visual Studio)
# 2. Delete the project directory from disk
# 3. Commit: git commit -m "chore: remove stub projects"
```

---

#### S0-T5 � Delete Duplicate / Dead Files (1 day)

Remove all confirmed dead code **before** migrating projects so that migration tools don't process them.

| Files to Delete | Count | Location |
|---|---|---|
| Stub `UnityConfig.cs` (empty) | 7 copies | Application, Contract, CrossCutting, DependancyResolver/App_Start, DistributedService, DomainModel, Infrastructure |
| Duplicate `FilterConfig.cs` | 4 copies | Application, Contract, CrossCutting, DependancyResolver |
| Duplicate `RouteConfig.cs` | 4 copies | Application, Contract, CrossCutting, DependancyResolver |
| `SimpleJson.cs` (2,127-line embedded JSON parser) | 1 | CrossCutting |
| Duplicate `UnauthorizedException.cs` | 1 copy | Remove the copy in Application; keep CrossCutting |
| Duplicate `AutoMapperConfig.cs` | 1 copy | Remove the Application copy; keep Frontend/Admin one as the base |
| `ConsoleTest/System/Web/HttpContext.cs` | 1 | Fake `System.Web` stub |

```bash
git commit -m "chore: remove dead code, stubs and duplicate config files"
```

---

#### S0-T6 � Run Upgrade Assistant Analysis (1 day)

```bash
upgrade-assistant analyze OpenSafety.sln --output upgrade-analysis.html
```

Review the output � it will flag all known incompatibilities. Cross-reference with `answers.md �18`. This becomes the authoritative checklist for Phases 1�4.

---

#### S0 � Exit Criteria

- [ ] `.NET 8 SDK` and tooling installed and verified
- [ ] Credentials rotated; `Web.config` with secrets removed from git history
- [ ] Layer violation (`Infrastructure ? Frontend`) resolved; solution builds cleanly on .NET FW
- [ ] 4 stub projects removed from solution and disk
- [ ] Dead files deleted
- [ ] `upgrade-assistant analyze` report produced with no blocker-level errors
- [ ] `git tag phase0-complete`

---

## Phase 1 � Foundation Libraries

> **Duration:** Sprint 1�2 (2 weeks) � **Effort:** 6 days � **Risk:** ?? Low

### Goals
Migrate the bottom 3 layers (CrossCutting, DomainModel, Contract) to `net8.0`. These have zero or minimal web-framework dependencies. All other projects depend on them � they must compile on .NET 8 first.

**Approach per project:**
1. Convert `.csproj` to SDK-style format
2. Set `<TargetFramework>net8.0</TargetFramework>`
3. Delete `packages.config`; convert to `<PackageReference>`
4. Delete `Properties/AssemblyInfo.cs` (auto-generated by SDK)
5. Fix breaking-change compiler errors
6. Run `dotnet build` � must be green before proceeding

---

### Sprint 1 � Weeks 2�3

#### S1-T1 � Migrate `OpenSafetyCrossCutting` (3 days)

**Complexity: LOW**

```xml
<!-- New OpenSafetyCrossCutting.csproj -->
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="ClosedXML" Version="0.102.2" />
    <PackageReference Include="DocumentFormat.OpenXml" Version="3.1.0" />
    <PackageReference Include="MailKit" Version="4.7.1" />
    <PackageReference Include="Microsoft.AspNetCore.Http.Abstractions" Version="2.2.0" />
    <PackageReference Include="Microsoft.Extensions.Caching.Memory" Version="8.0.1" />
    <PackageReference Include="Microsoft.Extensions.Logging.Abstractions" Version="8.0.2" />
    <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
  </ItemGroup>
</Project>
```

**File-level changes:**

| File | Change |
|---|---|
| `Class/GenerateCsvFile.cs` | Remove `System.Web.HttpContext.Current.Response`; inject `IHttpContextAccessor` via constructor; extract `WriteFileToResponse(IHttpContextAccessor)` |
| `Class/OpsEmailSender.cs` | Replace `System.Net.Mail.SmtpClient` with `MailKit.Net.Smtp.SmtpClient` |
| `Class/CacheManager.cs` | Replace `System.Runtime.Caching.MemoryCache` with `IMemoryCache`; change to instance-based injection |
| All files using `log4net` | Replace `private static readonly ILog _log = LogManager.GetLogger(typeof(T))` ? constructor-injected `ILogger<T> _logger` |
| `App_Start/UnityConfig.cs` | **Delete** |
| `SimpleJson.cs` | **Already deleted in Phase 0** |

**Verify:** `dotnet build OpenSafetyCrossCutting` ? 0 errors

---

#### S1-T2 � Migrate `OpenSafetyDomainModel` (1 day)

**Complexity: LOW**

```xml
<!-- New OpenSafetyDomainModel.csproj -->
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
  </ItemGroup>
  <ItemGroup>
    <ProjectReference Include="..\OpenSafetyCrossCutting\OpenSafetyCrossCutting.csproj" />
  </ItemGroup>
</Project>
```

**File-level changes:**

| File | Change |
|---|---|
| `App_Start/UnityConfig.cs` | **Delete** |
| `BlocDico/IRepository.cs` | **Delete** (unused specification-based interface) |
| `BlocDico/DicoDomainSpecification.cs` | **Delete** (never implemented) |
| All entity classes | Add `<Nullable>enable</Nullable>` � fix nullable reference warnings |

**Verify:** `dotnet build OpenSafetyDomainModel` ? 0 errors

---

#### S1-T3 � Migrate `OpenSafetyContract` (2 days)

**Complexity: MEDIUM** � WCF attribute removal

```xml
<!-- New OpenSafetyContract.csproj -->
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
  </ItemGroup>
  <ItemGroup>
    <ProjectReference Include="..\OpenSafetyCrossCutting\OpenSafetyCrossCutting.csproj" />
    <ProjectReference Include="..\OpenSafetyDomainModel\OpenSafetyDomainModel.csproj" />
  </ItemGroup>
</Project>
```

**File-level changes � strip all WCF annotations from 9 service interfaces:**

| Interface | Attributes to Remove |
|---|---|
| `IDicoService.cs` | `[ServiceContract]`, all `[OperationContract]`, all `[WebGet]`, all `using System.ServiceModel.*` |
| `IAdminService.cs` | Same pattern |
| `IAcquisitionService.cs` | Same pattern |
| `IDataService.cs` | Same pattern |
| `ICosmetochemService.cs` | Same pattern |
| `IMDMService.cs` | Same pattern |
| `IMpnetService.cs` | Same pattern |
| `ISynonymsService.cs` | Same pattern |
| `ISecurityService.cs` | Has no WCF attributes � no change needed |
| `App_Start/UnityConfig.cs` | **Delete** |

> All 93 DTO classes (`*DTO.cs`) require **no changes** � they are plain C# POCOs.

**Verify:** `dotnet build OpenSafetyContract` ? 0 errors

---

#### S1 � Exit Criteria

- [ ] `OpenSafetyCrossCutting` builds on `net8.0` with 0 errors
- [ ] `OpenSafetyDomainModel` builds on `net8.0` with 0 errors
- [ ] `OpenSafetyContract` builds on `net8.0` with 0 errors � no `System.ServiceModel` reference remains
- [ ] All 3 `packages.config` files deleted
- [ ] `git tag phase1-complete`

---

## Phase 2 � Infrastructure & Application

> **Duration:** Sprint 3�5 (3 weeks) � **Effort:** 17 days � **Risk:** ?? High (EF Core migration, ES client rewrite)

### Goals
Migrate the data access layer (EF Core 8, Elasticsearch 8) and the application service layer (AutoMapper 13, ILogger, IConfiguration). These layers contain the most technically complex breaking changes.

---

### Sprint 2 � Weeks 4�6

#### S2-T1 � Migrate `OPenSafetyInfrastructure` � Part A: Project & EF Core (5 days)

**Complexity: HIGH**

```xml
<!-- New OpenSafetyInfrastructure.csproj -->
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Elastic.Clients.Elasticsearch" Version="8.14.6" />
    <PackageReference Include="Microsoft.EntityFrameworkCore" Version="8.0.8" />
    <PackageReference Include="Microsoft.EntityFrameworkCore.SqlServer" Version="8.0.8" />
    <PackageReference Include="Microsoft.EntityFrameworkCore.Proxies" Version="8.0.8" />
    <PackageReference Include="Microsoft.EntityFrameworkCore.Tools" Version="8.0.8">
      <IncludeAssets>runtime; build; native; contentfiles; analyzers; buildtransitive</IncludeAssets>
      <PrivateAssets>all</PrivateAssets>
    </PackageReference>
    <PackageReference Include="Microsoft.Extensions.Http" Version="8.0.1" />
    <PackageReference Include="Microsoft.Extensions.Logging.Abstractions" Version="8.0.2" />
    <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
  </ItemGroup>
  <ItemGroup>
    <ProjectReference Include="..\OpenSafetyCrossCutting\OpenSafetyCrossCutting.csproj" />
    <ProjectReference Include="..\OpenSafetyDomainModel\OpenSafetyDomainModel.csproj" />
  </ItemGroup>
</Project>
```

**EF6 ? EF Core 8 � File-level changes:**

| File | Change |
|---|---|
| `OpenSafetyDBContext.cs` | Replace `DbContext(string connStr)` constructor with `DbContext(DbContextOptions<T> options)`; replace `DbModelBuilder` ? `ModelBuilder`; replace `modelBuilder.Configurations.Add(new X())` ? `modelBuilder.ApplyConfiguration(new X())`; remove `this.Configuration.*` properties; add `UseLazyLoadingProxies()` option |
| All 31 `*ETC.cs` files | Change base class from `EntityTypeConfiguration<T>` ? implement `IEntityTypeConfiguration<T>`; rename `this.ToTable()` ? `builder.ToTable()`; rename `this.HasKey()` ? `builder.HasKey()`; rename `this.Property().HasDatabaseGeneratedOption(...)` ? `builder.Property().ValueGeneratedOnAdd()`|
| `Migrations/Configuration.cs` | **Delete** |
| All 14 `*_Migration.cs` + 14 `*.Designer.cs` | **Delete all** � replaced by single new EF Core migration |
| `GenericRepository.cs` | Inject `OpenSafetyDBContext` via constructor (remove `new OpenSafetyDBContext()`); replace `_context.Entry(entity).State = EntityState.Modified` with EF Core equivalent |
| `EFUnitOfWork.cs` | Inject `OpenSafetyDBContext` via constructor |
| `EFDicoRepository.cs` | Inject `OpenSafetyDBContext` via constructor; replace `NotImplementedException` stubs; fix LINQ-to-SQL patterns (remove `.ToList()` before filter) |
| `EFDataRepository.cs` | Inject `OpenSafetyDBContext`; async-ify queries using `ToListAsync()`, `FirstOrDefaultAsync()` |

**Generate new EF Core baseline migration:**
```bash
# Step 1: Ensure the production DB is the current baseline
# Step 2: Create new startup project reference
dotnet ef migrations add InitialCreate \
  --project OPenSafetyInfrastructure \
  --startup-project OpenSafetyDistributedService \
  --output-dir Data/EF/DicoDB/Migrations

# Step 3: Validate generated migration matches production schema
# (use SQL schema diff tool or dbcontext scaffold against prod DB)

# Step 4: Apply to dev DB
dotnet ef database update \
  --project OPenSafetyInfrastructure \
  --startup-project OpenSafetyDistributedService
```

---

#### S2-T2 � Migrate `OPenSafetyInfrastructure` � Part B: Elasticsearch & HTTP Clients (5 days)

**NEST 6 ? `Elastic.Clients.Elasticsearch` 8 rewrite (`WebApiElasticSearch.cs`, 2,132 lines):**

| Old NEST 6 API | New Elastic.Clients.Elasticsearch 8 API |
|---|---|
| `new ConnectionSettings(new Uri(host))` | `new ElasticsearchClientSettings(new Uri(host))` |
| `client.Search<T>(s => s.Query(...))` | `await client.SearchAsync<T>(s => s.Query(...))` |
| `client.Index(doc, i => i.Index("name"))` | `await client.IndexAsync(doc, i => i.Index("name"))` |
| `client.Bulk(b => b.Index<T>(...))` | `await client.BulkAsync(b => b.Index<T>(...))` |
| `response.Documents` | `response.Documents` (same) |
| `response.IsValid` | `response.IsSuccess()` |

**Replace ASMX Web Reference for MDM (`WSMdmRepository.cs`):**
```
1. Delete OPenSafetyInfrastructure/Web References/MdmWS/ (entire folder)
2. Rewrite WSMdmRepository to use IHttpClientFactory:
   - Constructor accepts HttpClient (injected via AddHttpClient<WSMdmRepository>())
   - Replace WebService proxy calls with HttpClient.GetFromJsonAsync<T>()
   - Replace .Result blocking calls with await
```

**Fix `HttpClient` anti-patterns (13 files with `new HttpClient`):**
```
In WSSynonymsRepository.cs, WSCosmetochemRepository.cs, WebApiMpnetRepository.cs:
- Remove: using (var handler = new HttpClientHandler()) { using (var client = new HttpClient(handler))
- Remove: handler.MaxRequestContentBufferSize = int.MaxValue  (removed in .NET 5)
- Add constructor injection: private readonly HttpClient _client
- Register: builder.Services.AddHttpClient<WSCosmetochemRepository>()
```

**Replace `log4net` and `ConfigurationManager` across all infrastructure files:**
```
- 'private static readonly ILog _log = LogManager.GetLogger(...)' 
  ? private readonly ILogger<T> _logger (constructor injected)
- ConfigurationManager.AppSettings["key"] 
  ? private readonly string _key; injected via IConfiguration in constructor
- static readonly fields reading AppSettings 
  ? constructor parameters from IConfiguration
```

**Verify:** `dotnet build OPenSafetyInfrastructure` ? 0 errors

---

### Sprint 3 � Weeks 7�8

#### S2-T3 � Migrate `OpenSafetyApplication` (4 days)

**Complexity: MEDIUM**

```xml
<!-- New OpenSafetyApplication.csproj -->
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="AutoMapper" Version="13.0.1" />
    <PackageReference Include="AutoMapper.Extensions.Microsoft.DependencyInjection" Version="12.0.1" />
    <PackageReference Include="Microsoft.AspNetCore.Http.Abstractions" Version="2.2.0" />
    <PackageReference Include="Microsoft.Extensions.Logging.Abstractions" Version="8.0.2" />
    <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
  </ItemGroup>
  <ItemGroup>
    <ProjectReference Include="..\OpenSafetyContract\OpenSafetyContract.csproj" />
    <ProjectReference Include="..\OpenSafetyCrossCutting\OpenSafetyCrossCutting.csproj" />
    <ProjectReference Include="..\OpenSafetyDomainModel\OpenSafetyDomainModel.csproj" />
  </ItemGroup>
</Project>
```

**File-level changes:**

| File | Change |
|---|---|
| `Security/SecurityService.cs` | Remove `using System.Web`; inject `IHttpContextAccessor`; replace `HttpContext.Current.Session["isRole"]` ? `_httpContextAccessor.HttpContext?.Session.GetString("isRole")`; replace `Session["LoginNT"]` and `Session["Domain"]` the same way |
| `BlocDico/Services/AutoMapperConfig.cs` | Remove static `Mapper.Initialize(cfg => ...)` call; create typed `Profile` classes; register via `services.AddAutoMapper(typeof(DicoApplicationService).Assembly)` in `Program.cs` |
| All `*ApplicationService.cs` files | Replace `private static readonly ILog _log = LogManager.GetLogger(typeof(T))` ? `ILogger<T> _logger` constructor injected; replace all `_log.*` calls |
| All `*ApplicationService.cs` files | Replace `ConfigurationManager.AppSettings["key"]` ? constructor-injected `IConfiguration _configuration`; use `_configuration["key"]` |
| `App_Start/UnityConfig.cs` | **Already deleted in Phase 0** |

**AutoMapper 5 ? 13 migration checklist (15 files affected):**
```
Before (AutoMapper 5, static):
  Mapper.Initialize(cfg => {
      cfg.CreateMap<BlocDTO, Bloc>();
  });
  var result = Mapper.Map<Bloc>(dto);

After (AutoMapper 13, DI-based):
  // In a Profile class:
  public class DicoProfile : Profile {
      public DicoProfile() {
          CreateMap<BlocDTO, Bloc>();
      }
  }
  // In Program.cs:
  services.AddAutoMapper(typeof(DicoProfile).Assembly);
  // In service constructor:
  private readonly IMapper _mapper;
  public DicoApplicationService(IMapper mapper, ...) { _mapper = mapper; }
  var result = _mapper.Map<Bloc>(dto);
```

**Verify:** `dotnet build OpenSafetyApplication` ? 0 errors

---

#### S2 � Exit Criteria

- [ ] `OPenSafetyInfrastructure` builds on `net8.0` � no `System.Data.Entity`, `NEST`, `System.Web` references
- [ ] New EF Core `InitialCreate` migration generated and validated against production schema
- [ ] `WebApiElasticSearch.cs` rewritten with `Elastic.Clients.Elasticsearch` 8 client
- [ ] `WSMdmRepository.cs` rewritten with `IHttpClientFactory`; ASMX proxy deleted
- [ ] `OpenSafetyApplication` builds on `net8.0` � no `System.Web`, `log4net`, `ConfigurationManager` static usage
- [ ] All `new HttpClient(handler)` anti-patterns eliminated (replaced by injection)
- [ ] All `.Result` blocking calls converted to `await`
- [ ] `git tag phase2-complete`

---

## Phase 3 � API Host: WCF ? ASP.NET Core 8 Web API

> **Duration:** Sprint 4�5 (2 weeks) � **Effort:** 16 days � **Risk:** ?? Highest � consumer impact

### Goals
Replace all 8 WCF services with ASP.NET Core Web API controllers. Deploy the new REST API alongside the existing WCF endpoints (Strangler Fig). Dissolve `OpenSafetyDependancyResolver` project.

---

### Sprint 4 � Weeks 9�10

#### S3-T1 � Dissolve `OpenSafetyDependancyResolver` (1 day)

This project contains only Unity DI wiring. Its content moves into `Program.cs` of `OpenSafetyDistributedService`.

```
1. Open OpenSafetyDependancyResolver\UnityConfig.cs
2. For each container.RegisterType<I, T>():
   Translate to services.AddScoped<I, T>() in the new Program.cs (see S3-T2)
3. Remove OpenSafetyDependancyResolver from OpenSafetyDistributedService.csproj references
4. Delete the project from solution and disk
```

---

#### S3-T2 � Create `Program.cs` for `OpenSafetyDistributedService` (2 days)

```csharp
// OpenSafetyDistributedService/Program.cs
using Microsoft.AspNetCore.Authentication.Negotiate;
using Microsoft.EntityFrameworkCore;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// Serilog
builder.Host.UseSerilog((ctx, cfg) => cfg
    .ReadFrom.Configuration(ctx.Configuration)
    .Enrich.FromLogContext()
    .WriteTo.Console()
    .WriteTo.File("logs/api-.log", rollingInterval: RollingInterval.Day));

// Database
builder.Services.AddDbContext<OpenSafetyDBContext>(opt =>
    opt.UseSqlServer(builder.Configuration.GetConnectionString("OpenSafetyDBContext"))
       .UseLazyLoadingProxies());

// Cache & Session
builder.Services.AddMemoryCache();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(opt => opt.IdleTimeout = TimeSpan.FromHours(8));
builder.Services.AddHttpContextAccessor();

// Repositories
builder.Services.AddScoped<IDicoRepository, EFDicoRepository>();
builder.Services.AddScoped<IAcquisitionRepository, EFDicoRepository>();
builder.Services.AddScoped<IDataSourceRepository, EFDataRepository>();
builder.Services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));
builder.Services.AddScoped<IUnitOfWork, EFUnitOfWork>();

// External API clients
builder.Services.AddHttpClient<WSMdmRepository>();
builder.Services.AddHttpClient<WSCosmetochemRepository>();
builder.Services.AddHttpClient<WSSynonymsRepository>();
builder.Services.AddHttpClient<WebApiMpnetRepository>();
builder.Services.AddScoped<IMdmRepository, WSMdmRepository>();
builder.Services.AddScoped<ICosmetochemRepository, WSCosmetochemRepository>();
builder.Services.AddScoped<ISynonymsRepository, WSSynonymsRepository>();
builder.Services.AddScoped<IMpnetRepository, WebApiMpnetRepository>();
builder.Services.AddScoped<IDataRepository, WebApiElasticSearch>();

// Application Services
builder.Services.AddScoped<IDicoService, DicoApplicationService>();
builder.Services.AddScoped<IAdminService, AdminApplicationService>();
builder.Services.AddScoped<IAcquisitionService, AcquisitionApplicationService>();
builder.Services.AddScoped<IDataService, DataApplicationService>();
builder.Services.AddScoped<ICosmetochemService, CosmetochemApplicationService>();
builder.Services.AddScoped<IMDMService, MdmApplicationService>();
builder.Services.AddScoped<IMpnetService, MpnetApplicationService>();
builder.Services.AddScoped<ISynonymsService, SynonymsApplicationService>();
builder.Services.AddScoped<ISecurityService, SecurityService>();

// AutoMapper
builder.Services.AddAutoMapper(typeof(DicoApplicationService).Assembly);

// Authentication � Windows Auth (Kerberos/NTLM)
builder.Services.AddAuthentication(NegotiateDefaults.AuthenticationScheme).AddNegotiate();
builder.Services.AddAuthorization();

// ASP.NET Core + Swagger
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
    c.SwaggerDoc("v1", new() { Title = "OpenSafety API", Version = "v1" }));

var app = builder.Build();

// DB migration at startup
using (var scope = app.Services.CreateScope())
    scope.ServiceProvider.GetRequiredService<OpenSafetyDBContext>().Database.Migrate();

app.UseSwagger();
app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "OpenSafety API v1"));
app.UseSession();
app.UseAuthentication();
app.UseAuthorization();
app.UseExceptionHandler("/error");
app.MapControllers();
app.Run();
```

---

#### S3-T3 � Create `appsettings.json` for API (0.5 day)

```json
{
  "ConnectionStrings": {
    "OpenSafetyDBContext": "USE-AZURE-KEY-VAULT-IN-PRODUCTION"
  },
  "Endpoints": {
    "ElasticSearch": "http://elk-host:9200",
    "IndexElasticSearch": "opensafety_data",
    "HttpEndPointAddressMdm": "https://mdm-host/api",
    "HttpEndPointAddressCosmetochem": "https://cosmetochem-host/api",
    "HttpEndPointAddressMpnet": "https://mpnet-host/api",
    "HttpEndPointAddressSynonyms": "https://synonyms-host/api",
    "CosmetochemAnalyze": "https://cosmetochem-host/api/AnalyzeSilicoResult"
  },
  "AppSettings": {
    "OST_ADMIN": "OST_ADMIN",
    "OST_USER": "OST_USER",
    "DataExportPageSize": "500",
    "environnementTravail": "DEV"
  },
  "Logging": {
    "LogLevel": { "Default": "Information", "Microsoft.AspNetCore": "Warning" }
  },
  "Serilog": {
    "MinimumLevel": { "Default": "Information" },
    "WriteTo": [{ "Name": "Console" }, { "Name": "File", "Args": { "path": "logs/api-.log", "rollingInterval": "Day" } }]
  }
}
```

---

### Sprint 5 � Weeks 11�12

#### S3-T4 � Create 8 ASP.NET Core Controllers (8 days)

One controller per former WCF service. Full mapping of WCF `[WebGet(UriTemplate=...)]` routes to `[HttpGet("{param}")]`:

| WCF Service | New Controller | Route Prefix | Methods |
|---|---|---|---|
| `OpenSafetyDicoWCFService` | `DicoController` | `api/dico` | GetAllSource, GetSource, CreateSource, UpdateSource, GetBloc, GetAllBlocs, � |
| `OpenSafetyAdminWCFService` | `AdminController` | `api/admin` | All bloc/version/colonne CRUD methods |
| `OpenSafetyAcquisitionWCFService` | `AcquisitionController` | `api/acquisition` | GetJobs, CreateJob, UpdateDataAcquisition, � |
| `OpenSafetyDataWCFService` | `DataController` | `api/data` | SearchData, GetDataBySource, ExportData, � |
| `OpenSafetyCosmetochemWCFService` | `CosmetochemController` | `api/cosmetochem` | SearchCosmetochem, AnalyzeSilicoResult, � |
| `OpenSafetyMdmWCFService` | `MdmController` | `api/mdm` | GetUserProfile, GetUserRoles, � |
| `OpenSafetyMpnetWCFService` | `MpnetController` | `api/mpnet` | GetIngredients, SearchMpnet, � |
| `OpenSafetySynonymsWCFService` | `SynonymsController` | `api/synonyms` | GetSynonyms, SearchSynonyms, � |

**Pattern for each controller:**
```csharp
// Replace: OpenSafetyDicoWCFService.svc.cs
// With:    DicoController.cs

[ApiController]
[Route("api/dico")]
[Authorize]
public class DicoController : ControllerBase
{
    private readonly IDicoService _dicoService;
    private readonly ILogger<DicoController> _logger;

    public DicoController(IDicoService dicoService, ILogger<DicoController> logger)
    {
        _dicoService = dicoService;
        _logger = logger;
    }

    // WCF: [WebGet(UriTemplate = "GetAllSource/{domain}/{loginNT}")]
    [HttpGet("GetAllSource/{domain}/{loginNT}")]
    public ActionResult<ResponseSourceDTO> GetAllSource(string domain, string loginNT)
        => Ok(_dicoService.GetAllSource(domain, loginNT));

    // WCF: [WebInvoke(UriTemplate = "CreateSource", Method = "POST")]
    [HttpPost("CreateSource")]
    public ActionResult<ResponseSourceDTO> CreateSource([FromBody] SourceDTO dto)
        => Ok(_dicoService.CreateSource(dto));
}
```

**Error handling � replace `FaultException` pattern:**
```csharp
// Add global exception middleware in Program.cs
app.UseExceptionHandler(errorApp => errorApp.Run(async context => {
    var error = context.Features.Get<IExceptionHandlerFeature>();
    var problem = new ProblemDetails {
        Status = StatusCodes.Status500InternalServerError,
        Title = "An unexpected error occurred.",
        Detail = error?.Error.Message
    };
    context.Response.ContentType = "application/problem+json";
    context.Response.StatusCode = 500;
    await context.Response.WriteAsJsonAsync(problem);
}));
// Remove all try/catch FaultException blocks from individual controllers
```

---

#### S3-T5 � Delete WCF Artifacts (0.5 day)

```
Files/folders to delete from OpenSafetyDistributedService:
??? OpenSafetyAcquisitionWCFService.svc + .svc.cs
??? OpenSafetyAdminWCFService.svc + .svc.cs
??? OpenSafetyCosmetochemWCFService.svc + .svc.cs
??? OpenSafetyDataWCFService.svc + .svc.cs
??? OpenSafetyDicoWCFService.svc + .svc.cs
??? OpenSafetyMdmWCFService.svc + .svc.cs
??? OpenSafetyMpnetWCFService.svc + .svc.cs
??? OpenSafetySynonymsWCFService.svc + .svc.cs
??? Global.asax + Global.asax.cs
??? Web.config
??? App_Start/UnityConfig.cs
```

---

#### S3-T6 � Deploy New API + Smoke Test (1 day)

```bash
# Build & publish
dotnet publish OpenSafetyDistributedService -c Release -o ./publish/api

# Deploy to dev IIS (side-by-side with WCF � different virtual path)
# New:  https://dev-server/opensafety-api/api/dico/GetAllSource/...
# Old:  https://dev-server/OpenSafetyWS/OpenSafetyDicoWCFService.svc/GetAllSource/...

# Smoke test via Swagger UI
# https://dev-server/opensafety-api/swagger
```

---

#### S3 � Exit Criteria

- [ ] `OpenSafetyDistributedService` converts to SDK-style, targets `net8.0`
- [ ] All 8 WCF `.svc` files deleted
- [ ] `Program.cs` bootstraps the full pipeline with DI, Auth, Swagger
- [ ] 8 new `[ApiController]` classes created; all WCF routes reproduced as REST routes
- [ ] `OpenSafetyDependancyResolver` project deleted
- [ ] `appsettings.json` created; no secrets committed
- [ ] New API deployed to dev; all endpoints return `200` in Swagger UI
- [ ] JSON response format verified against frontend expectations
- [ ] `git tag phase3-complete`

---

## Phase 4 � Frontend: MVC 5 ? ASP.NET Core 8 MVC

> **Duration:** Sprint 6�9 (4 weeks) � **Effort:** 29 days � **Risk:** ?? Medium � UI surface area is large

### Goals
Migrate `OpenSafetyFrontend` to ASP.NET Core 8 MVC. Replace 6 WCF client proxies with typed `HttpClient`. Update all 119 Razor views. Migrate jqGrid (7 views) to DataTables.js.

---

### Sprint 6 � Weeks 13�14

#### S4-T1 � Delete Legacy Artifacts & Create Skeleton (1 day)

```
Files to delete from OpenSafetyFrontend:
??? Global.asax + Global.asax.cs
??? Web.config
??? App_Start/BundleConfig.cs
??? App_Start/FilterConfig.cs
??? App_Start/RouteConfig.cs
??? App_Start/WebApiConfig.cs
??? Service References/ServiceAdmin/         (entire folder)
??? Service References/ServiceCosmetochem/   (entire folder)
??? Service References/ServiceData/          (entire folder)
??? Service References/ServiceDico/          (entire folder)
??? Service References/ServiceMdm/           (entire folder)
??? Service References/ServiceMpnet/         (entire folder)
```

---

#### S4-T2 � Create `Program.cs` for `OpenSafetyFrontend` (2 days)

```csharp
// OpenSafetyFrontend/Program.cs
var builder = WebApplication.CreateBuilder(args);

builder.Host.UseSerilog((ctx, cfg) => cfg
    .ReadFrom.Configuration(ctx.Configuration)
    .Enrich.FromLogContext()
    .WriteTo.Console()
    .WriteTo.File("logs/frontend-.log", rollingInterval: RollingInterval.Day));

// MVC
builder.Services.AddControllersWithViews();
builder.Services.AddHttpContextAccessor();

// Session
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(opt => {
    opt.IdleTimeout = TimeSpan.FromHours(8);
    opt.Cookie.HttpOnly = true;
    opt.Cookie.IsEssential = true;
});

// Typed HTTP clients ? OpenSafety API
builder.Services.AddHttpClient<DicoApiClient>(c =>
    c.BaseAddress = new Uri(builder.Configuration["Endpoints:DicoApi"]!));
builder.Services.AddHttpClient<AdminApiClient>(c =>
    c.BaseAddress = new Uri(builder.Configuration["Endpoints:AdminApi"]!));
builder.Services.AddHttpClient<AcquisitionApiClient>(c =>
    c.BaseAddress = new Uri(builder.Configuration["Endpoints:AcquisitionApi"]!));
builder.Services.AddHttpClient<DataApiClient>(c =>
    c.BaseAddress = new Uri(builder.Configuration["Endpoints:DataApi"]!));
builder.Services.AddHttpClient<MdmApiClient>(c =>
    c.BaseAddress = new Uri(builder.Configuration["Endpoints:MdmApi"]!));
builder.Services.AddHttpClient<MpnetApiClient>(c =>
    c.BaseAddress = new Uri(builder.Configuration["Endpoints:MpnetApi"]!));

// AutoMapper
builder.Services.AddAutoMapper(typeof(Program).Assembly);

// Memory cache
builder.Services.AddMemoryCache();

// Windows Auth
builder.Services.AddAuthentication(NegotiateDefaults.AuthenticationScheme).AddNegotiate();
builder.Services.AddAuthorization();

var app = builder.Build();

app.UseExceptionHandler("/OpsError/Index");
app.UseHsts();
app.UseStaticFiles();
app.UseSession();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(name: "areas", pattern: "{area:exists}/{controller=Home}/{action=Index}/{id?}");
app.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
```

---

#### S4-T3 � Create 6 Typed `HttpClient` Classes (2 days)

Replace the 6 WCF `ServiceReference` proxies with typed `HttpClient` wrappers:

```csharp
// Pattern (same for all 6 clients)
public class DicoApiClient
{
    private readonly HttpClient _client;
    public DicoApiClient(HttpClient client) => _client = client;

    public async Task<ResponseSourceDTO?> GetAllSourceAsync(string domain, string loginNT)
        => await _client.GetFromJsonAsync<ResponseSourceDTO>(
               $"GetAllSource/{Uri.EscapeDataString(domain)}/{Uri.EscapeDataString(loginNT)}");

    public async Task<ResponseBlocDTO?> GetAllBlocsAsync(string sourceId, string domain, string loginNT)
        => await _client.GetFromJsonAsync<ResponseBlocDTO>(
               $"GetAllBlocs/{sourceId}/{domain}/{loginNT}");
    // ... one method per former WCF OperationContract
}
```

**Client ? Service mapping:**
| Typed Client | Replaces WCF Proxy | Base URL Config Key |
|---|---|---|
| `DicoApiClient` | `ServiceDico.DicoServiceClient` | `Endpoints:DicoApi` |
| `AdminApiClient` | `ServiceAdmin.AdminServiceClient` | `Endpoints:AdminApi` |
| `AcquisitionApiClient` | `ServiceAcquisition.AcquisitionServiceClient` | `Endpoints:AcquisitionApi` |
| `DataApiClient` | `ServiceData.DataServiceClient` | `Endpoints:DataApi` |
| `MdmApiClient` | `ServiceMdm.MdmServiceClient` | `Endpoints:MdmApi` |
| `MpnetApiClient` | `ServiceMpnet.MpnetServiceClient` | `Endpoints:MpnetApi` |

---

### Sprint 7 � Weeks 14�15

#### S4-T4 � Migrate All Controllers (3 days)

**MVC controllers (14 files):**
```
Replace in every controller:
- using System.Web.Mvc ? using Microsoft.AspNetCore.Mvc
- : Controller ? : Controller (same name, different namespace � verify using directive)
- ActionResult (same, namespace update only)
- HttpContext.Current ? _httpContextAccessor.HttpContext
- Session["key"] ? HttpContext.Session.GetString("key")
- new ServiceDico.DicoServiceClient().GetAllSource() ? await _dicoApiClient.GetAllSourceAsync()
- ConfigurationManager.AppSettings["key"] ? _configuration["key"]
- log4net ? ILogger<T>
```

**Web API 2 controllers (11 files in `/Api/`):**
```
Replace in every API controller:
- using System.Web.Http ? using Microsoft.AspNetCore.Mvc
- : ApiController ? : ControllerBase
- Add [ApiController] attribute
- Add [Route("api/[controller]")] attribute
- IHttpActionResult ? IActionResult
- Ok(result) ? same
- BadRequest() ? same (different namespace)
- Request.GetOwinContext() ? remove; use IHttpContextAccessor
```

---

#### S4-T5 � Replace `RestHelper` and `OPSConfigHelper` (1 day)

```
RestHelper.cs:
- Remove static class entirely
- Replace all usages with the appropriate typed HttpClient
- The 13 occurrences of new HttpClient() ? typed client injection

OPSConfigHelper.cs:
- Remove static ConfigurationManager.AppSettings reads
- Replace with IConfiguration injected into controllers
```

---

### Sprint 8 � Weeks 16�17

#### S4-T6 � Update 119 Razor Views (5 days)

**Systematic view update procedure:**

```
Step 1 � Namespace fixes (find & replace across all .cshtml):
  @using System.Web.Mvc ? @using Microsoft.AspNetCore.Mvc
  @using System.Web.Mvc.Html ? (remove � implicit in ASP.NET Core)

Step 2 � @model directive fixes:
  @model OpenSafetyFrontend.ServiceAdmin.BlocDTO
  ? @model OpenSafety.Contract.BlocDico.BlocDTO
  (update 12+ views referencing WCF proxy namespaces)

Step 3 � Ajax helpers:
  @Ajax.BeginForm(...) ? keep the same syntax but ensure
  jquery.unobtrusive-ajax.js is included via LibMan

Step 4 � PagedList:
  @using PagedList.Mvc ? @using X.PagedList.Mvc.Core
  @Html.PagedListPager(Model, ...) ? same syntax (X.PagedList is API-compatible)

Step 5 � Verify each area:
  - Run dotnet build ? fix any @model type errors
  - Browse each page in dev browser ? fix 404/500 errors
```

---

#### S4-T7 � Migrate jqGrid ? DataTables.js (3 days)

7 Razor views use `Trirand.jqGrid` server-side .NET wrapper. Replace with pure client-side DataTables.js:

```
Affected views:
  Admin/Views/Blocs/Index.cshtml
  Admin/Views/Colonnes/Index.cshtml
  Admin/Views/Sources/Index.cshtml
  Admin/Views/BlocVersionMetas/Index.cshtml
  Admin/Views/Metas/Index.cshtml
  Home/Views/SearchNoSql.cshtml
  Home/Views/Index.cshtml (partial grid)

Replacement pattern:
  Before (jqGrid server-side rendering):
    @Html.Trirand().JQGrid(Model.GridModel, "GridId")

  After (DataTables.js client-side):
    <table id="GridId" class="table table-striped"></table>
    <script>
      $('#GridId').DataTable({
          ajax: '/api/admin/GetBlocs',
          columns: [
              { data: 'NAME_EN', title: 'Name EN' },
              { data: 'NAME_FR', title: 'Name FR' },
              ...
          ],
          pageLength: 25
      });
    </script>

  Add to LibMan: datatables 2.1.x + datatables.net-bs5
```

---

### Sprint 9 � Weeks 18�19

#### S4-T8 � Replace `BundleConfig` with LibMan (1 day)

```json
// libman.json
{
  "version": "1.0",
  "defaultProvider": "cdnjs",
  "libraries": [
    { "library": "bootstrap@5.3.3", "destination": "wwwroot/lib/bootstrap" },
    { "library": "jquery@3.7.1", "destination": "wwwroot/lib/jquery" },
    { "library": "jquery-validate@1.21.0", "destination": "wwwroot/lib/jquery-validate" },
    { "library": "datatables@2.1.8", "destination": "wwwroot/lib/datatables" },
    { "library": "font-awesome@6.6.0", "destination": "wwwroot/lib/font-awesome" }
  ]
}
```

```
Move custom JS files to wwwroot/js/ops/:
  Scripts/ops_js/*.js ? wwwroot/js/ops/*.js

Update _Layout.cshtml:
  Remove @Scripts.Render("~/bundles/jquery") etc.
  Add <script src="~/lib/jquery/jquery.min.js"></script> etc. directly
  Or use _ViewImports.cshtml to define a tag helper for shared scripts
```

---

#### S4-T9 � Create `appsettings.json` for Frontend (0.5 day)

```json
{
  "Endpoints": {
    "DicoApi":       "https://api-host/api/dico",
    "AdminApi":      "https://api-host/api/admin",
    "AcquisitionApi":"https://api-host/api/acquisition",
    "DataApi":       "https://api-host/api/data",
    "MdmApi":        "https://api-host/api/mdm",
    "MpnetApi":      "https://api-host/api/mpnet"
  },
  "AppSettings": {
    "PageSize": "10",
    "OST_ADMIN": "OST_ADMIN"
  },
  "Logging": {
    "LogLevel": { "Default": "Information" }
  }
}
```

---

#### S4-T10 � Frontend End-to-End Smoke Test (1.5 days)

```
Test matrix (one tester per module):
  ? Home � search results page loads, data returned from new API
  ? Home � silico launch (Code, Draw, File modes)
  ? Acquisition � create/edit data acquisition
  ? BatchSilico � batch launch form
  ? Admin � all 6 CRUD modules (Blocs, Colonnes, Metas, Sources, BlocVersionMetas, UserRoles)
  ? Language switching
  ? Session timeout behaviour
  ? Windows Authentication (NTLM/Kerberos)
  ? Excel/CSV export from data grid
  ? MarvinJS chemical sketcher (4 views)
```

---

#### S4 � Exit Criteria

- [ ] `OpenSafetyFrontend` builds on `net8.0` � no `System.Web`, `System.ServiceModel` references
- [ ] All 6 WCF `Service References` folders deleted; replaced by 6 typed `HttpClient` classes
- [ ] All 14 MVC controllers + 11 API controllers updated to ASP.NET Core namespaces
- [ ] All 119 `.cshtml` views compile without errors
- [ ] 7 jqGrid views replaced with DataTables.js
- [ ] `BundleConfig` removed; `libman.json` serves all static assets
- [ ] `RestHelper` and `OPSConfigHelper` statics replaced with injected services
- [ ] End-to-end smoke test matrix passes on DEV environment
- [ ] `git tag phase4-complete`

---

## Phase 5 � Background Services & Utilities

> **Duration:** Sprint 10 (1 week) � **Effort:** 6 days � **Risk:** ?? Low

---

### Sprint 10 � Week 20

#### S5-T1 � Migrate `WsAsynchronousSilicoState` ? Worker Service (3 days)

```xml
<!-- New OpenSafetyAsynchronousService.csproj -->
<Project Sdk="Microsoft.NET.Sdk.Worker">
  <PropertyGroup>
    <TargetFramework>net8.0-windows</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Microsoft.Extensions.Hosting" Version="8.0.1" />
    <PackageReference Include="Microsoft.Extensions.Hosting.WindowsServices" Version="8.0.0" />
    <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
    <PackageReference Include="Serilog.Extensions.Hosting" Version="8.0.0" />
  </ItemGroup>
</Project>
```

**Files to delete:**
```
ProjectInstaller.cs
ProjectInstaller.Designer.cs
ProjectInstaller.resx
OpenSafetyAsynchronousService.Designer.cs
Program.cs (old WinForms-style bootstrap)
```

**New `Program.cs`:**
```csharp
using Microsoft.Extensions.Hosting.WindowsServices;
using Serilog;

IHost host = Host.CreateDefaultBuilder(args)
    .UseWindowsService(opt => opt.ServiceName = "OpenSafety Async Service")
    .UseSerilog((ctx, cfg) => cfg
        .ReadFrom.Configuration(ctx.Configuration)
        .WriteTo.EventLog("OpenSafetyAsyncService"))
    .ConfigureServices((ctx, services) => {
        services.AddHttpClient("CosmetochemApi", c =>
            c.BaseAddress = new Uri(ctx.Configuration["Endpoints:CosmetochemAnalyze"]!));
        services.AddHostedService<OpenSafetyWorkerService>();
    })
    .Build();

await host.RunAsync();
```

**Rewrite `OpenSafetyAsynchronousService.cs` ? `OpenSafetyWorkerService.cs`:**
```csharp
public class OpenSafetyWorkerService : BackgroundService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger<OpenSafetyWorkerService> _logger;
    private readonly IConfiguration _configuration;

    public OpenSafetyWorkerService(IHttpClientFactory factory,
        ILogger<OpenSafetyWorkerService> logger, IConfiguration config)
    {
        _httpClientFactory = factory;
        _logger = logger;
        _configuration = config;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("OpenSafety Worker Service starting");
        using var timer = new PeriodicTimer(TimeSpan.FromSeconds(
            _configuration.GetValue<int>("AppSettings:PollingIntervalSeconds", 30)));

        while (await timer.WaitForNextTickAsync(stoppingToken))
        {
            try
            {
                var domain  = _configuration["AppSettings:Domain"]!;
                var loginNT = _configuration["AppSettings:LoginNT"]!;
                var client  = _httpClientFactory.CreateClient("CosmetochemApi");
                var url     = $"AnalyzeSilicoResult/{domain}/{loginNT}";
                var response = await client.GetAsync(url, stoppingToken);
                response.EnsureSuccessStatusCode();
                _logger.LogInformation("Silico analysis triggered successfully");
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                _logger.LogError(ex, "Error during silico analysis poll");
            }
        }
    }
}
```

---

#### S5-T2 � Migrate `OpenSafetyStateChecker` (1 day)

Same pattern as S5-T1. If no business logic is ever planned for this service, **retire it** (remove from solution). Otherwise, implement the health check using `IHealthChecks` pattern:

```csharp
// Option A: Retire � remove project from solution
// Option B: Convert to health-check worker
builder.Services.AddHealthChecks()
    .AddDbContextCheck<OpenSafetyDBContext>()
    .AddUrlGroup(new Uri(config["Endpoints:DicoApi"]!), "dico-api");
```

---

#### S5-T3 � Update `JsonToSql` (0.5 day)

```xml
<!-- JsonToSql.csproj � bump from netcoreapp3.1 -->
<TargetFramework>net8.0</TargetFramework>
```

Replace `Microsoft.Office.Interop.Excel` (not supported on .NET 8) with `ClosedXML`:
```csharp
// Before (Excel Interop)
var app = new Microsoft.Office.Interop.Excel.Application();
// After (ClosedXML)
using var workbook = new XLWorkbook();
var sheet = workbook.Worksheets.Add("Data");
```

---

#### S5-T4 � Retire or Update `ConsoleTest` (0.5 day)

```
Option A (recommended): Remove from solution � it is a developer scratch tool with
hardcoded internal server URLs that should never be in CI.

Option B (if kept):
- Remove using System.Runtime.Remoting.Messaging (not in .NET Core)
- Remove using System.Web.Script.Serialization (not in .NET Core)
- Replace WebRequest with HttpClient
- Replace JavaScriptSerializer with System.Text.Json
- Update to net8.0
```

---

#### S5 � Exit Criteria

- [ ] `WsAsynchronousSilicoState` converts to `net8.0-windows` Worker Service; `ServiceBase` removed
- [ ] `PeriodicTimer` replaces `System.Timers.Timer`; all `.Result` blocking calls eliminated
- [ ] Service runs and polls the cosmetochem endpoint successfully in DEV environment
- [ ] `OpenSafetyStateChecker` either retired or converted
- [ ] `JsonToSql` targets `net8.0`; Excel Interop replaced with ClosedXML
- [ ] `git tag phase5-complete`

---

## Phase 6 � Test Modernisation

> **Duration:** Sprint 11 (1 week) � **Effort:** 9 days � **Risk:** ?? Low

---

### Sprint 11 � Week 21

#### S6-T1 � Convert Test Projects to xUnit (2 days)

```xml
<!-- New OpenSafetyDistributedService.Tests.csproj -->
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <IsPackable>false</IsPackable>
    <Nullable>enable</Nullable>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Microsoft.AspNetCore.Mvc.Testing" Version="8.0.8" />
    <PackageReference Include="Microsoft.NET.Test.Sdk" Version="17.11.1" />
    <PackageReference Include="Moq" Version="4.20.72" />
    <PackageReference Include="FluentAssertions" Version="6.12.1" />
    <PackageReference Include="xunit" Version="2.9.2" />
    <PackageReference Include="xunit.runner.visualstudio" Version="2.8.2">
      <PrivateAssets>all</PrivateAssets>
    </PackageReference>
  </ItemGroup>
  <ItemGroup>
    <ProjectReference Include="..\OpenSafetyDistributedService\OpenSafetyDistributedService.csproj" />
  </ItemGroup>
</Project>
```

```
Migration steps:
1. Remove [TestClass], [TestMethod] ? use [Fact] and [Theory]
2. Assert.AreEqual(x, y) ? x.Should().Be(y) (FluentAssertions)
3. Assert.IsNotNull(x) ? x.Should().NotBeNull()
4. New[ServiceDico.DicoServiceClient()] ? inject WebApplicationFactory<Program>
5. Remove all WCF Connected Services folders from test project
```

---

#### S6-T2 � Write Unit Tests for Core Services (3 days)

Priority order (highest business value):

| Test Class | System Under Test | Mock |
|---|---|---|
| `SecurityServiceTests` | `SecurityService.CheckSecurityService()` | `IMdmRepository`, `IHttpContextAccessor` |
| `DicoApplicationServiceTests` | `GetAllSource()`, `CreateSource()`, `UpdateSource()` | `IDicoRepository`, `IMapper` |
| `AcquisitionApplicationServiceTests` | `GetJobs()`, `CreateJob()` | `IAcquisitionRepository`, `IUnitOfWork` |
| `EFDicoRepositoryTests` | `GetAllBlocs()`, `GetSourceById()` | In-memory EF Core (`UseInMemoryDatabase`) |
| `AdminApplicationServiceTests` | Bloc CRUD operations | `IGenericRepository<Bloc>` |

---

#### S6-T3 � Write Integration Tests for API Controllers (3 days)

```csharp
// Pattern using WebApplicationFactory
public class DicoControllerTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly HttpClient _client;

    public DicoControllerTests(WebApplicationFactory<Program> factory)
    {
        _client = factory.WithWebHostBuilder(builder =>
            builder.ConfigureServices(services => {
                // Replace real DbContext with in-memory
                services.RemoveAll<DbContextOptions<OpenSafetyDBContext>>();
                services.AddDbContext<OpenSafetyDBContext>(opt =>
                    opt.UseInMemoryDatabase("TestDb"));
            })).CreateClient();
    }

    [Fact]
    public async Task GetAllSource_Returns200_WithDomainAndLoginNT()
    {
        var response = await _client.GetAsync("/api/dico/GetAllSource/loreal/testuser");
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        var content = await response.Content.ReadFromJsonAsync<ResponseSourceDTO>();
        content.Should().NotBeNull();
    }
}
```

---

#### S6-T4 � Configure CI Coverage Gate (1 day)

```groovy
// Jenkinsfile addition
stage('Test & Coverage') {
    steps {
        sh '''
        dotnet test OpenSafety.sln \
          --collect:"XPlat Code Coverage" \
          --results-directory TestResults \
          --logger "trx;LogFileName=test-results.trx"
        '''
        // Fail build if coverage drops below 60%
        sh 'dotnet tool run reportgenerator -reports:"TestResults/**/coverage.cobertura.xml" -targetdir:CoverageReport -reporttypes:Html'
    }
    post {
        always {
            publishHTML(target: [reportDir: 'CoverageReport', reportFiles: 'index.html', reportName: 'Coverage Report'])
        }
    }
}
```

---

#### S6 � Exit Criteria

- [ ] Both test projects target `net8.0`, use xUnit + Moq + FluentAssertions
- [ ] At least 5 unit test classes with meaningful assertions
- [ ] At least 8 integration tests (one per API controller)
- [ ] `dotnet test` passes with 0 failures in CI
- [ ] Coverage report generated; gate set at 60%
- [ ] `git tag phase6-complete`

---

## Phase 7 � CI/CD & IIS Deployment

> **Duration:** Sprint 11 (concurrent with Phase 6) � **Effort:** 4 days � **Risk:** ?? Low

---

### S7-T1 � Update Jenkinsfiles (1 day)

**Replace MSBuild pipeline with dotnet CLI:**

```groovy
// Jenkinsfile-Api (replaces MSBuild-based build)
pipeline {
    agent { label 'windows-dotnet8' }
    stages {
        stage('Restore') {
            steps { bat 'dotnet restore OpenSafety.sln' }
        }
        stage('Build') {
            steps { bat 'dotnet build OpenSafety.sln -c Release --no-restore' }
        }
        stage('Test') {
            steps {
                bat 'dotnet test OpenSafety.sln -c Release --no-build --logger trx --results-directory TestResults'
            }
            post { always { mstest testResultsFile: 'TestResults/**/*.trx' } }
        }
        stage('Publish API') {
            steps { bat 'dotnet publish OpenSafetyDistributedService -c Release -o publish\\api' }
        }
        stage('Migrate DB') {
            steps {
                bat '''
                dotnet ef database update ^
                  --project OPenSafetyInfrastructure ^
                  --startup-project OpenSafetyDistributedService ^
                  --connection "%OPENSAFETY_CONNECTION_STRING%"
                '''
            }
        }
        stage('Deploy API to IIS') {
            steps {
                // Use existing DeployDotNetWithParams shared library
                // Update parameters: targetDir ? publish\api
                deployDotNetWithParams(publishDir: 'publish\\api', siteName: 'OpenSafety-API')
            }
        }
    }
}

// Jenkinsfile-Front (same pattern)
stage('Publish Frontend') {
    steps { bat 'dotnet publish OpenSafetyFrontend -c Release -o publish\\frontend' }
}
stage('Deploy Frontend to IIS') {
    steps { deployDotNetWithParams(publishDir: 'publish\\frontend', siteName: 'OpenSafety-Frontend') }
}
```

---

### S7-T2 � IIS Server Configuration (2 days)

**Perform on all IIS servers: dev, pit, int, prod (in that order):**

```
Step 1 � Install .NET 8 Windows Hosting Bundle:
  Download: https://dotnet.microsoft.com/download/dotnet/8.0 ? "Hosting Bundle"
  Install on each Windows Server
  Restart IIS: iisreset

Step 2 � Configure Application Pools:
  OpenSafety-API Pool:
    .NET CLR Version = "No Managed Code"
    Managed Pipeline Mode = Integrated
    Identity = (service account with DB access)

  OpenSafety-Frontend Pool:
    .NET CLR Version = "No Managed Code"
    Managed Pipeline Mode = Integrated

Step 3 � Add web.config to each publish output:
```

```xml
<!-- web.config for IIS hosting (included in publish output) -->
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <system.webServer>
    <handlers>
      <add name="aspNetCore" path="*" verb="*"
           modules="AspNetCoreModuleV2" resourceType="Unspecified" />
    </handlers>
    <aspNetCore processPath="dotnet"
                arguments=".\OpenSafetyDistributedService.dll"
                stdoutLogEnabled="true"
                stdoutLogFile=".\logs\stdout"
                hostingModel="inprocess" />
  </system.webServer>
</configuration>
```

```
Step 4 � Azure Key Vault for secrets:
  Create Key Vault in Azure portal
  Add secrets: OpenSafetyDBContext, MDM_X-Username, OST-Api-Key, ClientSecret, etc.
  Grant Managed Identity access to Key Vault
  Add to Program.cs:
    builder.Configuration.AddAzureKeyVault(new Uri(config["KeyVaultUri"]!), new DefaultAzureCredential());
```

---

### S7-T3 � Decommission WCF (0.5 day)

Once all consumers have been confirmed migrated to the new REST API:

```
1. Take WCF application pool offline in IIS
2. Archive (do NOT delete yet) the WCF virtual directory
3. Monitor for 404 errors on .svc URLs in logs for 2 weeks
4. After 2-week clean period: delete IIS WCF site configuration
5. Archive the WCF deployment artifacts to cold storage
```

---

### S7-T4 � Production Go-Live Checklist (0.5 day)

```
Pre-deployment:
  [ ] DB backup taken
  [ ] EF Core migration dry-run against prod DB replica
  [ ] Canary deployment to 1 IIS node before full rollout
  [ ] Rollback plan documented (restore IIS backup + DB backup)

Deployment:
  [ ] .NET 8 Hosting Bundle installed on all prod servers
  [ ] App pools reconfigured to "No Managed Code"
  [ ] API published to prod IIS
  [ ] Frontend published to prod IIS
  [ ] dotnet ef database update executed on prod DB

Post-deployment:
  [ ] Application Insights / Serilog verified � logs flowing
  [ ] Health checks passing
  [ ] Smoke test: login, search, admin CRUD
  [ ] WCF endpoints monitored � should return 0 requests after cutover
```

---

#### S7 � Exit Criteria

- [ ] `Jenkinsfile-Api` and `Jenkinsfile-Front` use `dotnet` CLI exclusively
- [ ] `dotnet ef database update` runs as a CI pipeline step
- [ ] `.NET 8 Windows Hosting Bundle` installed on dev, pit, int, prod
- [ ] Application pools set to "No Managed Code" on all environments
- [ ] `web.config` Kestrel handler deployed with each publish
- [ ] Azure Key Vault wired; no plaintext secrets in source code or config files
- [ ] WCF application pool offline; monitoring for .svc requests for 2 weeks
- [ ] `git tag phase7-complete` ? merge `feature/dotnet8-migration` ? `master`

---

## Complete Task Checklist

### Phase 0 � Pre-Migration
- [ ] S0-T1: Environment setup (.NET 8 SDK, tools)
- [ ] S0-T2: ?? Credential rotation + git history rewrite
- [ ] S0-T3: Fix Infrastructure ? Frontend layer violation
- [ ] S0-T4: Remove 4 stub projects
- [ ] S0-T5: Delete duplicate / dead files
- [ ] S0-T6: Run `upgrade-assistant analyze`

### Phase 1 � Foundation Libraries
- [ ] S1-T1: `OpenSafetyCrossCutting` ? net8.0
- [ ] S1-T2: `OpenSafetyDomainModel` ? net8.0
- [ ] S1-T3: `OpenSafetyContract` ? net8.0 (strip WCF attributes)

### Phase 2 � Infrastructure & Application
- [ ] S2-T1: `OPenSafetyInfrastructure` � EF Core 8 migration
- [ ] S2-T2: `OPenSafetyInfrastructure` � Elasticsearch 8 + HttpClient
- [ ] S2-T3: `OpenSafetyApplication` � AutoMapper 13, ILogger, IConfiguration

### Phase 3 � API Host
- [ ] S3-T1: Dissolve `OpenSafetyDependancyResolver`
- [ ] S3-T2: Create `Program.cs` for DistributedService
- [ ] S3-T3: Create `appsettings.json` for API
- [ ] S3-T4: Create 8 ASP.NET Core controllers
- [ ] S3-T5: Delete WCF artifacts
- [ ] S3-T6: Deploy API + smoke test

### Phase 4 � Frontend
- [ ] S4-T1: Delete legacy artifacts (Global.asax, Web.config, App_Start, Service References)
- [ ] S4-T2: Create `Program.cs` for Frontend
- [ ] S4-T3: Create 6 typed HttpClient classes
- [ ] S4-T4: Migrate all 14 MVC + 11 API controllers
- [ ] S4-T5: Replace RestHelper + OPSConfigHelper
- [ ] S4-T6: Update 119 Razor views
- [ ] S4-T7: Migrate 7 jqGrid views ? DataTables.js
- [ ] S4-T8: Replace BundleConfig with LibMan
- [ ] S4-T9: Create `appsettings.json` for Frontend
- [ ] S4-T10: End-to-end smoke test

### Phase 5 � Background Services
- [ ] S5-T1: `WsAsynchronousSilicoState` ? BackgroundService
- [ ] S5-T2: `OpenSafetyStateChecker` ? retire or convert
- [ ] S5-T3: `JsonToSql` ? net8.0
- [ ] S5-T4: `ConsoleTest` ? retire or update

### Phase 6 � Tests
- [ ] S6-T1: Convert both test projects to xUnit
- [ ] S6-T2: Write unit tests (min. 5 test classes)
- [ ] S6-T3: Write integration tests (min. 8 controller tests)
- [ ] S6-T4: Configure CI coverage gate (? 60%)

### Phase 7 � CI/CD & Deployment
- [ ] S7-T1: Update Jenkinsfiles to dotnet CLI
- [ ] S7-T2: Configure IIS servers (.NET 8 Hosting Bundle)
- [ ] S7-T3: Decommission WCF
- [ ] S7-T4: Production go-live

---

## Effort Summary

| Phase | Sprints | Weeks | Effort (days) | Primary Risk |
|---|---|---|---|---|
| 0 � Preparation | 0 | 1 | 5 | ?? Credentials |
| 1 � Foundation Libraries | 1 | 2 | 6 | ?? Low |
| 2 � Infrastructure + Application | 2�3 | 3 | 17 | ?? EF Core, ES |
| 3 � API Host | 4�5 | 2 | 16 | ?? WCF consumers |
| 4 � Frontend | 6�9 | 4 | 29 | ?? UI surface |
| 5 � Background Services | 10 | 1 | 6 | ?? Low |
| 6 � Tests | 11 | 1 | 9 | ?? Low |
| 7 � CI/CD + Deploy | 11 | 1 | 4 | ?? Low |
| **Total** | **11** | **~15** | **~92** | |

> **Parallel-track option (2 developers):** Phases 1�2 and Phases 3�4 can overlap.
> Phase 1+2 (dev A: Infrastructure track): ~23 days
> Phase 3+4 (dev B: Frontend track, starts after Phase 3 API is stable): ~45 days
> **Combined calendar time: ~12�13 weeks** at 2 developers working in parallel.

---

*Plan generated from `Upgrade_report.md`, `answers.md`, and `Audit.md` � OpenSafety solution on branch `master`.*
