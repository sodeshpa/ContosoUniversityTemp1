# OpenSafety � .NET 8 Upgrade Report

## Table of Contents

1. [Solution Overview](#1-solution-overview)
2. [Project-by-Project Migration Plan](#2-project-by-project-migration-plan)
3. [Cross-Cutting Migration Topics](#3-cross-cutting-migration-topics)
4. [Package Migration Table](#4-package-migration-table)
5. [Breaking Changes Catalogue](#5-breaking-changes-catalogue)
6. [New Project File Format (SDK-Style)](#6-new-project-file-format-sdk-style)
7. [Step-by-Step Upgrade Procedure](#7-step-by-step-upgrade-procedure)
8. [Code Change Examples](#8-code-change-examples)
9. [CI/CD Pipeline Changes](#9-cicd-pipeline-changes)
10. [Risk Register](#10-risk-register)
11. [Effort Estimate](#11-effort-estimate)

---

## 1. Solution Overview

### Current State

| Property | Value |
|---|---|
| Solution file | `OpenSafety.sln` |
| Total projects | 17 |
| Source `.cs` files | 578 |
| Target framework (majority) | .NET Framework 4.7.1 |
| Target framework (legacy outliers) | .NET Framework 4.5.2 (`OpenSafetyFrontedApplication`, `Fronted.Tests`) |
| Already on .NET Core | `JsonToSql` ? `netcoreapp3.1` |
| Project format | Legacy XML (`<Project ToolsVersion="12.0">`) |
| Package management | `packages.config` |

### Dependency Graph (Build Order)

The following order must be respected during migration � each layer depends only on layers below it:

```
[1] OpenSafetyCrossCutting          (no project dependencies)
[2] OpenSafetyDomainModel           ? CrossCutting
[3] OpenSafetyContract              ? CrossCutting, DomainModel
[4] OPenSafetyInfrastructure        ? CrossCutting, DomainModel, Frontend (?? violation � see �3.1)
[5] OpenSafetyApplication           ? Contract, CrossCutting, DomainModel
[6] OpenSafetyDependancyResolver    ? Application, Contract, DomainModel, Infrastructure
[7] OpenSafetyDistributedService    ? Application, Contract, CrossCutting, DependancyResolver, DomainModel, Infrastructure
[8] OpenSafetyFrontend              ? CrossCutting, DomainModel, Application, Contract, Infrastructure
[9] OpenSafetyFrontedApplication    ? (stub � no project dependencies)
[10] WsAsynchronousSilicoState      ? Frontend (runtime HTTP only)
[11] OpenSafetyStateChecker         ? (stub � no project dependencies)
[12] ConsoleTest                    ? Contract, CrossCutting, DomainModel
[13] WebApiOpenSafety               ? (scaffold placeholder)
[14] JsonToSql                      ? (already netcoreapp3.1)
[15] OpenSafetyDistributedService.Tests ? (WCF service references only)
[16] OpenSafetyFrontend.Tests       ? Frontend
[17] Fronted.Tests                  ? (empty stub)
```

---

## 2. Project-by-Project Migration Plan

### 2.1 `OpenSafetyCrossCutting` ? `net8.0` Class Library

**Migration complexity: LOW**

**Current dependencies:**
- `ClosedXML` 0.95.2
- `DocumentFormat.OpenXml` 2.10.1
- `log4net` 2.0.8
- `Newtonsoft.Json` 12.0.3
- `Unity` 5.11.x
- `System.Runtime.Caching` (in-process cache)
- `System.Web` (via `GenerateCsvFile` which uses `HttpContext.Current.Response`)

**Actions required:**

| # | Action | Detail |
|---|---|---|
| 1 | Remove `System.Web` dependency | `GenerateCsvFile` uses `HttpContext.Current.Response` for file download � extract HTTP concern into an interface; inject `IHttpContextAccessor` in the web host |
| 2 | Replace `log4net` | Swap to `Microsoft.Extensions.Logging.Abstractions`; inject `ILogger<T>` |
| 3 | Replace `System.Runtime.Caching.MemoryCache` | Use `Microsoft.Extensions.Caching.Memory.IMemoryCache` |
| 4 | Remove `Unity` stubs | Delete `App_Start\UnityConfig.cs` entirely |
| 5 | Remove `Microsoft.CodeDom.Providers.DotNetCompilerPlatform` | Not needed on .NET 8 |
| 6 | Update `ClosedXML` ? 0.102+ | Supports `net8.0` natively |
| 7 | Update `DocumentFormat.OpenXml` ? 3.x | Supports `net8.0` |
| 8 | Update `Newtonsoft.Json` ? 13.x | Backward-compatible |

**New `.csproj`:**
```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="ClosedXML" Version="0.102.2" />
    <PackageReference Include="DocumentFormat.OpenXml" Version="3.1.0" />
    <PackageReference Include="Microsoft.Extensions.Caching.Memory" Version="8.0.1" />
    <PackageReference Include="Microsoft.Extensions.Logging.Abstractions" Version="8.0.2" />
    <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
  </ItemGroup>
</Project>
```

---

### 2.2 `OpenSafetyDomainModel` ? `net8.0` Class Library

**Migration complexity: LOW**

**Current dependencies:**
- `Microsoft.CodeDom.Providers.DotNetCompilerPlatform` 2.0.1 (dev only)
- `Microsoft.Net.Compilers` 2.10.0 (dev only)
- `Newtonsoft.Json` 12.0.3
- `Unity` 5.2.1 / `Unity.Mvc5`
- `Microsoft.AspNet.Mvc` 5.2.3 (pulled in transitively � should not be here)

**Actions required:**

| # | Action | Detail |
|---|---|---|
| 1 | Remove ALL build-time toolchain packages | `Microsoft.CodeDom.Providers`, `Microsoft.Net.Compilers` are not needed on .NET 8 |
| 2 | Remove `Unity` and `Unity.Mvc5` | Domain model must have zero DI framework dependency |
| 3 | Remove `Microsoft.AspNet.Mvc` reference | Domain model must have zero web-framework dependency |
| 4 | Remove `Folder Include="App_Start\"` item | Stale IDE artifact |
| 5 | Remove `IRepository<TEntity>` / `ISpecification<TEntity>` | Not implemented anywhere; or implement properly |
| 6 | Update `Newtonsoft.Json` ? 13.x | |

**New `.csproj`:**
```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
  </ItemGroup>
  <ItemGroup>
    <ProjectReference Include="..\OpenSafetyCrossCutting\OpenSafetyCrossCutting.csproj" />
  </ItemGroup>
</Project>
```

---

### 2.3 `OpenSafetyContract` ? `net8.0` Class Library

**Migration complexity: MEDIUM**

**Current dependencies:**
- `System.ServiceModel` / `System.ServiceModel.Web` � WCF annotations (`[ServiceContract]`, `[OperationContract]`, `[WebGet]`)
- `Unity` 5.2.1

**Actions required:**

| # | Action | Detail |
|---|---|---|
| 1 | **Remove all WCF attributes** | Strip `[ServiceContract]`, `[OperationContract]`, `[WebGet(UriTemplate=...)]`, and `[WebInvoke]` from all 9 service interfaces (`IDicoService`, `IAdminService`, `IAcquisitionService`, `IDataService`, `ICosmetochemService`, `IMDMService`, `IMpnetService`, `ISynonymsService`, `ISecurityService`) |
| 2 | Remove `System.ServiceModel` references | Not available on .NET 8 without `CoreWCF` |
| 3 | Remove `Unity` | |
| 4 | Delete `App_Start\UnityConfig.cs` | |
| 5 | Keep DTOs unchanged | All `*DTO` classes are plain C# � no changes needed |

**New `.csproj`:**
```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
  </ItemGroup>
  <ItemGroup>
    <ProjectReference Include="..\OpenSafetyCrossCutting\OpenSafetyCrossCutting.csproj" />
    <ProjectReference Include="..\OpenSafetyDomainModel\OpenSafetyDomainModel.csproj" />
  </ItemGroup>
</Project>
```

---

### 2.4 `OPenSafetyInfrastructure` ? `net8.0` Class Library

**Migration complexity: HIGH**

**Current dependencies:**
- `EntityFramework` 6.1.3 ? must become `Microsoft.EntityFrameworkCore` 8.x
- `NEST` 6.1.0 / `Elasticsearch.Net` 6.1.0 ? `Elastic.Clients.Elasticsearch` 8.x
- `Unity` 5.2.1
- `System.ServiceModel` (via `Web References\MdmWS`)
- `OpenSafetyFrontend` project reference (**layer violation � must be removed**)
- 14 EF Entity Type Configurations using `EntityTypeConfiguration<T>` (EF6 API)
- 14 EF Migrations (EF6 `DbMigrationsConfiguration`)

**Actions required:**

| # | Action | Detail |
|---|---|---|
| 1 | **Remove `OpenSafetyFrontend` project reference** | This is a critical layer violation; move any shared types into `OpenSafetyContract` |
| 2 | **Migrate EF6 ? EF Core 8** | See �3.2 for full EF migration details |
| 3 | Replace `EntityTypeConfiguration<T>` | Use `IEntityTypeConfiguration<T>` from `Microsoft.EntityFrameworkCore` |
| 4 | Re-create EF Migrations | Generate a single initial migration from the current schema (`dotnet ef migrations add InitialCreate`) |
| 5 | Replace `NEST` 6 / `Elasticsearch.Net` 6 | Upgrade to `Elastic.Clients.Elasticsearch` 8.x (new official client) � API is significantly different |
| 6 | Replace `Web References\MdmWS` (ASMX proxy) | Delete generated `Reference.cs`; implement `WSMdmRepository` using `IHttpClientFactory` |
| 7 | Remove `Unity`, `System.ServiceModel`, `System.Web` | |
| 8 | Inject `OpenSafetyDBContext` via DI | Remove `new OpenSafetyDBContext()` in `EFDicoRepository` and `GenericRepository<T>` |
| 9 | Fix `GenericRepository<T>` context lifetime | Constructor must accept `OpenSafetyDBContext` injected, not instantiate a new one |

**New `.csproj`:**
```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Elastic.Clients.Elasticsearch" Version="8.14.6" />
    <PackageReference Include="Microsoft.EntityFrameworkCore" Version="8.0.8" />
    <PackageReference Include="Microsoft.EntityFrameworkCore.SqlServer" Version="8.0.8" />
    <PackageReference Include="Microsoft.EntityFrameworkCore.Tools" Version="8.0.8">
      <IncludeAssets>runtime; build; native; contentfiles; analyzers; buildtransitive</IncludeAssets>
      <PrivateAssets>all</PrivateAssets>
    </PackageReference>
    <PackageReference Include="Microsoft.Extensions.Http" Version="8.0.1" />
    <PackageReference Include="Microsoft.Extensions.Logging.Abstractions" Version="8.0.2" />
    <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
  </ItemGroup>
  <ItemGroup>
    <ProjectReference Include="..\OpenSafetyCrossCutting\OpenSafetyCrossCutting.csproj" />
    <ProjectReference Include="..\OpenSafetyDomainModel\OpenSafetyDomainModel.csproj" />
  </ItemGroup>
</Project>
```

---

### 2.5 `OpenSafetyApplication` ? `net8.0` Class Library

**Migration complexity: MEDIUM**

**Current dependencies:**
- `AutoMapper` 5.1.1 ? 13.x
- `log4net` 2.0.8
- `Unity` 5.2.1 + `Unity.Mvc5`
- `Microsoft.AspNet.Mvc` 5.2.3 (should not be referenced here)
- `System.Web` (`HttpContext` in `SecurityService`)
- `System.Configuration` (`ConfigurationManager.AppSettings`)

**Actions required:**

| # | Action | Detail |
|---|---|---|
| 1 | Replace `log4net` with `ILogger<T>` | |
| 2 | Replace `ConfigurationManager.AppSettings` with `IConfiguration` / `IOptions<T>` | |
| 3 | Remove `System.Web` / `HttpContext.Current.Session` from `SecurityService` | Inject `IHttpContextAccessor`; access `HttpContext.Current.Session` via `ISession` |
| 4 | Update `AutoMapper` ? 13.x | Update profile definitions to use `CreateMap` in typed `Profile` classes |
| 5 | Remove `Unity`, `Unity.Mvc5`, `Microsoft.AspNet.Mvc` | |
| 6 | Delete `App_Start\UnityConfig.cs` | |
| 7 | Update `AutoMapperConfig` classes | In `MapperConfiguration`, replace `Mapper.Initialize()` (static) with `new MapperConfiguration(cfg => ...)` |

**New `.csproj`:**
```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="AutoMapper" Version="13.0.1" />
    <PackageReference Include="Microsoft.Extensions.Http" Version="8.0.1" />
    <PackageReference Include="Microsoft.Extensions.Logging.Abstractions" Version="8.0.2" />
    <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
  </ItemGroup>
  <ItemGroup>
    <ProjectReference Include="..\OpenSafetyContract\OpenSafetyContract.csproj" />
    <ProjectReference Include="..\OpenSafetyCrossCutting\OpenSafetyCrossCutting.csproj" />
    <ProjectReference Include="..\OpenSafetyDomainModel\OpenSafetyDomainModel.csproj" />
  </ItemGroup>
</Project>
```

---

### 2.6 `OpenSafetyDependancyResolver` ? Dissolve into Host Projects

**Migration complexity: LOW (dissolve)**

This project exists solely to contain `UnityConfig.cs` and `UnityDependencyResolver.cs`. On .NET 8, both are replaced by built-in DI in `Program.cs`.

**Actions required:**

| # | Action | Detail |
|---|---|---|
| 1 | **Delete this project** | All DI registration moves to `Program.cs` of the host projects (`OpenSafetyDistributedService` and `OpenSafetyFrontend`) |
| 2 | Move `UnityConfig.RegisterComponents()` content | Translate each `container.RegisterType<I, T>()` to `services.AddScoped<I, T>()` in each host's `Program.cs` |
| 3 | Remove all references to this project | |

---

### 2.7 `OpenSafetyDistributedService` ? ASP.NET Core 8 Web API

**Migration complexity: VERY HIGH**

This is the highest-impact project. 8 WCF services must be replaced with ASP.NET Core Web API controllers.

**Current WCF services and their replacements:**

| WCF Service (`.svc.cs`) | New ASP.NET Core Controller | Route prefix |
|---|---|---|
| `OpenSafetyDicoWCFService` | `DicoController` | `api/dico` |
| `OpenSafetyAdminWCFService` | `AdminController` | `api/admin` |
| `OpenSafetyAcquisitionWCFService` | `AcquisitionController` | `api/acquisition` |
| `OpenSafetyDataWCFService` | `DataController` | `api/data` |
| `OpenSafetyCosmetochemWCFService` | `CosmetochemController` | `api/cosmetochem` |
| `OpenSafetyMdmWCFService` | `MdmController` | `api/mdm` |
| `OpenSafetyMpnetWCFService` | `MpnetController` | `api/mpnet` |
| `OpenSafetySynonymsWCFService` | `SynonymsController` | `api/synonyms` |

**Actions required:**

| # | Action | Detail |
|---|---|---|
| 1 | Delete all `.svc` and `.svc.cs` files | 8 WCF service files removed |
| 2 | Delete `Global.asax` / `Global.asax.cs` | Replaced by `Program.cs` |
| 3 | Delete `Web.config` | Replaced by `appsettings.json` |
| 4 | Delete `App_Start\UnityConfig.cs` | Replaced by `Program.cs` DI registration |
| 5 | Create `Program.cs` | Bootstrap host, register DI, configure middleware |
| 6 | Create `appsettings.json` | Move all `<appSettings>` keys; use Azure Key Vault for secrets |
| 7 | Create 8 controller classes | One per former WCF service; methods become `[HttpGet]` / `[HttpPost]` actions |
| 8 | Replace `[WebGet(UriTemplate=...)]` | Use `[HttpGet("{param1}/{param2}")]` |
| 9 | Replace `[WebInvoke(UriTemplate=...)]` | Use `[HttpPost]` with `[FromBody]` parameters |
| 10 | Replace `FaultException` wrapping | Use `IActionResult` / `ProblemDetails` and global exception middleware |
| 11 | Replace `System.ServiceModel.Activation` | Remove `[AspNetCompatibilityRequirements]` |
| 12 | Remove per-constructor `UnityConfig.RegisterComponents()` calls | Handled once at startup |
| 13 | Add `Swashbuckle.AspNetCore` for OpenAPI | Replace `Swashbuckle 6.0.0-rc1-final` |
| 14 | Add Windows Authentication middleware | `services.AddAuthentication(NegotiateDefaults.AuthenticationScheme)` + `services.AddAuthorization()` |

**New `.csproj`:**
```xml
<Project Sdk="Microsoft.NET.Sdk.Web">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Microsoft.AspNetCore.Authentication.Negotiate" Version="8.0.8" />
    <PackageReference Include="Swashbuckle.AspNetCore" Version="6.8.1" />
  </ItemGroup>
  <ItemGroup>
    <ProjectReference Include="..\OpenSafetyApplication\OpenSafetyApplication.csproj" />
    <ProjectReference Include="..\OpenSafetyContract\OpenSafetyContract.csproj" />
    <ProjectReference Include="..\OpenSafetyCrossCutting\OpenSafetyCrossCutting.csproj" />
    <ProjectReference Include="..\OpenSafetyDomainModel\OpenSafetyDomainModel.csproj" />
    <ProjectReference Include="..\OPenSafetyInfrastructure\OpenSafetyInfrastructure.csproj" />
  </ItemGroup>
</Project>
```

---

### 2.8 `OpenSafetyFrontend` ? ASP.NET Core 8 MVC

**Migration complexity: VERY HIGH**

**Current dependencies (significant ones):**
- `Microsoft.AspNet.Mvc` 5.2.3 ? `Microsoft.AspNetCore.Mvc` 8.x
- `System.Web` ? removed entirely
- `System.Web.Optimization` (BundleConfig) ? LibMan or Webpack/Vite
- `System.Web.Http` (WebApiConfig) ? built-in ASP.NET Core Web API
- WCF `Service References` (6 generated proxy files) ? typed `HttpClient` pointing to new Web API
- `PagedList.Mvc` ? `X.PagedList.Mvc.Core`
- `Trirand.jqGrid` 4.6.0 � no .NET 8 port; grid logic must move to JS-only or replace with a different grid
- `Bootstrap` 3.3.7 ? recommend Bootstrap 5.x (83 Razor views affected)
- `AutoMapper` 5.1.1 ? 13.x
- `EntityFramework` 6 / `NEST` 6 (direct references � should be removed; accessed via Infrastructure layer)
- `Modernizr` ? no longer needed for modern browsers

**Actions required:**

| # | Action | Detail |
|---|---|---|
| 1 | Delete `Global.asax` / `Global.asax.cs` | Replaced by `Program.cs` |
| 2 | Delete `Web.config` | Replaced by `appsettings.json` |
| 3 | Delete `App_Start\FilterConfig.cs`, `BundleConfig.cs`, `RouteConfig.cs`, `WebApiConfig.cs` | All replaced by `Program.cs` middleware configuration |
| 4 | Delete all `Service References` (6 folders) | Replace with `IHttpClientFactory`-based typed clients pointing to the new Web API |
| 5 | Replace `System.Web.HttpContext.Current` references | Use `IHttpContextAccessor` |
| 6 | Replace `System.Web.SessionState` | Use `ISession` via `services.AddSession()` |
| 7 | Replace `System.Web.Mvc.Controller` | Use `Microsoft.AspNetCore.Mvc.Controller` |
| 8 | Replace `System.Web.Http.ApiController` | Use `Microsoft.AspNetCore.Mvc.ControllerBase` |
| 9 | Replace `ActionResult` / `ViewResult` | API is compatible but namespace changes |
| 10 | Replace `System.Web.Optimization` bundles | Use `LibraryManager` (LibMan) for client-side assets or Vite/Webpack |
| 11 | Replace `HandleErrorAttribute` (global error filter) | Use `app.UseExceptionHandler()` middleware |
| 12 | Replace `ValidateModelStateAttribute` (Web API filter) | Use `[ApiController]` which enables automatic model validation |
| 13 | Remove `System.Web.Script.Serialization.JavaScriptSerializer` | Use `System.Text.Json` or `Newtonsoft.Json` |
| 14 | Remove `WebRequest` / `WebResponse` usage in `RestHelper` | Replace with `IHttpClientFactory` |
| 15 | Replace `ConfigurationManager.AppSettings` in `OPSConfigHelper` | Use `IConfiguration` / `IOptions<T>` |
| 16 | Update all 83 `.cshtml` Razor views | Remove `@using System.Web.Mvc.Html`, update tag helpers, update Bootstrap class names if upgrading to v5 |
| 17 | Replace `PagedList.Mvc` | Use `X.PagedList.Mvc.Core` package |
| 18 | Evaluate `Trirand.jqGrid` | No .NET 8 compatible port exists; migrate grid to a pure-JS grid library (AG Grid, DataTables) |
| 19 | Create `Program.cs` | Full middleware pipeline: Authentication, Authorization, Session, MVC, Static Files, etc. |
| 20 | Create `appsettings.json` | All endpoint URLs, environment settings |

**New `.csproj`:**
```xml
<Project Sdk="Microsoft.NET.Sdk.Web">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="AutoMapper.Extensions.Microsoft.DependencyInjection" Version="12.0.1" />
    <PackageReference Include="Microsoft.AspNetCore.Authentication.Negotiate" Version="8.0.8" />
    <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
    <PackageReference Include="X.PagedList.Mvc.Core" Version="9.1.2" />
  </ItemGroup>
  <ItemGroup>
    <ProjectReference Include="..\OpenSafetyApplication\OpenSafetyApplication.csproj" />
    <ProjectReference Include="..\OpenSafetyContract\OpenSafetyContract.csproj" />
    <ProjectReference Include="..\OpenSafetyCrossCutting\OpenSafetyCrossCutting.csproj" />
    <ProjectReference Include="..\OpenSafetyDomainModel\OpenSafetyDomainModel.csproj" />
    <ProjectReference Include="..\OPenSafetyInfrastructure\OpenSafetyInfrastructure.csproj" />
  </ItemGroup>
</Project>
```

---

### 2.9 `WsAsynchronousSilicoState` ? .NET 8 Worker Service

**Migration complexity: MEDIUM**

**Current:** Windows Service using `System.ServiceProcess.ServiceBase` + `System.Timers.Timer`

**Actions required:**

| # | Action | Detail |
|---|---|---|
| 1 | Replace `ServiceBase` | Convert to `BackgroundService` from `Microsoft.Extensions.Hosting` |
| 2 | Replace `System.Timers.Timer` | Use `PeriodicTimer` (available since .NET 6) or `Task.Delay` loop |
| 3 | Delete `Program.cs` (WinForms bootstrap) | Replace with `Host.CreateDefaultBuilder` pattern |
| 4 | Delete `ProjectInstaller.cs` / `.Designer.cs` / `.resx` | Windows Installer components � not needed with .NET 8 Windows Services |
| 5 | Delete `OpenSafetyAsynchronousService.Designer.cs` | Generated component designer file |
| 6 | Replace `log4net` with `ILogger<T>` | |
| 7 | Replace `ConfigurationManager.AppSettings` | Use `IConfiguration` / `appsettings.json` |
| 8 | Fix `HttpClient` instantiation | Inject via `IHttpClientFactory` |
| 9 | Replace `.Result` blocking calls | Use `await` throughout |
| 10 | Add `Microsoft.Extensions.Hosting.WindowsServices` | Enables `UseWindowsService()` for IIS/Windows SC hosting |

**New `.csproj`:**
```xml
<Project Sdk="Microsoft.NET.Sdk.Worker">
  <PropertyGroup>
    <TargetFramework>net8.0-windows</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
    <UserSecretsId>opensafety-async-service</UserSecretsId>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Microsoft.Extensions.Hosting" Version="8.0.1" />
    <PackageReference Include="Microsoft.Extensions.Hosting.WindowsServices" Version="8.0.0" />
    <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
  </ItemGroup>
</Project>
```

---

### 2.10 `OpenSafetyStateChecker` ? .NET 8 Worker Service (stub)

**Migration complexity: TRIVIAL**

Empty `ServiceBase` stub. Same pattern as �2.9 but no business logic.

---

### 2.11 `OpenSafetyDistributedService.Tests` ? net8.0 xUnit

**Migration complexity: LOW**

Currently contains 1 empty test and 2 commented-out test methods. All WCF `ServiceClient` references become `HttpClient` calls to the new API.

**New `.csproj`:**
```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <IsPackable>false</IsPackable>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Microsoft.AspNetCore.Mvc.Testing" Version="8.0.8" />
    <PackageReference Include="Microsoft.NET.Test.Sdk" Version="17.11.1" />
    <PackageReference Include="Moq" Version="4.20.72" />
    <PackageReference Include="FluentAssertions" Version="6.12.1" />
    <PackageReference Include="xunit" Version="2.9.2" />
    <PackageReference Include="xunit.runner.visualstudio" Version="2.8.2">
      <IncludeAssets>runtime; build; native; contentfiles; analyzers; buildtransitive</IncludeAssets>
      <PrivateAssets>all</PrivateAssets>
    </PackageReference>
  </ItemGroup>
  <ItemGroup>
    <ProjectReference Include="..\OpenSafetyDistributedService\OpenSafetyDistributedService.csproj" />
  </ItemGroup>
</Project>
```

---

### 2.12 `OpenSafetyFrontend.Tests` ? net8.0 xUnit

**Migration complexity: LOW**

Same as �2.11. Replace MSTest with xUnit; add `WebApplicationFactory<T>` for integration tests.

---

### 2.13 `ConsoleTest` ? `net8.0` Console (or retire)

**Migration complexity: LOW**

This is a developer scratch/debug console. Consider retiring it. If kept:
- Remove `System.Runtime.Remoting.Messaging` (removed in .NET Core)
- Remove `System.Web.Script.Serialization` (removed in .NET Core)
- Replace `WebRequest` with `HttpClient`

---

### 2.14 `JsonToSql` ? `net8.0` Console

**Migration complexity: LOW**

Already on `netcoreapp3.1`. Simply bump `<TargetFramework>` to `net8.0` and remove `Microsoft.Office.Interop.Excel` (not supported on .NET 8). Replace Excel interop with `ClosedXML` or `EPPlus`.

---

### 2.15 `OpenSafetyFrontedApplication` + `Fronted.Tests` + `WebFrontendTest` � Retire

These three projects are empty scaffolded stubs (`OutputType=Library` or `WinExe` with no meaningful source) targeting obsolete runtimes. They should be **removed from the solution**.

---

### 2.16 `WebApiOpenSafety` � Retire or Consolidate

Scaffolded ASP.NET Web API 2 placeholder with only `HomeController` and `ValuesController`. Functionality should be merged into `OpenSafetyDistributedService` (the new Web API host). **Remove from solution**.

---

## 3. Cross-Cutting Migration Topics

### 3.1 Fixing the Layer Violation in `OPenSafetyInfrastructure`

`GenericRepository.cs` in Infrastructure currently has a `ProjectReference` to `OpenSafetyFrontend`. This must be removed before migration is possible.

**Root cause:** `GenericRepository` imports `OpenSafetyFrontend.ServiceAdmin` to use `ServiceAdmin.BlocColonneDTO` for a specific query.

**Fix:** Move the shared DTO to `OpenSafetyContract` (where all DTOs belong), remove the UI project reference from Infrastructure.

---

### 3.2 Entity Framework 6 ? EF Core 8 Migration

This is the most technically involved sub-task.

#### 3.2.1 API Changes

| EF 6 | EF Core 8 |
|---|---|
| `using System.Data.Entity` | `using Microsoft.EntityFrameworkCore` |
| `EntityTypeConfiguration<T>` | `IEntityTypeConfiguration<T>` |
| `DbModelBuilder` | `ModelBuilder` |
| `modelBuilder.Configurations.Add(new XEtc())` | `modelBuilder.ApplyConfiguration(new XEtc())` |
| `this.ToTable("X")` | `builder.ToTable("X")` |
| `this.HasKey(e => e.ID)` | `builder.HasKey(e => e.ID)` |
| `this.Property(t => t.X).HasDatabaseGeneratedOption(...)` | `builder.Property(t => t.X).ValueGeneratedOnAdd()` |
| `this.Configuration.LazyLoadingEnabled = true` | `optionsBuilder.UseLazyLoadingProxies()` (via `Microsoft.EntityFrameworkCore.Proxies`) |
| `this.Configuration.ProxyCreationEnabled = true` | Same as above |
| `DbMigrationsConfiguration<TContext>` | Obsolete � EF Core uses `dotnet ef migrations` |
| `AutomaticMigrationsEnabled = false` | N/A in EF Core |
| `DbSet<T>.AddOrUpdate()` | `DbSet<T>.Upsert()` via `EFCore.BulkExtensions` or manual check |
| `Database.SetInitializer<T>()` | N/A � use `dbContext.Database.Migrate()` at startup |

#### 3.2.2 Migration Strategy

The 14 existing EF6 migrations cannot be used by EF Core. The recommended approach:

1. Ensure the **current production schema** is the baseline.
2. Run `dotnet ef migrations add InitialCreate --project OPenSafetyInfrastructure` � this generates a single EF Core migration representing the full schema.
3. Apply with `dotnet ef database update` or `dbContext.Database.Migrate()` at startup.
4. **Delete all 29 legacy EF6 migration files** after verifying schema equivalence.

#### 3.2.3 `OpenSafetyDBContext` changes

```csharp
// Before (EF6)
public class OpenSafetyDBContext : DbContext
{
    public OpenSafetyDBContext() : base("name=OpenSafetyDBContext") { }
}

// After (EF Core 8)
public class OpenSafetyDBContext : DbContext
{
    public OpenSafetyDBContext(DbContextOptions<OpenSafetyDBContext> options) : base(options) { }
}

// Registration in Program.cs
builder.Services.AddDbContext<OpenSafetyDBContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("OpenSafetyDBContext")));
```

---

### 3.3 WCF Service Contracts ? REST Contracts

All `[ServiceContract]` interfaces in `OpenSafetyContract` define the public API. The UriTemplate patterns in `[WebGet]` and `[WebInvoke]` map directly to ASP.NET Core route templates.

**Conversion pattern:**

```csharp
// Before (WCF � OpenSafetyContract)
[ServiceContract]
public interface IDicoService
{
    [OperationContract]
    [WebGet(UriTemplate = "GetSource/{sourceId}/{domain}/{loginNT}",
            ResponseFormat = WebMessageFormat.Json)]
    ResponseSourceDTO GetSource(string sourceId, string domain, string loginNT);
}

// After (ASP.NET Core � new DicoController in OpenSafetyDistributedService)
[ApiController]
[Route("api/dico")]
public class DicoController : ControllerBase
{
    private readonly IDicoService _dicoService;

    public DicoController(IDicoService dicoService) => _dicoService = dicoService;

    [HttpGet("GetSource/{sourceId}/{domain}/{loginNT}")]
    public ActionResult<ResponseSourceDTO> GetSource(string sourceId, string domain, string loginNT)
        => _dicoService.GetSource(sourceId, domain, loginNT);
}
```

---

### 3.4 WCF Client Proxies (`Service References`) ? Typed `HttpClient`

The frontend currently uses 6 auto-generated WCF proxy classes. These must be replaced with typed `HttpClient` services.

**Conversion pattern:**

```csharp
// Before (WCF proxy � OpenSafetyFrontend)
var client = new ServiceDico.DicoServiceClient();
var sources = client.GetAllSource(domain, loginNT);

// After (typed HttpClient � OpenSafetyFrontend)
// 1. Define a typed client in OpenSafetyFrontend
public class DicoApiClient
{
    private readonly HttpClient _client;
    public DicoApiClient(HttpClient client) => _client = client;

    public async Task<ResponseSourceDTO?> GetAllSourceAsync(string domain, string loginNT)
        => await _client.GetFromJsonAsync<ResponseSourceDTO>($"api/dico/GetAllSource/{domain}/{loginNT}");
}

// 2. Register in Program.cs
builder.Services.AddHttpClient<DicoApiClient>(client =>
    client.BaseAddress = new Uri(builder.Configuration["Endpoints:DicoApi"]!));
```

---

### 3.5 `System.Web` Removal

`System.Web` does not exist on .NET 8. Every usage must be replaced:

| Old (`System.Web`) | New (ASP.NET Core / .NET 8) |
|---|---|
| `HttpContext.Current` | Inject `IHttpContextAccessor`; use `.HttpContext` |
| `HttpContext.Current.Session["key"]` | `ISession` via `HttpContext.Session.GetString("key")` |
| `HttpContext.Current.Request` | `HttpContext.Request` |
| `HttpContext.Current.Response` | `HttpContext.Response` |
| `ConfigurationManager.AppSettings["key"]` | `IConfiguration["key"]` or `IOptions<T>` |
| `WebRequest.Create(uri)` | `IHttpClientFactory` / `HttpClient` |
| `JavaScriptSerializer` | `System.Text.Json.JsonSerializer` |
| `System.Web.Script.Serialization` | `System.Text.Json` or `Newtonsoft.Json` |
| `System.Web.Optimization` (BundleConfig) | LibMan + middleware or Vite/Webpack |
| `System.Web.Mvc.Controller` | `Microsoft.AspNetCore.Mvc.Controller` |
| `System.Web.Http.ApiController` | `Microsoft.AspNetCore.Mvc.ControllerBase` |
| `GlobalFilterCollection` / `HandleErrorAttribute` | `app.UseExceptionHandler()` |
| `RouteTable.Routes` | `app.MapControllerRoute()` |
| `AreaRegistration.RegisterAllAreas()` | `builder.Services.AddControllersWithViews()` + area attributes |

---

### 3.6 Configuration System Migration

All `AppSettings` from `Web.config` and `App.config` must move to `appsettings.json` with environment-specific overrides.

**Structure:**
```
appsettings.json                    ? shared defaults (no secrets)
appsettings.Development.json        ? dev overrides
appsettings.Production.json         ? prod overrides (secrets from Key Vault)
```

**Pattern:**
```json
// appsettings.json
{
  "Endpoints": {
    "DicoApi": "https://your-api-host/api/dico",
    "ElasticSearch": "http://your-elk-host:9200"
  },
  "AppSettings": {
    "OST_ADMIN": "OST_ADMIN",
    "OST_USER": "OST_USER",
    "DataPageSize": "10"
  },
  "ConnectionStrings": {
    "OpenSafetyDBContext": "placeholder-use-key-vault-in-prod"
  }
}
```

**Typed options class:**
```csharp
public class AppOptions
{
    public const string Section = "AppSettings";
    public string OST_ADMIN { get; set; } = string.Empty;
    public string OST_USER { get; set; } = string.Empty;
    public int DataPageSize { get; set; } = 10;
}

// Registration in Program.cs
builder.Services.Configure<AppOptions>(builder.Configuration.GetSection(AppOptions.Section));

// Usage via injection
public class MyService(IOptions<AppOptions> options) { }
```

---

### 3.7 Logging Migration (`log4net` ? `Microsoft.Extensions.Logging`)

| Old | New |
|---|---|
| `private static readonly ILog _log = LogManager.GetLogger(typeof(T))` | `private readonly ILogger<T> _logger;` injected via constructor |
| `_log.Debug("msg")` | `_logger.LogDebug("msg")` |
| `_log.Info("msg")` | `_logger.LogInformation("msg")` |
| `_log.Error("msg")` | `_logger.LogError("msg")` |
| `log4net.config` XML file | `appsettings.json` `Logging` section + Serilog sink configuration |

Add `Serilog.AspNetCore` as the structured logging sink for production:
```csharp
// Program.cs
builder.Host.UseSerilog((ctx, cfg) => cfg
    .ReadFrom.Configuration(ctx.Configuration)
    .Enrich.FromLogContext()
    .WriteTo.Console()
    .WriteTo.File("logs/opensafety-.log", rollingInterval: RollingInterval.Day));
```

---

### 3.8 Dependency Injection Consolidation

Replace all Unity registrations from `UnityConfig.cs` with `IServiceCollection` extensions.

**`Program.cs` for `OpenSafetyDistributedService`:**
```csharp
var builder = WebApplication.CreateBuilder(args);

// Infrastructure
builder.Services.AddDbContext<OpenSafetyDBContext>(opt =>
    opt.UseSqlServer(builder.Configuration.GetConnectionString("OpenSafetyDBContext")));

// Repositories
builder.Services.AddScoped<IDicoRepository, EFDicoRepository>();
builder.Services.AddScoped<IDataSourceRepository, EFDataRepository>();
builder.Services.AddScoped<IAcquisitionRepository, EFDicoRepository>();
builder.Services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));

// Application Services
builder.Services.AddScoped<IDicoService, DicoApplicationService>();
builder.Services.AddScoped<IDataService, DataApplicationService>();
builder.Services.AddScoped<IAcquisitionService, AcquisitionApplicationService>();
builder.Services.AddScoped<ICosmetochemService, CosmetochemApplicationService>();
builder.Services.AddScoped<IMpnetService, MpnetApplicationService>();
builder.Services.AddScoped<IMdmService, MdmApplicationService>();
builder.Services.AddScoped<ISynonymsService, SynonymsApplicationService>();
builder.Services.AddScoped<ISecurityService, SecurityService>();
builder.Services.AddScoped<IUnitOfWork, EFUnitOfWork>();

// Infrastructure clients
builder.Services.AddScoped<IMpnetRepository, WebApiMpnetRepository>();
builder.Services.AddScoped<IMdmRepository, WSMdmRepository>();
builder.Services.AddScoped<ISynonymsRepository, WSSynonymsRepository>();
builder.Services.AddScoped<IDataRepository, WebApiElasticSearch>();
builder.Services.AddScoped<ICosmetochemRepository, WSCosmetochemRepository>();

// HttpClient factories
builder.Services.AddHttpClient<WebApiMpnetRepository>();
builder.Services.AddHttpClient<WSMdmRepository>();

// AutoMapper
builder.Services.AddAutoMapper(typeof(DicoApplicationService).Assembly);

// Cache
builder.Services.AddMemoryCache();

// Auth
builder.Services.AddAuthentication(NegotiateDefaults.AuthenticationScheme).AddNegotiate();
builder.Services.AddAuthorization();

// Controllers + Swagger
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.Run();
```

---

## 4. Package Migration Table

### Core Package Replacements (All Projects)

| Old Package | Old Version | New Package | New Version | Notes |
|---|---|---|---|---|
| `EntityFramework` | 6.1.3 | `Microsoft.EntityFrameworkCore` | 8.0.8 | Full API rewrite |
| `EntityFramework.SqlServer` | 6.1.3 | `Microsoft.EntityFrameworkCore.SqlServer` | 8.0.8 | |
| `NEST` | 6.1.0 | `Elastic.Clients.Elasticsearch` | 8.14.6 | New official client; NEST deprecated |
| `Elasticsearch.Net` | 6.1.0 | _(bundled in new client)_ | � | |
| `AutoMapper` | 5.1.1 | `AutoMapper` | 13.0.1 | Breaking: `Mapper.Initialize()` removed |
| `log4net` | 2.0.8 | `Serilog.AspNetCore` + `Microsoft.Extensions.Logging` | 8.0.x | |
| `Unity` | 5.2.1 / 5.11.6 | _(built-in DI)_ `Microsoft.Extensions.DependencyInjection` | 8.0.1 | |
| `Unity.Mvc5` / `Unity.Mvc` | 1.2.3 / 5.11.1 | _(removed)_ | � | |
| `Microsoft.AspNet.Mvc` | 5.2.3�5.2.7 | `Microsoft.AspNetCore.Mvc` _(framework)_ | 8.0.x | |
| `Microsoft.AspNet.WebApi.*` | 5.2.x | _(ASP.NET Core Web API, built-in)_ | � | |
| `Microsoft.AspNet.Razor` | 3.2.x | _(ASP.NET Core Razor, built-in)_ | � | |
| `Swashbuckle` | 6.0.0-rc1 | `Swashbuckle.AspNetCore` | 6.8.1 | Different package for Core |
| `Owin` | 1.0 | _(removed)_ | � | Not needed in ASP.NET Core |
| `PagedList.Mvc` | 4.5.0 | `X.PagedList.Mvc.Core` | 9.1.2 | |
| `Newtonsoft.Json` | 6.0.4�12.0.3 | `Newtonsoft.Json` | 13.0.3 | Compatible upgrade |
| `ClosedXML` | 0.95.2 | `ClosedXML` | 0.102.2 | Supports .NET 8 |
| `DocumentFormat.OpenXml` | 2.9.1�2.10.1 | `DocumentFormat.OpenXml` | 3.1.0 | |
| `Microsoft.Web.Infrastructure` | 1.0 | _(removed)_ | � | `System.Web` only |
| `Microsoft.CodeDom.Providers.DotNetCompilerPlatform` | 2.0.x | _(removed)_ | � | Not needed on .NET 8 |
| `Microsoft.Net.Compilers` | 2.10.0 | _(removed)_ | � | Roslyn built in |
| `WebActivatorEx` | 2.2.0 | _(removed)_ | � | `System.Web` hook |
| `WebGrease` | 1.3�1.6 | _(removed)_ | � | `System.Web.Optimization` only |
| `Modernizr` | 2.6�2.8 | _(remove or evaluate)_ | � | Modern browsers don't need it |
| `Trirand.jqGrid` | 4.6.0 | _(no .NET 8 port � migrate to JS-only)_ | � | Use AG Grid or DataTables |
| `System.Runtime.Caching` | 4.6.0 | `Microsoft.Extensions.Caching.Memory` | 8.0.1 | |
| `FromHeaderAttribute` | 2.0.4 | _(built-in `[FromHeader]` in ASP.NET Core)_ | � | |
| `bootstrap` | 3.3.7 | `bootstrap` | 5.3.3 | Major UI API changes |
| `jQuery` | 1.10.2�3.3.1 | `jQuery` | 3.7.1 | Align all projects to same version |
| `Microsoft.ApplicationInsights.*` | 2.5.x | `Microsoft.ApplicationInsights.AspNetCore` | 2.22.0 | |

### Packages with No Replacement Needed (remove)

- `CommonServiceLocator` � Unity-specific
- `Microsoft.Practices.Unity` � old Unity namespace, fully replaced by `Microsoft.Extensions.DependencyInjection`
- `System.IO.FileSystem.Primitives` � built-in on .NET 8
- `System.Threading.Tasks.Extensions` � built-in on .NET 8
- `System.Runtime.CompilerServices.Unsafe` � built-in on .NET 8
- `System.Spatial` � OData-specific; remove if not needed
- `Bootstrap.Datepicker`, `Bootstrap.Multiselect`, etc. � client-side only; manage via LibMan

---

## 5. Breaking Changes Catalogue

### 5.1 `System.Web` Removal (Affects: All web projects)

All types in the `System.Web` namespace are removed. Every usage across 578 `.cs` files referencing `System.Web` must be addressed. Key occurrences identified:

- `HttpContext.Current` ? 15+ files (SecurityService, OPSConfigHelper, RestHelper, DataHelper, controllers)
- `Session["key"]` ? 10+ files
- `ConfigurationManager` ? 30+ files
- `WebRequest`/`WebResponse` ? 3 files (RestHelper)
- `JavaScriptSerializer` ? 2 files (RestHelper)
- `BundleConfig`/`BundleTable` ? 1 file
- `GlobalFilterCollection` ? 1 file

### 5.2 WCF Not Available on .NET 8 (Affects: Contract, DistributedService, Frontend, Tests)

- `System.ServiceModel` NuGet package provides limited client-side WCF support via `CoreWCF.Http` but **WCF server hosting is not supported** on .NET 8 without `CoreWCF` which is a community project with incomplete feature coverage.
- **Decision: Full WCF ? REST API migration** (not `CoreWCF`).
- All `[ServiceContract]`, `[OperationContract]`, `[WebGet]`, `[WebInvoke]`, `[FaultContract]`, `FaultException` usages must be removed.

### 5.3 AutoMapper Static API Removed (Affects: Application, Frontend)

```csharp
// Removed in AutoMapper 9+
Mapper.Initialize(cfg => { ... });
Mapper.Map<T>(source);

// New pattern
var config = new MapperConfiguration(cfg => cfg.AddProfile<MyProfile>());
var mapper = config.CreateMapper();
// Or inject IMapper via DI after services.AddAutoMapper(assembly)
```

### 5.4 EF6 Migration Files Not Compatible with EF Core (Affects: Infrastructure)

All 14 existing migration classes inherit from `DbMigration` (EF6 API). They must be replaced by a new initial EF Core migration.

### 5.5 `System.Runtime.Remoting` Removed (Affects: ConsoleTest)

`System.Runtime.Remoting.Messaging` is removed in .NET Core / .NET 8. `ConsoleTest` uses it � must be removed.

### 5.6 `System.EnterpriseServices` Removed (Affects: Infrastructure, DistributedService)

Referenced in project files for COM+ / Transactions. Not available on .NET 8. Remove the reference.

### 5.7 `HttpClient.MaxRequestContentBufferSize` Removed (Affects: RestHelper, WsAsync)

`HttpClientHandler.MaxRequestContentBufferSize` was removed in .NET 5+. Remove those property assignments.

### 5.8 `PagedList.Mvc` for ASP.NET MVC 5 (Affects: Frontend)

`PagedList.Mvc` does not support ASP.NET Core. Replace with `X.PagedList.Mvc.Core`.

### 5.9 `Trirand.jqGrid` No .NET 8 Port (Affects: Frontend)

This package has no NuGet release targeting .NET Core / .NET 8. The jqGrid initialization must be converted to pure JavaScript/CDN loading without a .NET wrapper.

### 5.10 Global.asax Application Events (Affects: Frontend, DistributedService)

`Application_Start`, `Application_Error`, `Application_BeginRequest`, `Application_PostAuthorizeRequest` in `Global.asax.cs` must be rewritten as:

| Old `Global.asax` event | New ASP.NET Core equivalent |
|---|---|
| `Application_Start` | `Program.cs` startup code |
| `Application_Error` | `app.UseExceptionHandler(...)` middleware |
| `Application_BeginRequest` | Custom middleware or `app.Use(...)` |
| `Application_PostAuthorizeRequest` | `app.UseSession()` middleware positioning |

---

## 6. New Project File Format (SDK-Style)

All projects must move from legacy `<Project ToolsVersion="12.0">` to SDK-style format. The new format:
- Implicitly includes all `.cs` files in the project directory (no `<Compile Include="...">` needed)
- Replaces `packages.config` with `<PackageReference>` inline
- Removes `AssemblyInfo.cs` (auto-generated by SDK)
- Removes `<Import Project="$(MSBuildToolsPath)\Microsoft.CSharp.targets">` boilerplate

**Migration checklist per project:**

- [ ] Replace `<Project ToolsVersion="12.0" xmlns="...">` with `<Project Sdk="Microsoft.NET.Sdk">` (or `.Web` / `.Worker`)
- [ ] Replace `<TargetFrameworkVersion>v4.7.1</TargetFrameworkVersion>` with `<TargetFramework>net8.0</TargetFramework>`
- [ ] Delete `packages.config`; convert all packages to `<PackageReference>`
- [ ] Delete `AssemblyInfo.cs` from `Properties\` (attributes are auto-generated)
- [ ] Delete `<Compile Include="...">` items (implicit in SDK-style)
- [ ] Delete `<Content Include="...">` for `.cshtml` and static files
- [ ] Delete `<Import Project="$(MSBuildToolsPath)\Microsoft.CSharp.targets">` line
- [ ] Delete the `EnsureNuGetPackageBuildImports` target block
- [ ] Remove `SccProjectName`, `SccLocalPath`, `SccAuxPath`, `SccProvider` (TFS source control properties)

---

## 7. Step-by-Step Upgrade Procedure

### Phase 1 � Preparation (1 week)

```
1. Create a feature branch: git checkout -b feature/dotnet8-migration
2. Install tooling:
   - .NET 8 SDK (https://dot.net/download)
   - dotnet-upgrade-assistant (dotnet tool install -g upgrade-assistant)
   - EF Core CLI tools (dotnet tool install -g dotnet-ef)
3. Run the .NET Upgrade Assistant analysis (read-only):
   upgrade-assistant analyze OpenSafety.sln
4. Fix the layer violation in OPenSafetyInfrastructure:
   - Remove ProjectReference to OpenSafetyFrontend
   - Move shared DTO to OpenSafetyContract
5. Remove stub projects from solution:
   - OpenSafetyFrontedApplication
   - Fronted.Tests
   - WebFrontendTest
   - WebApiOpenSafety
```

### Phase 2 � Bottom-Up Library Migration (2�3 weeks)

Migrate in dependency order. Each step: convert project format ? swap NuGet packages ? fix breaking changes ? verify compile.

```
Step 1: OpenSafetyCrossCutting
  - Convert to SDK-style csproj targeting net8.0
  - Remove System.Web (HttpContext.Current in GenerateCsvFile)
  - Replace log4net with ILogger abstractions
  - Replace MemoryCache with IMemoryCache
  - Remove Unity stubs

Step 2: OpenSafetyDomainModel
  - Convert to SDK-style csproj
  - Remove Unity, ASP.NET MVC references

Step 3: OpenSafetyContract
  - Convert to SDK-style csproj
  - Remove [ServiceContract]/[OperationContract]/[WebGet] WCF attributes
  - Remove System.ServiceModel

Step 4: OPenSafetyInfrastructure
  - Convert to SDK-style csproj
  - Replace EntityFramework 6 with EF Core 8
  - Convert all EntityTypeConfiguration<T> to IEntityTypeConfiguration<T>
  - Generate new EF Core initial migration
  - Replace NEST 6 with Elastic.Clients.Elasticsearch 8
  - Remove Web References\MdmWS ASMX proxy
  - Implement WSMdmRepository with IHttpClientFactory
  - Inject DbContext via constructor (remove new OpenSafetyDBContext())

Step 5: OpenSafetyApplication
  - Convert to SDK-style csproj
  - Replace ConfigurationManager with IConfiguration
  - Replace log4net with ILogger
  - Replace HttpContext.Current.Session in SecurityService with IHttpContextAccessor
  - Update AutoMapper to v13 API (Profile-based, no static Mapper.Initialize)
  - Remove Unity stubs
```

### Phase 3 � API Host Migration (2�3 weeks)

```
Step 6: OpenSafetyDistributedService ? ASP.NET Core 8 Web API
  - Delete WCF service files (.svc, .svc.cs)
  - Delete Global.asax, Web.config, App_Start/UnityConfig.cs
  - Create Program.cs with full DI and middleware pipeline
  - Create appsettings.json
  - Create 8 API controllers (one per former WCF service)
  - Map WCF UriTemplates to [HttpGet]/[HttpPost] routes
  - Replace FaultException with ProblemDetails / IActionResult
  - Add Swashbuckle.AspNetCore for OpenAPI
  - Add Windows Authentication (Negotiate)
  - Delete OpenSafetyDependancyResolver project (merge content into Program.cs)

Step 7: Verify API endpoints with Swagger UI / curl
  - Test each former WCF method via the new REST endpoint
  - Validate JSON serialization output matches what the frontend expects
```

### Phase 4 � Frontend Migration (3�4 weeks)

```
Step 8: OpenSafetyFrontend ? ASP.NET Core 8 MVC
  - Delete Global.asax, Web.config
  - Delete App_Start/ (BundleConfig, FilterConfig, RouteConfig, WebApiConfig)
  - Delete Service References/ (6 WCF proxies)
  - Create Program.cs
  - Create appsettings.json
  - Create typed HttpClient classes (DicoApiClient, AdminApiClient, etc.)
  - Replace all WCF ServiceClient() calls with typed clients
  - Replace System.Web.Mvc references
  - Replace HttpContext.Current usages with IHttpContextAccessor
  - Replace Session access pattern
  - Update 83 Razor views (namespace changes, tag helpers)
  - Replace BundleConfig with LibMan (libman.json)
  - Replace HandleErrorAttribute with UseExceptionHandler middleware
  - Replace ConfigurationManager with IConfiguration
  - Evaluate Trirand.jqGrid ? migrate grids to pure JS
  - Replace PagedList.Mvc with X.PagedList.Mvc.Core

Step 9: WsAsynchronousSilicoState ? Worker Service
  - Replace ServiceBase with BackgroundService
  - Replace Timer with PeriodicTimer
  - Create Program.cs with Host.CreateDefaultBuilder
  - Delete ProjectInstaller files
  - Inject IHttpClientFactory
  - Convert blocking .Result calls to async/await
```

### Phase 5 � Tests & Validation (1�2 weeks)

```
Step 10: Update test projects to net8.0 + xUnit
Step 11: Write smoke tests for each API controller
Step 12: Run full regression on DEV environment
Step 13: Update Jenkins pipeline (see �9)
```

---

## 8. Code Change Examples

### 8.1 `OpenSafetyDBContext` (EF6 ? EF Core 8)

```csharp
// BEFORE (EF6 � System.Data.Entity)
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

public class OpenSafetyDBContext : DbContext
{
    public OpenSafetyDBContext() : base("name=OpenSafetyDBContext")
    {
        this.Configuration.ProxyCreationEnabled = true;
        this.Configuration.LazyLoadingEnabled = true;
        this.Configuration.AutoDetectChangesEnabled = true;
        this.Configuration.ValidateOnSaveEnabled = false;
    }

    protected override void OnModelCreating(DbModelBuilder modelBuilder)
    {
        modelBuilder.Conventions.Remove<PluralizingEntitySetNameConvention>();
        modelBuilder.Configurations.Add(new BlocETC());
        // ...
    }
}

// AFTER (EF Core 8 � Microsoft.EntityFrameworkCore)
using Microsoft.EntityFrameworkCore;

public class OpenSafetyDBContext : DbContext
{
    public OpenSafetyDBContext(DbContextOptions<OpenSafetyDBContext> options) : base(options) { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfiguration(new BlocETC());
        // ... all other configurations
    }
}
```

### 8.2 Entity Type Configuration (EF6 ? EF Core 8)

```csharp
// BEFORE (EF6 � System.Data.Entity.ModelConfiguration)
using System.Data.Entity.ModelConfiguration;

public class BlocETC : EntityTypeConfiguration<Bloc>
{
    public BlocETC()
    {
        this.ToTable("OPS_BLOC");
        this.HasKey(e => e.ID);
        this.Property(t => t.ID).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
        this.Property(e => e.NAME_EN).IsRequired();
    }
}

// AFTER (EF Core 8 � Microsoft.EntityFrameworkCore)
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

public class BlocETC : IEntityTypeConfiguration<Bloc>
{
    public void Configure(EntityTypeBuilder<Bloc> builder)
    {
        builder.ToTable("OPS_BLOC");
        builder.HasKey(e => e.ID);
        builder.Property(t => t.ID).ValueGeneratedOnAdd();
        builder.Property(e => e.NAME_EN).IsRequired();
    }
}
```

### 8.3 `SecurityService` � Replace `HttpContext.Current.Session`

```csharp
// BEFORE
using System.Web;

public class SecurityService : ISecurityService
{
    protected static string isRole
    {
        get => (string)HttpContext.Current.Session["isRole"];
        set => HttpContext.Current.Session["isRole"] = value;
    }
}

// AFTER
using Microsoft.AspNetCore.Http;

public class SecurityService : ISecurityService
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    public SecurityService(IHttpContextAccessor httpContextAccessor, ...)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    private string? IsRole
    {
        get => _httpContextAccessor.HttpContext?.Session.GetString("isRole");
        set
        {
            if (value is not null)
                _httpContextAccessor.HttpContext?.Session.SetString("isRole", value);
        }
    }
}
```

### 8.4 WCF Service ? ASP.NET Core Controller

```csharp
// BEFORE (WCF � OpenSafetyDicoWCFService.svc.cs)
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
public class OpenSafetyDicoWCFService : IDicoService
{
    private IDicoService _dicoService;

    public OpenSafetyDicoWCFService()
    {
        UnityConfig.RegisterComponents();
        _dicoService = UnityConfig.container.Resolve<IDicoService>();
    }

    public ResponseSourceDTO GetAllSource(string domain, string loginNT)
    {
        try { return _dicoService.GetAllSource(domain, loginNT); }
        catch (FaultException ex) { throw new FaultException(ex.Message); }
        catch (Exception ex) { throw new FaultException(ex.Message); }
    }
}

// AFTER (ASP.NET Core 8 � DicoController.cs)
[ApiController]
[Route("api/dico")]
public class DicoController : ControllerBase
{
    private readonly IDicoService _dicoService;
    private readonly ILogger<DicoController> _logger;

    public DicoController(IDicoService dicoService, ILogger<DicoController> logger)
    {
        _dicoService = dicoService;
        _logger = logger;
    }

    [HttpGet("GetAllSource/{domain}/{loginNT}")]
    public ActionResult<ResponseSourceDTO> GetAllSource(string domain, string loginNT)
    {
        var result = _dicoService.GetAllSource(domain, loginNT);
        return Ok(result);
    }
}
```

### 8.5 `RestHelper` � Replace `WebRequest` and Fix `HttpClient`

```csharp
// BEFORE
public static T ExecuterWebMethode<T>(string sURL)
{
    using (var handler = new HttpClientHandler())
    {
        handler.UseDefaultCredentials = true;
        handler.MaxRequestContentBufferSize = int.MaxValue;  // removed in .NET 5
        using (var client = new HttpClient(handler))         // socket exhaustion risk
        {
            var result = client.GetAsync(Uri.EscapeUriString(sURL));
            var responseMessage = result.Result;             // blocking .Result
            // ...
        }
    }
}

// AFTER
public class ApiClient
{
    private readonly HttpClient _client;

    public ApiClient(HttpClient client) => _client = client;

    public async Task<T?> GetAsync<T>(string url)
    {
        var response = await _client.GetAsync(Uri.EscapeUriString(url));
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<T>();
    }
}
// Registered via: builder.Services.AddHttpClient<ApiClient>();
```

### 8.6 `WsAsynchronousSilicoState` � `ServiceBase` ? `BackgroundService`

```csharp
// BEFORE
public partial class OpenSafetyAsynchronousService : ServiceBase
{
    private System.Timers.Timer _timer;

    protected override void OnStart(string[] args)
    {
        _timer = new System.Timers.Timer();
        _timer.Interval = 30000;
        _timer.Elapsed += _timer_Elapsed;
        _timer.AutoReset = false;
        _timer.Start();
    }
}

// AFTER
public class OpenSafetyWorkerService : BackgroundService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger<OpenSafetyWorkerService> _logger;
    private readonly IConfiguration _configuration;

    public OpenSafetyWorkerService(
        IHttpClientFactory httpClientFactory,
        ILogger<OpenSafetyWorkerService> logger,
        IConfiguration configuration)
    {
        _httpClientFactory = httpClientFactory;
        _logger = logger;
        _configuration = configuration;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromSeconds(30));
        while (await timer.WaitForNextTickAsync(stoppingToken))
        {
            try
            {
                var client = _httpClientFactory.CreateClient("CosmetochemApi");
                var url = _configuration["Endpoints:CosmetochemAnalyze"];
                var response = await client.GetAsync(url, stoppingToken);
                response.EnsureSuccessStatusCode();
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                _logger.LogError(ex, "Error in background job tick");
            }
        }
    }
}
```

---

## 9. CI/CD Pipeline Changes

### Current Pipeline (`Jenkinsfile-Api`, `Jenkinsfile-Front`)

- Uses a shared `DeployDotNetWithParams` library
- Builds with MSBuild and a publish profile (`BuildPublishProfile.pubxml`)
- Deploys to IIS on Windows servers

### Required Changes After Migration

| Item | Current | Required |
|---|---|---|
| Build tool | `MSBuild` (Visual Studio) | `dotnet build` / `dotnet publish` |
| Publish profile | `.pubxml` (Web Deploy) | `dotnet publish -c Release -o ./publish` |
| EF Migrations | Manual / EF6 PMC | `dotnet ef database update` as a pipeline step |
| Test runner | MSTest via MSBuild | `dotnet test --logger trx` |
| Target framework check | N/A | Add `<TargetFramework>net8.0</TargetFramework>` check |
| IIS hosting | `System.Web` / IIS integrated mode | `dotnet` + `AspNetCoreModule v2` in IIS (install `.NET 8 Hosting Bundle`) |

### Updated Jenkinsfile Pattern

```groovy
stage('Build') {
    steps {
        sh 'dotnet restore OpenSafety.sln'
        sh 'dotnet build OpenSafety.sln -c Release --no-restore'
    }
}
stage('Test') {
    steps {
        sh 'dotnet test OpenSafety.sln -c Release --no-build --logger trx'
    }
}
stage('Migrate DB') {
    steps {
        sh 'dotnet ef database update --project OPenSafetyInfrastructure --startup-project OpenSafetyDistributedService'
    }
}
stage('Publish API') {
    steps {
        sh 'dotnet publish OpenSafetyDistributedService -c Release -o ./publish/api'
    }
}
stage('Publish Frontend') {
    steps {
        sh 'dotnet publish OpenSafetyFrontend -c Release -o ./publish/frontend'
    }
}
```

### IIS Hosting Requirement

Install the **.NET 8 Windows Hosting Bundle** on all IIS servers (dev, pit, int, prod). Configure each IIS site's application pool:
- `.NET CLR Version` ? **No Managed Code**
- `Managed Pipeline Mode` ? **Integrated**
- Add `web.config` with `<aspNetCore processPath="dotnet" arguments=".\OpenSafetyFrontend.dll" stdoutLogEnabled="true" />`

---

## 10. Risk Register

| ID | Risk | Probability | Impact | Mitigation |
|---|---|---|---|---|
| R-01 | WCF client consumers outside this repo (other apps calling `.svc` endpoints) break | HIGH | CRITICAL | Audit all WCF callers; maintain parallel WCF (via CoreWCF) or version endpoints during transition |
| R-02 | EF Core migration generates wrong schema (missed column mapping, wrong conventions) | MEDIUM | HIGH | Compare EF Core scaffold output against production DB using `dotnet ef dbcontext scaffold`; run schema diff |
| R-03 | `Elastic.Clients.Elasticsearch` 8.x API incompatible with current Elasticsearch 6.x cluster | HIGH | HIGH | Check ES cluster version; upgrade ES to 8.x or use `NEST` 7.x as intermediate step |
| R-04 | `Trirand.jqGrid` has no replacement � grids break | HIGH | MEDIUM | Plan a UI sprint to replace grids with DataTables.js or AG Grid CE before migration |
| R-05 | 83 Razor views need review for namespace/tag helper changes | MEDIUM | MEDIUM | Run `dotnet build` after initial conversion; fix compiler errors systematically |
| R-06 | Windows Authentication (Negotiate/Kerberos) behaviour differences between IIS-integrated and Kestrel | MEDIUM | HIGH | Test on a staging IIS instance with `.NET 8 Hosting Bundle` before production |
| R-07 | AutoMapper 5 ? 13 breaking changes (profile API, `ResolveUsing` removed) | HIGH | MEDIUM | Run `AutoMapper.Extensions.Microsoft.DependencyInjection` profile validator in tests |
| R-08 | `System.Configuration.ConfigurationManager` usage in class-level static fields prevents DI injection | HIGH | MEDIUM | Systematic find-and-replace using grep; use `IOptions<T>` |
| R-09 | Session storage (`InProc`) must be re-evaluated for Kestrel multi-instance deployments | MEDIUM | MEDIUM | Use `services.AddDistributedMemoryCache()` + `services.AddSession()` |
| R-10 | `WsAsynchronousSilicoState` requires Windows Service host � verify `UseWindowsService()` works on target servers | LOW | LOW | Test on pit server before production |

---

## 11. Effort Estimate

| Task | Project(s) | Complexity | Estimated Effort |
|---|---|---|---|
| Preparation & layer violation fix | All | Low | 3 days |
| Remove stub projects | 4 projects | Trivial | 1 day |
| `OpenSafetyCrossCutting` migration | CrossCutting | Low | 3 days |
| `OpenSafetyDomainModel` migration | DomainModel | Low | 1 day |
| `OpenSafetyContract` � remove WCF attributes | Contract | Low | 2 days |
| `OPenSafetyInfrastructure` � EF6 ? EF Core 8 | Infrastructure | High | 8 days |
| `OPenSafetyInfrastructure` � NEST 6 ? Elastic 8 | Infrastructure | High | 5 days |
| `OpenSafetyApplication` migration | Application | Medium | 4 days |
| `OpenSafetyDistributedService` � WCF ? REST API (8 services) | DistributedService | Very High | 10 days |
| `OpenSafetyFrontend` � MVC 5 ? ASP.NET Core 8 MVC | Frontend | Very High | 15 days |
| `OpenSafetyFrontend` � Service References ? HttpClient | Frontend | High | 5 days |
| `WsAsynchronousSilicoState` � Worker Service | Async Service | Medium | 3 days |
| `OpenSafetyStateChecker` � Worker stub | StateChecker | Trivial | 1 day |
| `ConsoleTest` / `JsonToSql` updates | Utilities | Low | 1 day |
| Test projects (xUnit, Moq) | Tests | Low | 3 days |
| EF Migrations baseline (schema validation) | Infrastructure | Medium | 3 days |
| Razor view updates (83 views) | Frontend | Medium | 5 days |
| CI/CD pipeline updates | Jenkins | Low | 2 days |
| IIS Hosting Bundle deployment + validation | Ops | Low | 2 days |
| Integration / regression testing | All | Medium | 5 days |
| **Total** | | | **~81 developer-days (~16 weeks)** |

> Effort can be reduced to **~10 weeks** with 2 developers working in parallel on independent layers (Infrastructure + Application in parallel with Frontend conversion).

---

*Report generated: based on source analysis of `OpenSafety.sln` on branch `master`.*
