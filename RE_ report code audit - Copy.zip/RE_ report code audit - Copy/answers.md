# OpenSafety � Solution Analysis & .NET 8 Migration Report

> **Analysis scope:** Full automated + manual source analysis of `OpenSafety.sln`
> **Repository:** `https://gitlab.rd.loreal/opensafetyAdm/opensafety` (branch `master`)

---

## Table of Contents

1. [Number of Solutions](#1-number-of-solutions)
2. [Number of Projects](#2-number-of-projects)
3. [Number of Test Projects](#3-number-of-test-projects)
4. [Number of Batch Projects](#4-number-of-batch-projects)
5. [.NET Framework Projects](#5-net-framework-projects)
6. [.NET Standard Projects](#6-net-standard-projects)
7. [Number of Screens](#7-number-of-screens)
8. [Number of Classes � Code Behind](#8-number-of-classes--code-behind)
9. [Average Number of Lines � Code Behind](#9-average-number-of-lines--code-behind)
10. [Number of Classes � Other](#10-number-of-classes--other)
11. [Average Number of Lines � Other](#11-average-number-of-lines--other)
12. [Razor Components / Razor Engine](#12-razor-components--razor-engine)
13. [WebForm Components](#13-webform-components)
14. [Other Frameworks / Engines](#14-other-frameworks--engines)
15. [NuGet Packages](#15-nuget-packages)
16. [3rd Party Libraries](#16-3rd-party-libraries)
17. [Dead Code](#17-dead-code)
18. [Dependencies Not Supported in .NET Core](#18-dependencies-not-supported-in-net-core)
19. [Shared Code](#19-shared-code)
20. [Migration Plan / Strategy](#20-migration-plan--strategy)

---

## 1. Number of Solutions

| Metric | Value |
|---|---|
| **Solution files (`.sln`)** | **1** |
| Solution name | `OpenSafety.sln` |
| Location | Repository root |

---

## 2. Number of Projects

| Metric | Value |
|---|---|
| **Total `.csproj` files** | **18** |
| Active production projects | 10 |
| Stub / scaffold / empty projects (candidates for removal) | 4 |
| Developer-tool projects | 2 |
| Already on .NET Core | 1 (`JsonToSql` ? `netcoreapp3.1`) |

### Full Project Inventory

| # | Project | Role | Output | Framework | Status |
|---|---|---|---|---|---|
| 1 | `OpenSafetyCrossCutting` | Utilities, cache, email, Excel export | Library | .NET FW 4.7.1 | ? Active |
| 2 | `OpenSafetyDomainModel` | Domain entities, repository interfaces | Library | .NET FW 4.7.1 | ? Active |
| 3 | `OpenSafetyContract` | WCF service interfaces, 99 DTOs | Library | .NET FW 4.7.1 | ? Active |
| 4 | `OPenSafetyInfrastructure` | EF6 DbContext, Elasticsearch, HTTP clients | Library | .NET FW 4.7.1 | ? Active |
| 5 | `OpenSafetyApplication` | Application services, adapters, AutoMapper | Library | .NET FW 4.7.1 | ? Active |
| 6 | `OpenSafetyDependancyResolver` | Unity IoC wiring (single real `UnityConfig.cs`) | Library | .NET FW 4.7.1 | ? Active (dissolve into host) |
| 7 | `OpenSafetyDistributedService` | WCF REST host (8 `.svc` services) | Library (IIS) | .NET FW 4.7.1 | ? Active |
| 8 | `OpenSafetyFrontend` | ASP.NET MVC 5 + Web API 2 web application | Library (IIS) | .NET FW 4.7.1 | ? Active |
| 9 | `WsAsynchronousSilicoState` | Windows Service � periodic silico-state poller | WinExe | .NET FW 4.7.1 | ? Active |
| 10 | `OpenSafetyStateChecker` | Windows Service � stub (empty OnStart/OnStop) | WinExe | .NET FW 4.7.1 | ?? Empty |
| 11 | `ConsoleTest` | Developer scratch console (hardcoded URLs) | Exe | .NET FW 4.7.1 | ?? Dev tool |
| 12 | `JsonToSql` | ES ? SQL console utility | Exe | .NET Core 3.1 | ?? Dev tool |
| 13 | `OpenSafetyDistributedService.Tests` | Unit tests for WCF service layer | Library | .NET FW 4.7.1 | ?? Test |
| 14 | `OpenSafetyFrontend.Tests` | Unit tests for MVC frontend | Library | .NET FW 4.7.1 | ?? Test |
| 15 | `WebFrontendTest` | Scaffold stub � WCF service references only | Library (IIS) | .NET FW 4.7.1 | ? Remove |
| 16 | `OpenSafetyFrontedApplication` | Scaffold stub � empty MVC application | Library (IIS) | .NET FW **4.5.2** | ? Remove |
| 17 | `Fronted.Tests` | Empty stub � `static void Main` only | Exe | .NET FW **4.5.2** | ? Remove |
| 18 | `WebApiOpenSafety` | Scaffold placeholder � default `ValuesController` only | Library (IIS) | .NET FW 4.7.1 | ? Remove |

### Dependency Graph (Build Order)

```
[1] OpenSafetyCrossCutting          ? no project dependencies
[2] OpenSafetyDomainModel           ? CrossCutting
[3] OpenSafetyContract              ? CrossCutting, DomainModel
[4] OPenSafetyInfrastructure        ? CrossCutting, DomainModel, Frontend ?? LAYER VIOLATION
[5] OpenSafetyApplication           ? Contract, CrossCutting, DomainModel
[6] OpenSafetyDependancyResolver    ? Application, Contract, DomainModel, Infrastructure
[7] OpenSafetyDistributedService    ? Application, Contract, CrossCutting, DependancyResolver, DomainModel, Infrastructure
[8] OpenSafetyFrontend              ? CrossCutting, DomainModel, Application, Contract, Infrastructure
[9] WsAsynchronousSilicoState       ? Frontend (HTTP calls only)
```

---

## 3. Number of Test Projects

| Metric | Value |
|---|---|
| **Dedicated test projects** | **4** |
| Using MSTest `[TestMethod]` | 2 (`OpenSafetyDistributedService.Tests`, `OpenSafetyFrontend.Tests`) |
| Empty stubs with no tests | 2 (`Fronted.Tests`, `WebFrontendTest`) |
| Developer console used as manual test | 1 (`ConsoleTest`) |
| Files containing active `[TestMethod]` declarations | **2** |
| Active non-commented test methods | **~3** |
| Commented-out test methods | **5+** |
| Mocking framework | **None** |
| Code coverage | **~0%** |

> ?? The test suite is virtually non-existent. Both `OpenSafetyDistributedService.Tests` and `OpenSafetyFrontend.Tests` contain WCF client calls or trivial `Assert.IsNotNull` checks. No integration tests, no unit tests, no mocking.

---

## 4. Number of Batch Projects

| Metric | Value |
|---|---|
| **Batch / background-service projects** | **2** |

| Project | Pattern | Interval | Business Logic |
|---|---|---|---|
| `WsAsynchronousSilicoState` | `System.ServiceProcess.ServiceBase` + `System.Timers.Timer` | 30 s | Polls a WCF endpoint (`AnalyzeSilicoResult`) to trigger background silico-state analysis |
| `OpenSafetyStateChecker` | `System.ServiceProcess.ServiceBase` | � | Empty stub � `OnStart` / `OnStop` contain no logic |

> Both projects use `ServiceBase` which does not run on .NET 8. They must be migrated to `Microsoft.Extensions.Hosting.BackgroundService`.

---

## 5. .NET Framework Projects

| Target Framework | Count | Projects |
|---|---|---|
| **.NET Framework 4.7.1** | **15** | `ConsoleTest`, `OpenSafetyApplication`, `OpenSafetyContract`, `OpenSafetyCrossCutting`, `OpenSafetyDependancyResolver`, `OpenSafetyDistributedService`, `OpenSafetyDistributedService.Tests`, `OpenSafetyDomainModel`, `OpenSafetyFrontend`, `OpenSafetyFrontend.Tests`, `OPenSafetyInfrastructure`, `OpenSafetyStateChecker`, `WebApiOpenSafety`, `WebFrontendTest`, `WsAsynchronousSilicoState` |
| **.NET Framework 4.5.2** | **2** | `OpenSafetyFrontedApplication`, `Fronted.Tests` � ? **EOL since January 2016** |
| **.NET Core 3.1** | **1** | `JsonToSql` � ? **EOL since December 2022** |
| **.NET 8** | **0** | � |

> **All 18 projects require framework updates.** None target a supported .NET runtime. All legacy `.NET Framework` projects use the old `<Project ToolsVersion="12.0">` XML format with `packages.config` NuGet management.

---

## 6. .NET Standard Projects

| Metric | Value |
|---|---|
| **Projects targeting .NET Standard** | **0** |

No project in the solution targets `.NET Standard`. All class libraries target `.NET Framework` directly. The lack of a `.NET Standard` target is the root cause of the deep `System.Web` and `System.ServiceModel` coupling across library layers � APIs that simply do not exist on .NET Core.

---

## 7. Number of Screens

### Razor Views (`.cshtml`)

| Category | Count |
|---|---|
| **Total `.cshtml` files** | **119** |
| Full page views | **73** |
| Partial views (prefixed `_`, excluding layout/viewstart) | **36** |
| Layout files (`_Layout*.cshtml`) | **5** |
| `_ViewStart.cshtml` files | **5** |
| Total lines across all views | **14,614** |
| Average lines per view | **123** |

### Screen Distribution by Module

| Module / Area | Full Views | Partials | Description |
|---|---|---|---|
| **Admin area** | 29 | 14 | CRUD for Blocs, BlocVersionMetas, Colonnes, Metas, Sources, UserRoleAcquisitions |
| **Home** | 14 | 7 | Search, result, silico launch, batch silico, acquisition, NoSQL search |
| **HelpPage** (scaffold) | 19 | 0 | Auto-generated Web API help (not used in production) |
| **Shared** | 0 | 9 | Common headers, layouts, modals, error views |
| **Silico** | 4 | 2 | Silico-state analysis screens (code, draw, file) |
| **Acquisition** | 4 | 0 | Data acquisition editing |
| **BatchSilico** | 1 | 1 | Batch silico submission |
| **Other** | 2 | 3 | GlyphIcon page, generic content |

### Custom JavaScript Screens / Components

| File | Purpose |
|---|---|
| `open-safety-script.js` | Main search & result interactions |
| `ops-resultpage.js` | Result pagination and rendering |
| `ops-searchNoSql.js` | Elasticsearch / NoSQL search |
| `opsAcquisition.js` | Data acquisition form logic |
| `OpsGenericFunction.js` | Shared utility functions |
| `opsMarvinJS.js` | MarvinJS chemical structure sketcher integration |
| `OpsSilicoJS.js` | Silico analysis launch & status |
| `OpsAdminBloc.js` | Admin � Bloc management |
| `OpsAdminBlocVersionMeta.js` | Admin � BlocVersionMeta management |
| `OpsAdminColonne.js` | Admin � Column / Colonne management |
| `OpsAdminControlHelper.js` | Admin � shared helper functions |
| `OpsAdminMeta.js` | Admin � Meta management |
| `OpsAdminSource.js` | Admin � Source management |
| `OpsUserAcquisitionRole.js` | User acquisition role management |
| `customannotation.js` | Custom jQuery Validation annotations |

**Total custom JS files: 15 | Total JS files (including vendor): 141 | Total CSS files: 122**

---

## 8. Number of Classes � Code Behind

"Code-behind" is interpreted as **MVC controllers**, **Web API controllers**, and **WCF service implementations** � the classes directly bound to HTTP requests.

| Category | Count | Project(s) |
|---|---|---|
| **MVC Controllers** (`System.Web.Mvc.Controller`) | **14** | `OpenSafetyFrontend` |
| **Web API 2 Controllers** (`System.Web.Http.ApiController`) | **11** | `OpenSafetyFrontend/Api/` |
| **WCF Service implementations** (`.svc.cs`) | **8** | `OpenSafetyDistributedService` |
| **Total code-behind classes** | **33** | |

### MVC Controllers Detail

| Controller | Area | Key Responsibility |
|---|---|---|
| `HomeController` | Root | Search, results, silico launch, dashboard |
| `AcquisitionController` | Root | Data acquisition management (1,595 lines) |
| `BaseController` | Root | Session, role, and language base logic |
| `LanguageController` | Root | Culture switching |
| `OpsErrorController` | Root | Error page rendering |
| `OutputLevelController` | Root | Output level listing |
| `AdminBaseController` | Admin | Admin area base (auth, nav) |
| `AdminHomeController` | Admin | Admin dashboard |
| `BlocsController` | Admin | Bloc CRUD |
| `BlocVersionMetasController` | Admin | BlocVersionMeta CRUD |
| `ColonnesController` | Admin | Column CRUD (995 lines) |
| `MetasController` | Admin | Meta CRUD |
| `SourcesController` | Admin | Source management |
| `UserRoleAcquisitionsController` | Admin | User-role mapping |

### Web API 2 Controllers Detail (inline JSON/AJAX endpoints)

`BlocController`, `BlocVersionMetaController`, `CategorieController`, `ColonneController`, `ConditionCategorieController`, `MetaController`, `OutputLevelController`, `RequestGroupController`, `SourceController`, `SousFamilleController`, `UserRoleAcquisitionController`

### WCF Service Implementations

| Service | Contract Interface | Domain |
|---|---|---|
| `OpenSafetyDicoWCFService` | `IDicoService` | Dictionary / reference data |
| `OpenSafetyAdminWCFService` | `IAdminService` | Admin operations (1,780 lines) |
| `OpenSafetyAcquisitionWCFService` | `IAcquisitionService` | Data acquisition |
| `OpenSafetyDataWCFService` | `IDataService` | Elasticsearch data queries |
| `OpenSafetyCosmetochemWCFService` | `ICosmetochemService` | Cosmetochem API |
| `OpenSafetyMdmWCFService` | `IMDMService` | MDM (Master Data Management) |
| `OpenSafetyMpnetWCFService` | `IMpnetService` | MPnet ingredient API |
| `OpenSafetySynonymsWCFService` | `ISynonymsService` | Synonym lookup |

---

## 9. Average Number of Lines � Code Behind

| Metric | Value |
|---|---|
| **MVC + Web API controllers** | |
| Total lines (33 controller files) | **6,574** |
| **Average lines per controller** | **199** |
| Largest controller | `AcquisitionController.cs` � **1,595 lines** |
| Second largest | `HomeController.cs` � **946 lines** |
| Third largest | `ColonnesController.cs` � **995 lines** |
| **WCF Service implementations** | |
| Total lines (8 `.svc.cs` files) | **4,723** |
| **Average lines per WCF service** | **590** |
| Largest WCF service | `OpenSafetyAdminWCFService.svc.cs` � **1,780 lines** |
| Second largest | `OpenSafetyDicoWCFService.svc.cs` � **1,006 lines** |

> ?? Several code-behind files far exceed recommended class sizes (200�300 lines). `AcquisitionController` at 1,595 lines should be split into at minimum 3�4 focused controllers. The large WCF services each wrap large `ApplicationService` classes � they must be decomposed during migration to ASP.NET Core controllers.

---

## 10. Number of Classes � Other

| Category | Count |
|---|---|
| **Total hand-written `.cs` files (non-controller, non-generated, non-proxy)** | **463** |
| Application service classes | 41 (in `OpenSafetyApplication`) |
| Infrastructure / repository classes | 25 (in `OPenSafetyInfrastructure`) |
| Adapter classes | 13 |
| Domain entity classes | ~95 (in `OpenSafetyDomainModel`) |
| DTO / response classes | 93 (in `OpenSafetyContract`) |
| Interface definitions | 46 |
| Custom exception classes | 7 |
| EF6 entity type configuration classes | 31 |
| EF6 migration classes | 14 (+ 14 `.Designer.cs` + 1 `Configuration.cs`) |
| ViewModel / Model classes | ~25 |
| Helper / utility classes | 20 (CrossCutting + Frontend helpers) |
| Stub / empty classes (< 20 lines) | 22 |
| Embedded 3rd-party source (`SimpleJson.cs`) | 1 (2,127 lines) |

### Largest Non-Controller Classes

| File | Lines | Project | Issue |
|---|---|---|---|
| `CosmetochemApplicationService.cs` | **2,208** | Application | God class � must be decomposed |
| `WebApiElasticSearch.cs` | **2,132** | Infrastructure | God class � must be decomposed |
| `SimpleJson.cs` | **2,127** | CrossCutting | Embedded 3rd-party � dead code, remove |
| `DataApplicationService.cs` | **1,736** | Application | God class � must be decomposed |
| `DicoAdapter.cs` | **1,630** | Application | Oversized adapter |
| `AcquisitionApplicationService.cs` | **1,543** | Application | God class |
| `AdminApplicationService.cs` | **1,499** | Application | God class |
| `LayoutClass.cs` | **1,069** | Frontend | Large view-model helper |
| `EFDataRepository.cs` | **961** | Infrastructure | Contains inline query logic |
| `DicoApplicationService.cs` | **927** | Application | Needs splitting |
| `EFDicoRepository.cs` | **783** | Infrastructure | |
| `RestHelper.cs` | **527** | Frontend | Static helper � anti-pattern |

---

## 11. Average Number of Lines � Other

| Metric | Value |
|---|---|
| Total lines across 463 non-controller hand-written files | **40,099** |
| **Average lines per non-controller class** | **87** |
| Total lines across all 578 `.cs` files | **~78,636** |
| Estimated non-blank, non-comment code lines | **~65,019** |
| Comment lines | **~3,230** |
| Blank lines | **~10,387** |
| `#nullable enable` annotations | **0** (none in the entire codebase) |
| `async`/`await` usage | **3 files** out of 578 (~0.5%) |

---

## 12. Razor Components / Razor Engine

### Engine

| Item | Value |
|---|---|
| View engine | **Razor � ASP.NET MVC 5** (`Microsoft.AspNet.Razor` 3.2.x / `System.Web.Mvc`) |
| Tag Helpers | **0** � The project uses only the legacy `@Html.*` helper syntax |
| Razor Pages | **0** � Strictly MVC Controller + View pattern throughout |
| Blazor components | **0** |

### View Technology Statistics

| Metric | Count |
|---|---|
| Views using `Html.BeginForm` / `Html.ActionLink` etc. | **30** |
| Views using `Ajax.BeginForm` / `Ajax.ActionLink` | **10** |
| Views using ASP.NET Core Tag Helpers (`asp-action`, etc.) | **0** |
| Views referencing WCF proxy DTOs (`ServiceAdmin.*`, `ServiceDico.*`) | **12+** |
| Views using Bootstrap 3 panel/glyphicon classes | **37** |
| Views using Bootstrap 3 `col-xs-*` grid classes | **3** |
| Views using KnockoutJS `data-bind` | **2** |
| Views integrating MarvinJS chemical sketcher | **4** |
| Views using `Trirand.jqGrid` | **7** |
| Views using `PagedList` | **1** |

### Razor Migration Implications

- `@Html.*` helpers are compatible with ASP.NET Core MVC but require updating the `using` directive from `System.Web.Mvc.Html` to `Microsoft.AspNetCore.Mvc.Rendering`.
- `@Ajax.*` helpers require adding `Microsoft.jQuery.Unobtrusive.Ajax` NuGet package for ASP.NET Core.
- The 12+ views that reference `@model OpenSafetyFrontend.ServiceAdmin.*` (WCF proxy namespace) must have their `@model` updated to point to the equivalent DTO types from `OpenSafetyContract`.
- Bootstrap 3 CSS classes (`panel-*`, `glyphicon-*`) are removed in Bootstrap 5 � 37 views require CSS class updates if Bootstrap is upgraded.

---

## 13. WebForm Components

| Technology | Count |
|---|---|
| `.aspx` WebForms pages | **0** |
| `.ascx` WebForms user controls | **0** |
| `.asmx` ASMX web services | **0** |
| Code-behind `.aspx.cs` files | **0** |

> The solution contains **no WebForms whatsoever**. The entire UI layer is ASP.NET MVC 5 with Razor views. The only unusual file is `ConsoleTest/System/Web/HttpContext.cs`, a manually created 6-line fake stub that was written to suppress a compile error in the console project � it declares an empty `System.Web.HttpContext` class to satisfy a `using` directive.

---

## 14. Other Frameworks / Engines

### Service Communication Layer

| Technology | Usage | .NET 8 Compatible | Action |
|---|---|---|---|
| **WCF � Windows Communication Foundation** | 8 REST-JSON services (`webHttpBinding`) hosted in IIS via `.svc` files; `[ServiceContract]` / `[WebGet]` / `[WebInvoke]` attributes on 9 service interfaces | ? No (server hosting) | Replace all 8 services with ASP.NET Core Web API controllers |
| **WCF generated client proxies** (`Service References`) | 6 proxies in `OpenSafetyFrontend`, 3 in `ConsoleTest`, 2 in `OpenSafetyDistributedService.Tests` � **14 `Reference.cs` files** total | ? No | Replace with typed `HttpClient` via `IHttpClientFactory` |
| **ASMX Web Reference** | 1 proxy in `OPenSafetyInfrastructure/Web References/MdmWS/Reference.cs` | ? No | Replace with `IHttpClientFactory`-based `WSMdmRepository` |
| **ASP.NET Web API 2** (`System.Web.Http.ApiController`) | 11 inline API controllers in `OpenSafetyFrontend/Api/` | ? No (`System.Web.Http`) | Migrate to `Microsoft.AspNetCore.Mvc.ControllerBase` |
| **OWIN** (`Owin`, `IAppBuilder`) | Referenced in DI config files for middleware bootstrapping | ? No | Remove entirely � not needed in ASP.NET Core |

### ORM / Data Access

| Technology | Usage | .NET 8 Compatible | Action |
|---|---|---|---|
| **Entity Framework 6** (`System.Data.Entity`) | Primary ORM � **65 files**, `OpenSafetyDBContext`, 31 `EntityTypeConfiguration<T>` classes, 14 migrations | ? No | Migrate to EF Core 8 |
| **NEST 6.1 + Elasticsearch.Net 6.1** | Elasticsearch client in `WebApiElasticSearch.cs` (~2,132 lines) and `WSCosmetochemRepository.cs` | ? No (deprecated) | Replace with `Elastic.Clients.Elasticsearch` 8.x |
| **Direct SQL** | `EFDataRepository.cs` contains raw SQL strings for complex queries | ?? Review | Replace with EF Core `FromSqlRaw` or Dapper |

### Dependency Injection

| Technology | Usage | .NET 8 Compatible | Action |
|---|---|---|---|
| **Unity IoC** (v4.0.1 / v5.2.1 / v5.11.6 � 3 versions in use) | DI container; real registration in `OpenSafetyDependancyResolver\UnityConfig.cs`; **7 additional empty stub copies** in other projects | ?? Unmaintained | Replace with `Microsoft.Extensions.DependencyInjection` (built-in) |

### Logging

| Technology | Usage | .NET 8 Compatible | Action |
|---|---|---|---|
| **log4net 2.0.8** | Used in **50 files** via static `ILog _log = LogManager.GetLogger(typeof(T))` pattern | ?? Core port exists | Replace with `Microsoft.Extensions.Logging.Abstractions` + `ILogger<T>` injection; use Serilog as the sink |

### Object Mapping

| Technology | Usage | .NET 8 Compatible | Action |
|---|---|---|---|
| **AutoMapper 5.1.1** | Used in **18 files**; uses the removed static `Mapper.Initialize()` API | ?? Upgrade needed | Upgrade to AutoMapper 13.x; switch to `new MapperConfiguration()` + `services.AddAutoMapper()` |

### UI / Front-End Frameworks

| Technology | Version | Usage | .NET 8 Compatible | Action |
|---|---|---|---|---|
| **Bootstrap** | 3.0.0 / 3.3.7 | All 37+ views with Bootstrap 3 CSS classes | ? (pure CSS/JS) | Upgrade to 5.x (CSS class breaking changes) |
| **jQuery** | 1.10.2 / 3.3.1 (mixed) | All views | ? (pure JS) | Align to 3.7.x |
| **Trirand.jqGrid** | 4.6.0 | 7 views use the .NET server-side wrapper | ? No .NET 8 port | Migrate to pure-JS grid (DataTables.js or AG Grid CE) |
| **MarvinJS** | External CDN | Chemical structure sketcher in 4 views | ? (pure JS, no .NET dependency) | No change |
| **KnockoutJS** | 2.2.0 | 2 views using `data-bind` | ? (pure JS) | Upgrade or replace |
| **Modernizr** | 2.6.2 / 2.8.3 | Client-side feature detection | ? (pure JS) | Remove (obsolete for modern browsers) |
| **FontAwesome** | 4.7.0 | Icons across all views | ? (pure CSS/font) | Upgrade to 6.x |
| **PagedList.Mvc** | 4.5.0 | Server-side pagination helper | ? No (MVC 5 only) | Replace with `X.PagedList.Mvc.Core` |
| **Spin.js** | 2.3.2 | Loading spinner | ? (pure JS) | Keep or replace with CSS |

### Configuration & Serialization

| Technology | Usage | .NET 8 Compatible | Action |
|---|---|---|---|
| **`System.Configuration.ConfigurationManager`** | **27 files** read `AppSettings` via static fields | ? Not default on .NET 8 | Replace with `IConfiguration` / `IOptions<T>` |
| **Newtonsoft.Json** | 4 different versions (4.5.11, 6.0.4, 11.0.1, 12.0.3) across projects | ? (upgrade) | Align all to 13.x |
| **`System.Web.Script.Serialization.JavaScriptSerializer`** | 3 files (`RestHelper.cs`, `ConsoleTest`) | ? Removed | Replace with `System.Text.Json.JsonSerializer` |
| **`SimpleJson.cs`** | Embedded 2,127-line MIT JSON parser in `OpenSafetyCrossCutting` | ?? Redundant | Delete � superseded by `Newtonsoft.Json` and `System.Text.Json` |

### Caching

| Technology | Usage | .NET 8 Compatible | Action |
|---|---|---|---|
| **`System.Runtime.Caching.MemoryCache`** | `CacheManager.cs` in CrossCutting | ?? Available via NuGet but not idiomatic | Replace with `Microsoft.Extensions.Caching.Memory.IMemoryCache` |

### Email

| Technology | Usage | .NET 8 Compatible | Action |
|---|---|---|---|
| **`System.Net.Mail.SmtpClient`** | `OpsEmailSender.cs` in CrossCutting | ?? Deprecated since .NET 5 | Replace with `MailKit` |

### CI/CD

| Technology | Usage | Action |
|---|---|---|
| **Jenkins** | `Jenkinsfile-Api`, `Jenkinsfile-Front`, `Jenkinsfile-Certificate` | Update to use `dotnet build` / `dotnet publish` / `dotnet test` |
| **MSBuild + `.pubxml` (Web Deploy)** | Current build/publish | Replace with `dotnet publish -c Release -o ./publish` |

---

## 15. NuGet Packages

**Total unique packages: 76 | Total package references across all `packages.config` files: ~150**

> ?? Version fragmentation: `Newtonsoft.Json` has **4 versions**, `Unity` has **3 versions**, `Microsoft.AspNet.Mvc` has **4 versions**, `log4net` has **2 versions**, `WebGrease` has **3 versions**.

| Package | Version(s) Found | Compatible with .NET 8 |
|---|---|---|
| `Antlr` | 3.4.1, 3.5.0 | ? (WebGrease dependency � remove) |
| `AutoMapper` | 5.1.1 | ?? Upgrade to 13.x |
| `bootstrap` | 3.0.0, 3.3.7 | ? (upgrade to 5.x) |
| `Bootstrap.Datepicker` | 1.8.0.1 | ? (pure JS) |
| `Bootstrap.Multiselect` | 0.9.13 | ? (pure JS) |
| `bootstrap-slider` | 5.0.13 | ? (pure JS) |
| `bootstrap-toggle.less` | 2.2.0.1 | ? (pure JS) |
| `bootstrap-tokenfield` | 0.12.1 | ? (pure JS) |
| `ClosedXML` | 0.95.2 | ?? Upgrade to 0.102+ |
| `CommonServiceLocator` | 1.3 | ? (Unity dependency � remove) |
| `DocumentFormat.OpenXml` | 2.9.1, 2.10.1 | ?? Upgrade to 3.x |
| `Elasticsearch.Net` | 6.1.0 | ? Replace with `Elastic.Clients.Elasticsearch` 8.x |
| `EntityFramework` | 6.1.3 | ? Replace with EF Core 8 |
| `ExcelNumberFormat` | 1.0.10 | ? |
| `FastMember` | 1.5.0 | ? |
| `FontAwesome` | 4.7.0 | ? (upgrade to 6.x) |
| `FromHeaderAttribute` | 2.0.4 | ? (built-in in ASP.NET Core) |
| `glyphicon` | 1.0.1 | ? (removed from Bootstrap 4+) |
| `jQuery` | 1.10.2, 3.3.1 | ? (upgrade to 3.7.x) |
| `jquery.datatables` | 1.10.15 | ? (pure JS) |
| `jQuery.Steps` | 1.1.0 | ? (pure JS) |
| `jQuery.UI.Combined` | 1.12.1 | ? (pure JS) |
| `jQuery.Validation` | 1.10.0, 1.11.1, 1.16.0 | ? (upgrade to 1.21.x) |
| `JSZip` | 3.1.5 | ? (pure JS) |
| `knockoutjs` | 2.2.0 | ? (pure JS, upgrade to 3.5.x) |
| `log4net` | 2.0.5, 2.0.8 | ?? Replace with Serilog + `ILogger<T>` |
| `Markdown` | 2.2.1 | ? |
| `Microsoft.ApplicationInsights.*` | 2.4�2.5.1 | ?? Replace with `Microsoft.ApplicationInsights.AspNetCore` 2.22+ |
| `Microsoft.AspNet.Mvc` | 4.0, 5.2.3, 5.2.4, 5.2.7 | ? Replace with ASP.NET Core MVC (built-in) |
| `Microsoft.AspNet.Razor` | 2.0�3.2.7 | ? Built-in in ASP.NET Core |
| `Microsoft.AspNet.Web.Optimization` | 1.0.0, 1.1.3 | ? Replace with LibMan |
| `Microsoft.AspNet.WebApi.*` | 4.0�5.2.4 | ? Replace with ASP.NET Core (built-in) |
| `Microsoft.AspNet.WebPages` | 2.0�3.2.7 | ? Built-in in ASP.NET Core |
| `Microsoft.CodeDom.Providers.DotNetCompilerPlatform` | 2.0.0, 2.0.1 | ? Remove (Roslyn built-in on .NET 8) |
| `Microsoft.CSharp` | 4.7.0 | ? |
| `Microsoft.Data.Edm` | 5.2.0 | ? (OData � remove if unused) |
| `Microsoft.Data.OData` | 5.2.0 | ? (OData � remove if unused) |
| `Microsoft.jQuery.Unobtrusive.Ajax` | 2.0, 3.2.6 | ?? Use ASP.NET Core version |
| `Microsoft.jQuery.Unobtrusive.Validation` | 2.0, 3.2.3 | ?? Use ASP.NET Core version |
| `Microsoft.Net.Compilers` | 2.10.0 | ? Remove (built-in on .NET 8) |
| `Microsoft.Net.Http` | 2.0.20710 | ? Remove (built-in) |
| `Microsoft.Web.Infrastructure` | 1.0 | ? Remove (System.Web only) |
| `Modernizr` | 2.6.2, 2.8.3 | ? (remove � obsolete) |
| `NEST` | 6.1.0 | ? Replace with `Elastic.Clients.Elasticsearch` 8.x |
| `Newtonsoft.Json` | 4.5.11, 6.0.4, 11.0.1, 12.0.3 | ? (align all to 13.x) |
| `Owin` | 1.0 | ? Remove (not needed in .NET 8) |
| `PagedList` | 1.17.0 | ?? Replace with `X.PagedList` |
| `PagedList.Mvc` | 4.5.0 | ? Replace with `X.PagedList.Mvc.Core` |
| `popper.js` | 1.14.3 | ? (pure JS, upgrade) |
| `Respond` | 1.2.0 | ? (pure JS � remove for modern browsers) |
| `Spin.js` | 2.3.2 | ? (pure JS) |
| `Swashbuckle` | 6.0.0-rc1-final | ? Replace with `Swashbuckle.AspNetCore` 6.8.x |
| `System.IO.Packaging` | 4.5.0, 4.7.0 | ? (built-in in .NET 8) |
| `System.Runtime.Caching` | 4.6.0 | ?? Replace with `IMemoryCache` |
| `System.Runtime.CompilerServices.Unsafe` | 4.5.2 | ? (built-in in .NET 8) |
| `System.Spatial` | 5.2.0 | ? (OData � remove if unused) |
| `System.Threading.Tasks.Extensions` | 4.5.2 | ? (built-in in .NET 8) |
| `Trirand.jqGrid` | 4.6.0 | ? No .NET 8 port � migrate to JS-only grid |
| `Unity` | 4.0.1, 5.2.1, 5.11.6 | ?? Unmaintained � replace with built-in DI |
| `Unity.Abstractions` | 5.11.1 | ?? Remove |
| `Unity.Container` | 5.11.1 | ?? Remove |
| `Unity.Interception` | 5.11.1 | ?? Remove |
| `Unity.Mvc` | 5.11.1 | ? Remove |
| `Unity.Mvc5` | 1.2.3 | ? Remove |
| `WebActivatorEx` | 2.2.0 | ? Remove (System.Web startup hook) |
| `WebGrease` | 1.3.0, 1.5.2, 1.6.0 | ? Remove (System.Web.Optimization only) |

---

## 16. 3rd Party Libraries

### Commercial / Proprietary

| Library | Version | Usage | .NET 8 Status | Action |
|---|---|---|---|---|
| **Trirand.jqGrid** | 4.6.0 | Server-side grid in 7 views | ? No .NET 8 port | Migrate to AG Grid Community or DataTables.js (pure JS) |
| **MarvinJS** | External CDN | Chemical structure sketcher in 4 views | ? Pure JS � no .NET dependency | No change needed |

### Open Source � Must Replace

| Library | Version | Reason | Replacement |
|---|---|---|---|
| `NEST` / `Elasticsearch.Net` | 6.1.0 | NEST deprecated; ES 6.x EOL | `Elastic.Clients.Elasticsearch` 8.x |
| `EntityFramework` | 6.1.3 | No .NET 8 support | `Microsoft.EntityFrameworkCore` 8.x |
| `Unity` | 4.0.1 / 5.2.1 / 5.11.6 | Unmaintained; not idiomatic in .NET 8 | `Microsoft.Extensions.DependencyInjection` (built-in) |
| `log4net` | 2.0.8 | Not idiomatic on .NET 8; static API | `Serilog.AspNetCore` + `Microsoft.Extensions.Logging` |
| `AutoMapper` | 5.1.1 | Static `Mapper.Initialize()` removed in v9 | `AutoMapper` 13.x + `AutoMapper.Extensions.Microsoft.DependencyInjection` |
| `PagedList.Mvc` | 4.5.0 | MVC 5 only | `X.PagedList.Mvc.Core` 9.x |
| `Swashbuckle` | 6.0.0-rc1 | Wrong package (Web API 2) | `Swashbuckle.AspNetCore` 6.8.x |

### Open Source � Upgrade

| Library | Current | Target | Breaking Changes |
|---|---|---|---|
| `Newtonsoft.Json` | 4.5�12.0 (4 versions) | 13.0.3 | Backward-compatible |
| `ClosedXML` | 0.95.2 | 0.102.2 | Some API surface changes |
| `DocumentFormat.OpenXml` | 2.9.1�2.10.1 | 3.1.0 | Namespace reorganisation |
| `bootstrap` | 3.3.7 | 5.3.3 | CSS grid, component API breaking changes |
| `jQuery` | 1.10.2 / 3.3.1 | 3.7.1 | Align to single version |
| `FontAwesome` | 4.7.0 | 6.6.0 | Icon name changes |

---

## 17. Dead Code

### Confirmed Dead / Unused Code

| Category | Count | Details |
|---|---|---|
| **Stub `UnityConfig.cs`** (empty DI registrations) | **7 copies** | In `OpenSafetyApplication`, `OpenSafetyContract`, `OpenSafetyCrossCutting`, `OpenSafetyDependancyResolver/App_Start`, `OpenSafetyDistributedService`, `OpenSafetyDomainModel`, `OPenSafetyInfrastructure` � all register nothing |
| **Stub projects** with no meaningful source | **4 projects** | `WebFrontendTest`, `OpenSafetyFrontedApplication`, `Fronted.Tests`, `WebApiOpenSafety` |
| **Duplicate `FilterConfig.cs`** | **4 copies** | Identical boilerplate in Application, Contract, CrossCutting, DependancyResolver |
| **Duplicate `RouteConfig.cs`** | **4 copies** | Identical boilerplate across projects |
| **Duplicate `AutoMapperConfig.cs`** | **2 copies** | Application and Frontend/Admin areas |
| **Duplicate `UnauthorizedException.cs`** | **2 copies** | CrossCutting and Application |
| **`SimpleJson.cs`** | **1 file / 2,127 lines** | Embedded MIT JSON parser � superseded by `Newtonsoft.Json` which is already a dependency |
| **Files with `throw new NotImplementedException()`** | **16 files** | Methods declared but never implemented (including in domain entities, services, and infrastructure) |
| **`OpenSafetyStateChecker`** | **1 project** | `OnStart` / `OnStop` are empty � no logic ever written |
| **`DicoDomainSpecification.cs`** | **1 file** | Specification pattern class � never implemented, never called |
| **`IRepository<TEntity>` / `ISpecification<TEntity>`** | **2 interfaces** | Specification pattern defined but no repository implements `IRepository` |
| **`ConsoleTest/System/Web/HttpContext.cs`** | **1 file** | Fake 6-line `System.Web.HttpContext` stub created to suppress a compiler error |
| **`DataAdapter.cs` / `MDMAdapter.cs` / `DicoAdapter.cs`** (stub versions) | **3 files** | Empty or near-empty adapter stubs with no implementation |
| **Files < 20 lines** (stub/empty) | **192 files** | Mix of empty DTOs, placeholder classes, empty config stubs |
| **Commented-out code blocks** | **18+ files** | Entire methods, route configurations, DI extension methods commented out |

### Partially Dead Code

| Item | Notes |
|---|---|
| `OpenSafetyDistributedService.Tests` | Test methods present but all assertions are commented out or trivially `Assert.IsNotNull` |
| `ConsoleTest` | Developer scratch project with hardcoded internal server URLs � not part of CI/CD |
| OWIN references (in config / DI) | `Owin` package imported but the IAppBuilder pipeline is never actually configured |
| `DomainService` classes (`DicoDomainService`, `DataDomainService`) | Classes exist and are instantiated but contain only constructor logic; no business methods |
| `HelpPage` area (19 views) | Auto-generated Web API help scaffold in `WebApiOpenSafety` � never extended |

---

## 18. Dependencies Not Supported in .NET Core

The following APIs are **absent or fundamentally incompatible** with .NET Core / .NET 8:

| Incompatible API / Framework | Files Affected | Replacement |
|---|---|---|
| `System.Web` (entire namespace) | **127 files** | ASP.NET Core APIs (`IHttpContextAccessor`, `ISession`, `HttpContext`) |
| `System.Web.Mvc` (ASP.NET MVC 5) | ~60 `.cs` + 119 `.cshtml` | `Microsoft.AspNetCore.Mvc` |
| `System.Web.Http` (Web API 2) | ~15 files | `Microsoft.AspNetCore.Mvc.ControllerBase` with `[ApiController]` |
| `System.Web.Optimization` (bundling) | 8 files | LibMan + `app.UseStaticFiles()` |
| `System.Web.Script.Serialization.JavaScriptSerializer` | 3 files | `System.Text.Json.JsonSerializer` |
| `System.ServiceModel` (WCF) | **28 files** | ASP.NET Core Web API controllers |
| `System.Data.Entity` (EF6) | **65 files** | `Microsoft.EntityFrameworkCore` 8.x |
| `System.Configuration.ConfigurationManager` | **27 files** | `Microsoft.Extensions.Configuration.IConfiguration` / `IOptions<T>` |
| `System.ServiceProcess.ServiceBase` | 4 files | `Microsoft.Extensions.Hosting.BackgroundService` |
| `System.Runtime.Remoting.Messaging` | 1 file (`ConsoleTest`) | Remove (remoting not available on .NET Core) |
| `System.EnterpriseServices` | Project file references | Remove (COM+ not available) |
| `System.Web.Services` (ASMX proxy) | 1 Web Reference | Replace with `IHttpClientFactory` |
| `Microsoft.Practices.Unity` (Unity 4 namespace) | 7 `UnityConfig.cs` stubs | `Microsoft.Extensions.DependencyInjection` |
| `HttpClientHandler.MaxRequestContentBufferSize` | 13 files (`new HttpClient`) | Remove property (removed in .NET 5+) |
| `Global.asax` / `HttpApplication` | 5 files | `Program.cs` + middleware pipeline |
| `Web.config` / `App.config` (as runtime config) | 13 Web.config + 13 App.config | `appsettings.json` + environment variables + Azure Key Vault |
| `System.Web.Optimization` | 8 files | Remove `BundleConfig`, use LibMan |
| `Trirand.jqGrid` (.NET server wrapper) | 7 views | Pure-JS grid |
| `Swashbuckle` (Web API 2 version) | 2 projects | `Swashbuckle.AspNetCore` |
| `Owin` / `IAppBuilder` | Config/startup files | Remove |
| `WebActivatorEx` | 1 reference | Remove |
| `WebGrease` | Bundle configs | Remove |
| `System.Runtime.Caching.MemoryCache` | `CacheManager.cs` | `Microsoft.Extensions.Caching.Memory.IMemoryCache` |
| EF6 `DbMigrationsConfiguration` / `DbMigration` | **29 migration files** | Re-scaffold via `dotnet ef migrations add InitialCreate` |
| EF6 `EntityTypeConfiguration<T>` | **31 config classes** | `IEntityTypeConfiguration<T>` (EF Core API) |
| `NEST` 6.x / `Elasticsearch.Net` 6.x | 2 implementation files | `Elastic.Clients.Elasticsearch` 8.x |
| `AutoMapper.Mapper.Initialize()` (static API) | 2 `AutoMapperConfig.cs` | `new MapperConfiguration()` + `services.AddAutoMapper()` |
| `System.Net.Mail.SmtpClient` | `OpsEmailSender.cs` | `MailKit.Net.Smtp.SmtpClient` |

**Summary: 225 `.cs` files (39% of the codebase) reference at least one API incompatible with .NET 8.**

---

## 19. Shared Code

### Infrastructure Shared Across Multiple Projects

| Component | Location | Consumed By | Description |
|---|---|---|---|
| `IUnitOfWork` | `OpenSafetyDomainModel` | Application, Infrastructure, DistributedService | Unit of Work contract |
| `IGenericRepository<T>` | `OpenSafetyDomainModel` | Infrastructure, Application, DependancyResolver | Generic CRUD repository interface |
| `IRepository<TEntity>` | `OpenSafetyDomainModel` | Defined but never implemented | Specification-based interface (dead) |
| `GenericRepository<T>` | `OPenSafetyInfrastructure` | DependancyResolver, DistributedService | Generic EF6 CRUD implementation |
| `EFUnitOfWork` | `OPenSafetyInfrastructure` | DependancyResolver, DistributedService | Concrete EF6 Unit of Work |
| `OpenSafetyDBContext` | `OPenSafetyInfrastructure` | Infrastructure, DependancyResolver, Frontend (?? violation) | EF6 DbContext � 29 entity type configurations |
| `BaseService` | `OpenSafetyApplication` | All 8 application services | Base class with session, logging, role helpers |
| `GenericApplicationService<T>` | `OpenSafetyApplication` | Admin CRUD services | Generic CRUD service over `IGenericRepository<T>` |
| `UnauthorizedException` | `OpenSafetyCrossCutting` | All layers (57 catch blocks, 44 `throw new Exception` rethrows) | Custom auth exception � core cross-cutting concern |
| `CacheManager` | `OpenSafetyCrossCutting` | Application, Infrastructure | Static `MemoryCache` wrapper |
| `OpsEmailSender` | `OpenSafetyCrossCutting` | Application, DistributedService | Static SMTP email utility |
| `GenerateExcelFile` | `OpenSafetyCrossCutting` | Application, Frontend | Static Excel export helper |
| `GenerateCsvFile` | `OpenSafetyCrossCutting` | Application, Frontend | Static CSV export (uses `HttpContext.Current.Response`) |
| `ConvertExcelToDataTable` | `OpenSafetyCrossCutting` | Application | Excel ? DataTable utility |
| All DTOs (`*DTO.cs`) | `OpenSafetyContract` (93 DTOs) | Frontend, DistributedService, Application, Tests | Service data transfer objects |
| Service interfaces (`IDicoService`, `IDataService`, etc.) | `OpenSafetyContract` (9 interfaces) | All layers | Public API contracts |
| `RestHelper` | `OpenSafetyFrontend/Helper` | Frontend controllers | Static HTTP call helper (anti-pattern; socket exhaustion risk) |
| `OPSConfigHelper` | `OpenSafetyFrontend/Helper` | Frontend controllers | Static WCF endpoint URL configuration |
| `SiteSession` | `OpenSafetyFrontend/Models` | Frontend controllers, admin helpers, views | Session user data carrier (`LoginNT`, `Domain`, `Role`) |
| `DataHelper` | `OpenSafetyFrontend/Areas/Admin/AdmHelpers` | All admin controllers | WCF call helpers for dropdown data |
| `LayoutClass` | `OpenSafetyFrontend/Models` | HomeController, views (1,069 lines) | View model aggregating search results |
| `DicoAdapter` | `OpenSafetyApplication/BlocDico/Adapter` | DicoApplicationService, DistributedService (1,630 lines) | Domain ? DTO mapping |

### Code Duplication Summary

| Duplicated File | Copies | Recommended Action |
|---|---|---|
| `UnityConfig.cs` | 8 | Delete 7 stubs; replace the real one with `IServiceCollection` extensions |
| `FilterConfig.cs` | 4 | Delete all; handled by `app.UseExceptionHandler()` in `Program.cs` |
| `RouteConfig.cs` | 4 | Delete all; handled by `app.MapControllerRoute()` in `Program.cs` |
| `AutoMapperConfig.cs` | 2 | Merge into one; register via `services.AddAutoMapper()` |
| `UnauthorizedException.cs` | 2 | Remove the copy in Application; keep only the one in CrossCutting |
| Exception triple-catch pattern | **100+ methods** | Replace with a single global exception-handling middleware |

---

## 20. Migration Plan / Strategy

### Principles

1. **Bottom-up, dependency-ordered** � Migrate the layer with no dependencies first, then work upward.
2. **One project per sprint** � Each project is independently compilable and verifiable before moving on.
3. **Strangler Fig** � Deploy the new .NET 8 API endpoint alongside the existing WCF services; redirect consumers one by one; decommission WCF last.
4. **No big bang** � Partial deployments are possible after Phase 3 completes.
5. **Remove before replacing** � Delete all dead code, stubs, and duplicates in Phase 0 to reduce noise during migration.

### Recommended Target Architecture

```
??????????????????????????????????????????????????????????????
?  OpenSafetyFrontend  (ASP.NET Core 8 MVC + Razor Views)    ?
?  ? Typed HttpClient ? OpenSafetyDistributedService         ?
?  ? IHttpContextAccessor (replaces HttpContext.Current)      ?
?  ? ISession (replaces Session["key"])                       ?
?  ? Negotiate auth (Windows Auth via Kerberos/NTLM)         ?
??????????????????????????????????????????????????????????????
                       ? HTTP/JSON
??????????????????????????????????????????????????????????????
?  OpenSafetyDistributedService  (ASP.NET Core 8 Web API)     ?
?  ? 8 [ApiController] replacing 8 WCF .svc services         ?
?  ? Swashbuckle.AspNetCore (OpenAPI / Swagger UI)           ?
?  ? Built-in DI (IServiceCollection) in Program.cs          ?
??????????????????????????????????????????????????????????????
                       ?
??????????????????????????????????????????????????????????????
?  OpenSafetyApplication  (Class Library, net8.0)            ?
?  ? Application services + AutoMapper 13 profiles           ?
?  ? ILogger<T> (replaces log4net)                           ?
?  ? IOptions<T> (replaces ConfigurationManager)             ?
??????????????????????????????????????????????????????????????
                       ?
??????????????????????????????????????????????????????????????
?  OPenSafetyInfrastructure  (Class Library, net8.0)         ?
?  ? EF Core 8 DbContext + Migrations                        ?
?  ? Elastic.Clients.Elasticsearch 8.x                       ?
?  ? IHttpClientFactory-based external API clients           ?
??????????????????????????????????????????????????????????????
                       ?
??????????????????????????????????????????????????????????????
?  OpenSafetyDomainModel  (Class Library, net8.0)            ?
?  OpenSafetyContract     (Class Library, net8.0)            ?
?  OpenSafetyCrossCutting (Class Library, net8.0)            ?
??????????????????????????????????????????????????????????????

WsAsynchronousSilicoState ? .NET 8 Worker Service (BackgroundService)
```

---

### Phase 0 � Preparation & Cleanup (Week 1 � ~5 days)

| Task | Detail |
|---|---|
| Create migration branch | `git checkout -b feature/dotnet8-migration` |
| Install tooling | .NET 8 SDK, `dotnet tool install -g dotnet-ef`, `dotnet tool install -g upgrade-assistant` |
| **Fix critical layer violation** | Remove `ProjectReference` to `OpenSafetyFrontend` from `OPenSafetyInfrastructure`; move the shared `BlocColonneDTO` to `OpenSafetyContract` |
| **Remove 4 stub projects** | `WebFrontendTest`, `OpenSafetyFrontedApplication`, `Fronted.Tests`, `WebApiOpenSafety` � delete from solution and disk |
| Delete 7 stub `UnityConfig.cs` | Keep only `OpenSafetyDependancyResolver\UnityConfig.cs` |
| Delete 4 `FilterConfig.cs` + 4 `RouteConfig.cs` copies | Boilerplate not needed; replaced by middleware |
| Delete `SimpleJson.cs` | Remove 2,127-line embedded JSON parser |
| Rotate credentials | `OpenSafetyDistributedService/Web.config` contains plaintext `Password=` � rotate immediately; add `Web.config` to `.gitignore` |
| Run `upgrade-assistant analyze` | `upgrade-assistant analyze OpenSafety.sln` � document all warnings |

---

### Phase 1 � Foundation Libraries (Weeks 2�3 � ~6 days)

Migrate in bottom-up order. Each step: convert project format ? swap packages ? fix breaking changes ? verify `dotnet build`.

| Step | Project | Key Changes |
|---|---|---|
| **1.1** | `OpenSafetyCrossCutting` | SDK-style `net8.0` csproj; replace `log4net` ? `ILogger<T>` abstractions; replace `System.Runtime.Caching` ? `IMemoryCache` interface; remove `System.Web.HttpContext` from `GenerateCsvFile` (use `IHttpContextAccessor`); remove `Unity` + `WebActivatorEx`; upgrade `ClosedXML` ? 0.102, `DocumentFormat.OpenXml` ? 3.x, `Newtonsoft.Json` ? 13.x; replace `SmtpClient` with `MailKit` in `OpsEmailSender` |
| **1.2** | `OpenSafetyDomainModel` | SDK-style `net8.0` csproj; remove `Unity`, `Microsoft.AspNet.Mvc`, `Microsoft.CodeDom.Providers` build-time packages; remove dead `IRepository` / `DicoDomainSpecification`; add `<Nullable>enable</Nullable>` |
| **1.3** | `OpenSafetyContract` | SDK-style `net8.0` csproj; **strip all WCF attributes** (`[ServiceContract]`, `[OperationContract]`, `[WebGet]`, `[WebInvoke]`, `[FaultContract]`) from all 9 service interfaces; remove `System.ServiceModel` reference; remove `Unity` stub |

---

### Phase 2 � Infrastructure & Application (Weeks 4�8 � ~17 days)

| Step | Project | Key Changes |
|---|---|---|
| **2.1** | `OPenSafetyInfrastructure` | **EF6 ? EF Core 8**: convert 31 `EntityTypeConfiguration<T>` ? `IEntityTypeConfiguration<T>`; update `OpenSafetyDBContext` constructor to accept `DbContextOptions<T>`; run `dotnet ef migrations add InitialCreate` to create a single new baseline migration; delete all 29 old EF6 migration files; inject `DbContext` via constructor (fix 4 `new OpenSafetyDBContext()` violations); **NEST 6 ? `Elastic.Clients.Elasticsearch` 8.x** (rewrite `WebApiElasticSearch.cs`); delete `Web References/MdmWS`; rewrite `WSMdmRepository` using `IHttpClientFactory`; replace `ConfigurationManager` ? `IConfiguration`; replace `log4net` ? `ILogger<T>` |
| **2.2** | `OpenSafetyApplication` | SDK-style `net8.0` csproj; replace `ConfigurationManager` ? `IConfiguration`; replace `log4net` ? `ILogger<T>`; replace `HttpContext.Current.Session` in `SecurityService` ? `IHttpContextAccessor` + `ISession`; update AutoMapper ? 13.x (remove `Mapper.Initialize()` static API; use `Profile`-based classes + `services.AddAutoMapper()`); remove `Unity`, `Unity.Mvc5`, `Microsoft.AspNet.Mvc`; merge duplicate `UnauthorizedException.cs` |

---

### Phase 3 � API Host: WCF ? ASP.NET Core Web API (Weeks 9�12 � ~16 days)

| Step | Task |
|---|---|
| **3.1** | Dissolve `OpenSafetyDependancyResolver` project � translate all `container.RegisterType<I,T>()` calls into `services.AddScoped<I,T>()` in the new `Program.cs` |
| **3.2** | Create `Program.cs` in `OpenSafetyDistributedService` with full DI pipeline, middleware, Windows Authentication (`Negotiate`), and `Swashbuckle.AspNetCore` |
| **3.3** | Create `appsettings.json`; migrate all `Web.config` `<appSettings>` keys; wire Azure Key Vault for secrets |
| **3.4** | Create 8 `[ApiController]` classes � one per WCF service � mapping `[WebGet(UriTemplate=...)]` routes to `[HttpGet("{param}")]` attributes |
| **3.5** | Delete all 8 `.svc` / `.svc.cs` files, `Global.asax`, `Web.config`, `App_Start/UnityConfig.cs` |
| **3.6** | Replace `FaultException` error wrapping with `ProblemDetails` / `IActionResult` + global exception middleware |
| **3.7** | Integration-test all 8 new API endpoints via Swagger UI and `curl` |

---

### Phase 4 � Frontend: MVC 5 ? ASP.NET Core 8 MVC (Weeks 13�19 � ~29 days)

| Step | Task |
|---|---|
| **4.1** | Delete `Global.asax`, `Web.config`, all `App_Start/` files (`BundleConfig`, `FilterConfig`, `RouteConfig`, `WebApiConfig`) |
| **4.2** | Create `Program.cs`, `appsettings.json` with full MVC + Session + Windows Auth + Exception handler pipeline |
| **4.3** | **Replace 6 WCF Service References** with 6 typed `HttpClient` classes (`DicoApiClient`, `AdminApiClient`, etc.) registered via `services.AddHttpClient<T>()` |
| **4.4** | Update all 14 MVC controllers: `System.Web.Mvc.Controller` ? `Microsoft.AspNetCore.Mvc.Controller`; fix namespace `using` directives |
| **4.5** | Update all 11 API controllers: `ApiController` ? `ControllerBase` + `[ApiController]` |
| **4.6** | Replace `HttpContext.Current` (32 files) with `IHttpContextAccessor` injection |
| **4.7** | Replace `Session["key"]` (29 files) with `ISession.GetString()` / `SetString()` |
| **4.8** | Replace `ConfigurationManager` (27 files) with `IConfiguration` |
| **4.9** | Replace `RestHelper` static WebRequest helper with `IHttpClientFactory` typed clients |
| **4.10** | Update 119 Razor views: fix `@model` types (proxy DTOs ? Contract DTOs); update `using` directives; keep `@Html.*` helpers (compatible with ASP.NET Core) |
| **4.11** | Replace `System.Web.Optimization` `BundleConfig` with **LibMan** (`libman.json`) for static asset management |
| **4.12** | Migrate 7 `Trirand.jqGrid` views to **DataTables.js** (pure JS CDN) |
| **4.13** | Replace `PagedList.Mvc` with `X.PagedList.Mvc.Core` |
| **4.14** | Replace `log4net` with `ILogger<T>` in 50 affected files |
| **4.15** | Add `<Nullable>enable</Nullable>` globally; fix null-safety warnings systematically |

---

### Phase 5 � Background Services & Utilities (Week 20 � ~6 days)

| Step | Project | Key Changes |
|---|---|---|
| **5.1** | `WsAsynchronousSilicoState` | Replace `ServiceBase` with `BackgroundService`; replace `System.Timers.Timer` with `PeriodicTimer`; create new `Program.cs` with `Host.CreateDefaultBuilder().UseWindowsService()`; delete `ProjectInstaller.*`; inject `IHttpClientFactory`; convert 10 blocking `.Result` calls to `async`/`await` |
| **5.2** | `OpenSafetyStateChecker` | Same pattern as 5.1; implement actual health-check logic or retire the project |
| **5.3** | `JsonToSql` | Bump `netcoreapp3.1` ? `net8.0`; replace `Microsoft.Office.Interop.Excel` with `ClosedXML` |
| **5.4** | `ConsoleTest` | Remove `System.Runtime.Remoting`, `JavaScriptSerializer`, `WebRequest`; replace with `HttpClient`; or retire |

---

### Phase 6 � Test Modernisation (Week 21 � ~9 days)

| Step | Task |
|---|---|
| **6.1** | Convert `OpenSafetyDistributedService.Tests` ? xUnit + `Microsoft.AspNetCore.Mvc.Testing` (`WebApplicationFactory<T>`) |
| **6.2** | Convert `OpenSafetyFrontend.Tests` ? xUnit + `WebApplicationFactory<T>` |
| **6.3** | Add **Moq** for mocking and **FluentAssertions** |
| **6.4** | Write unit tests for `DicoApplicationService`, `SecurityService`, `EFDicoRepository` |
| **6.5** | Write integration tests for all 8 new API controllers |
| **6.6** | Set up CI code coverage gate (? 60% target) |

---

### Phase 7 � CI/CD & Deployment (Week 22 � ~4 days)

| Step | Task |
|---|---|
| **7.1** | Update `Jenkinsfile-Api` and `Jenkinsfile-Front`: replace `MSBuild` with `dotnet restore` ? `dotnet build` ? `dotnet test` ? `dotnet publish` |
| **7.2** | Add `dotnet ef database update` pipeline step after publish, before IIS deployment |
| **7.3** | Install **.NET 8 Windows Hosting Bundle** on all IIS servers (dev, pit, int, prod) |
| **7.4** | Configure IIS application pools: `.NET CLR Version` = **No Managed Code** |
| **7.5** | Create `web.config` deployment template with `<aspNetCore processPath="dotnet" ...>` handler |

---

### Total Effort Summary

| Phase | Description | Duration | Effort |
|---|---|---|---|
| 0 | Preparation, cleanup, credential rotation | Week 1 | 5 days |
| 1 | Foundation libraries (CrossCutting, DomainModel, Contract) | Weeks 2�3 | 6 days |
| 2 | Infrastructure (EF Core 8, Elasticsearch 8) + Application | Weeks 4�8 | 17 days |
| 3 | WCF ? ASP.NET Core Web API (8 services) | Weeks 9�12 | 16 days |
| 4 | Frontend MVC 5 ? ASP.NET Core 8 MVC | Weeks 13�19 | 29 days |
| 5 | Background services + console utilities | Week 20 | 6 days |
| 6 | Test modernisation (xUnit, Moq, coverage) | Week 21 | 9 days |
| 7 | CI/CD pipeline + IIS deployment update | Week 22 | 4 days |
| **Total** | | **~22 weeks** | **~92 developer-days** |

> With 2 developers in parallel (e.g., one on Infrastructure/Application, one on Frontend), calendar time reduces to approximately **12�14 weeks**.

---

### Top 5 Risks

| Risk | Probability | Impact | Mitigation |
|---|---|---|---|
| External consumers of WCF `.svc` endpoints break | ?? High | ?? Critical | Use Strangler Fig � run WCF and new REST API in parallel; audit all callers before cutover |
| Elasticsearch cluster version mismatch (cluster on 6.x, new client requires 8.x) | ?? High | ?? High | Upgrade ES cluster to 8.x first; or use NEST 7.x as an intermediate step |
| `Trirand.jqGrid` has no drop-in replacement � 7 screens need UI redesign | ?? High | ?? Medium | Dedicate a UI sprint to replace grids with DataTables.js; agree on grid feature parity list upfront |
| EF Core migration generates incorrect schema | ?? Medium | ?? High | Run `dotnet ef dbcontext scaffold` on production DB to verify; compare output against current schema before cutover |
| AutoMapper 5 ? 13 breaks unmapped configuration | ?? High | ?? Medium | Run `cfg.AssertConfigurationIsValid()` in startup tests after upgrade; fix all mapping gaps |

---

*Document generated from automated source analysis and manual review of `OpenSafety.sln`.*
